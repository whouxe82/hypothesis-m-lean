import OrbitArithmetic
import CP_CycleAdapter

namespace HypothesisMMinimal
open HypothesisMTarget HypothesisMOrbit HypothesisMCycleAdapter

/-- Infinite equality of actual parity itineraries determines the seed. -/
theorem seed_eq_of_all_parities (n m : ℕ)
    (h : ∀ t, orbit n t % 2 = orbit m t % 2) : n = m := by
  have hd := same_parities_dvd (n + m + 1) n m (fun t ht => h t)
  have hpN : n + m < 2 ^ (n + m + 1) := by
    have hh := Nat.lt_two_pow_self (n := n + m + 1)
    omega
  have hp : (n : ℤ) + (m : ℤ) < (2 : ℤ) ^ (n + m + 1) := by
    exact_mod_cast hpN
  have hab : |(n : ℤ) - (m : ℤ)| ≤ (n : ℤ) + (m : ℤ) := by
    apply abs_le.mpr
    constructor <;> omega
  have hz : (n : ℤ) - (m : ℤ) = 0 := by
    by_contra hne
    have hle := Int.le_of_dvd (abs_pos.mpr hne) ((dvd_abs _ _).mpr hd)
    omega
  exact_mod_cast sub_eq_zero.mp hz

theorem exists_least_return (n p : ℕ) (hp : 0 < p) (hret : orbit n p = n) :
    ∃ d : ℕ, 0 < d ∧ d ≤ p ∧ orbit n d = n ∧
      ∀ a : ℕ, 0 < a → a < d → orbit n a ≠ n := by
  have hex : ∃ d : ℕ, 0 < d ∧ orbit n d = n := ⟨p, hp, hret⟩
  refine ⟨Nat.find hex, (Nat.find_spec hex).1, Nat.find_min' hex ⟨hp, hret⟩,
    (Nat.find_spec hex).2, ?_⟩
  intro a ha had heq
  have hh := Nat.find_min' hex ⟨ha, heq⟩
  omega

/-- A least positive state period has no shorter cyclic parity period.
The proof uses the universal congruence theorem, not a finite parity test. -/
theorem no_short_parity_period (n p : ℕ) [NeZero p]
    (hret : orbit n p = n)
    (hmin : ∀ a : ℕ, 0 < a → a < p → orbit n a ≠ n) :
    ∀ a : ℕ, 0 < a → a < p →
      ¬ (∀ s : ZMod p, cycleBits n p (s + (a : ZMod p)) = cycleBits n p s) := by
  intro a ha hap hw
  apply hmin a ha hap
  apply seed_eq_of_all_parities
  intro t
  have hb := hw (t : ZMod p)
  rw [← Nat.cast_add, cycleBits_natCast n p hret (t + a),
    cycleBits_natCast n p hret t] at hb
  have hn := Nat.mod_lt (orbit n t) (by decide : 0 < 2)
  have hm := Nat.mod_lt (orbit n (t + a)) (by decide : 0 < 2)
  have hpar : orbit n (t + a) % 2 = orbit n t % 2 := by
    by_cases he : orbit n (t + a) % 2 = 1 <;>
      by_cases hf : orbit n t % 2 = 1 <;> simp [he, hf] at hb <;> omega
  simpa [← orbit_add, Nat.add_comm] using hpar

#print axioms seed_eq_of_all_parities
#print axioms exists_least_return
#print axioms no_short_parity_period
end HypothesisMMinimal
