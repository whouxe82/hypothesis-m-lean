# Hypothesis M portable Lean replay project

This directory preserves the exact Lean source and dependency pins for the
October 2026 Hypothesis M assembly. The final theorem names are listed in
FINAL_THEOREMS.json. The surrounding interim report and the root verification
record state which final builds were accepted. Packaging a theorem does not by
itself show that it compiled: successful compiler logs and axiom closures are
the evidence for that claim.

## Scope of the mathematical statements

MStatement.lean fixes the shortcut Collatz map, its actual orbit, the odd-step
count, and the assertion that every seed n at least 2 has a coefficient exit
from [1,3] within Nat.log2(n*n)+1 steps. It allows either a downward or an upward
coefficient exit. The main formal target remains exactly that definition.

The package also contains an actual-orbit balanced-cycle classification and
the supporting arithmetic and combinatorial bridges. An accepted proof of M
does not establish that every Collatz orbit reaches 1. It also does not establish
originality or priority of the bound.

## Toolchain and dependency pins

Use Lean 4.35.0 and its paired Lake executable. The exact toolchain declaration
is in lean-toolchain. Mathlib is pinned by lake-manifest.json to commit
56a005855ea17e0b0958f73ec801ae140b0a1679, the v4.35.0 dependency used for the
recorded verification. All transitive Git revisions are preserved in that
manifest. The package contains neither the Lean distribution nor Mathlib's
sources and compiled cache.

Knight2026 sources are from tcosmo/Knight2026_lean, commit
a535cd1db48e2bd62790a8efed24e91120b1e2ff. They are included locally so the replay
does not track a moving Knight repository branch. The single compatibility edit
in HighCycle.lean is recorded in provenance/KNIGHT_COMPATIBILITY_PATCH.diff.
Original source fetch records and the upstream tree are preserved there as well.

## License provenance

Knight2026/Defs.lean declares Apache 2.0 in its source header. The preserved
upstream tree contains no LICENSE file. LICENSE.Apache-2.0 supplies the standard
Apache 2.0 text copied from the locally installed, pinned Mathlib LICENSE; it is
not described as a LICENSE file downloaded from the Knight repository. Original
source notices are preserved. DEPENDENCY_PINS.json records this distinction and
the license text hash. This package makes no new licensing declaration for the
project's newly authored proof modules.

## Replay

Install the toolchain named in lean-toolchain and make its lean and lake
executables available. Python 3 and Git are also required. From this directory:

```sh
python3 replay.py --check-only
python3 replay.py
```

The first command only checks the frozen file hashes and local import order.
It performs no network operation and does not compile Lean. The second command
checks the installed versions, obtains the exact manifest-pinned dependencies
and Mathlib cache, verifies their Git revisions, builds Knight2026, and compiles
each project module in dependency order. It then creates and compiles an axiom
audit for every final theorem. Only propext, Classical.choice, and Quot.sound
are accepted in those dependency closures.

If the pinned executables are outside PATH, supply their directory:

```sh
python3 replay.py --lean-bin /absolute/path/to/lean-4.35.0/bin
```

For an environment whose exact dependencies and required cache are already
present, use `python3 replay.py --offline`. This verifies all local dependency
Git revisions before invoking Lake and skips the cache download. A missing or
different dependency stops the run.

Each run creates a new replay_runs directory with timestamped subdirectories,
individual command logs, a final theorem axiom audit, and REPLAY_RECORD.json.
Failure preserves all completed logs and identifies the failing command. PASS
requires successful compilation of every project module and the named final
theorems, accepted axiom closures, and unchanged packaged source hashes.

## Evidence and reproducibility

The original assembly verification used the existing local Lean installation
and dependency cache. A portable replay describes how another environment can
repeat it; preparing this directory is not an independent-machine replay.
Consult the surrounding verification record for the actual original run and
any separately completed replay. No fresh download or network replay was run
while this portable directory was prepared.

SOURCE_MANIFEST.json freezes the source bytes. A verifier should not run
freeze_manifest.py to make a mismatch disappear. That utility is for a
maintainer deliberately creating a new source version after an authorized edit.
The replay itself never regenerates or silently accepts a different manifest.
