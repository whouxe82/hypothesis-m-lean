import PrefixReturn
import MinimalCycle
import WordAffineBridge

/-!
Complete assembly for the unchanged frozen Hypothesis M seed statement.
No assertion of universal Collatz convergence is made by this file.
-/
namespace HypothesisMAssembly
open HypothesisMTarget HypothesisMCritical HypothesisMOrbit HypothesisMAffine
open HypothesisMBalanced HypothesisMCycleAdapter HypothesisMMinimal
open HypothesisMWordAffine
open scoped BigOperators

/-- A balanced least-period positive integer return has period two. -/
theorem balanced_minimal_return_period_two (n p : ℕ) [NeZero p]
    (hn : 0 < n) (hp : 0 < p) (hret : orbit n p = n)
    (hmin : ∀ a : ℕ, 0 < a → a < p → orbit n a ≠ n)
    (hbal : CyclicallyBalanced (cycleBits n p)) : p = 2 := by
  have hdata := positive_return_data n p hn hp hret
  have hq : (∑ z : ZMod p, cycleBits n p z) =
      ((orbitWord n 0 p).count true : ℤ) := by
    rw [← cyclic_weight_period (cycleBits n p) (0 : ZMod p),
      cyclicWeight_eq_actual n p hret]
    simp
  have hprim : NoShortPeriod (cycleBits n p) :=
    no_short_parity_period n p hret hmin
  obtain ⟨s, hs, t, ht, hfs, hft, hls, hlt, hmid⟩ :=
    balanced_primitive_endpoint_letters (cycleBits n p)
      (cycleBits_binary n p) hbal hprim hq hdata.1 hdata.2.1
  obtain ⟨u, hu, hv⟩ := endpoint_letters_to_rotations n p s t
    (by omega) hret hfs hft hls hlt hmid
  have hden : 0 < bsDenominator (orbitWord n 0 p).length
      ((orbitWord n 0 p).count true) := by
    simpa only [HypothesisMWordAffine.orbitWord_length] using hdata.2.2.2.1
  have hint : bsIsInteger (orbitWord n 0 p).length
      ((orbitWord n 0 p).count true) (orbitWord n 0 p) := by
    simpa only [HypothesisMWordAffine.orbitWord_length] using hdata.2.2.2.2
  have he := endpoint_rotations_force_period_two (orbitWord n 0 p) u s t hu hv hden hint
  simpa only [HypothesisMWordAffine.orbitWord_length] using he.2.1

/-- Balance of every pair of equal-length actual parity factors. -/
def BalancedParityOrbit (n : ℕ) : Prop :=
  ∀ s t a : ℕ, (orbitWord n s a).count true ≤ (orbitWord n t a).count true + 1

/-- The positive integer cycles with balanced parity are exactly the
trivial cycle states. This does not assume that all Collatz cycles are balanced. -/
theorem balanced_return_trivial (n p : ℕ) (hn : 0 < n) (hp : 0 < p)
    (hret : orbit n p = n) (hbal : BalancedParityOrbit n) : n = 1 ∨ n = 2 := by
  obtain ⟨d, hd, hdp, hretD, hmin⟩ := exists_least_return n p hp hret
  letI : NeZero d := ⟨by omega⟩
  have hcyc : CyclicallyBalanced (cycleBits n d) := by
    intro s t a ha
    rw [cyclicWeight_eq_actual n d hretD s a,
      cyclicWeight_eq_actual n d hretD t a]
    exact_mod_cast hbal s.val t.val a
  have hd2 := balanced_minimal_return_period_two n d hn hd hretD hmin hcyc
  exact period_two_states n hn (by simpa only [hd2] using hretD)

/-- Hypothesis M, with exactly the previously frozen target and definitions. -/
theorem hypothesis_M : MStatement := by
  intro n hn
  by_cases hsmall : n < 64
  · exact small_seeds_meet_bound n hn hsmall
  have hlarge : 64 ≤ n := by omega
  let L : ℕ := Nat.log2 (n * n) + 1
  let k : ℕ := (L - 1) / 2
  obtain ⟨hL, hk, hwindow, hupper, hseed⟩ :=
    large_seed_parameters n L k hlarge rfl rfl
  by_contra hnoexit
  change ¬ CoefficientExitWithin n L at hnoexit
  obtain ⟨i, p, hi, hik, hp, hpk, hfit, hgrow, hret⟩ :=
    confined_prefix_returns n L k hn hk hwindow hseed hnoexit
  obtain ⟨d, hd, hdp, hretD, hmin⟩ := exists_least_return (orbit n i) p hp hret
  letI : NeZero d := ⟨by omega⟩
  have hbalance := returned_orbit_cyclically_balanced n L i d hnoexit
    (by omega) hretD
  have hx : 0 < orbit n i := by omega
  have hd2 := balanced_minimal_return_period_two (orbit n i) d hx hd hretD hmin hbalance
  have htrivial := period_two_states (orbit n i) hx (by simpa only [hd2] using hretD)
  omega

/-- Expanded statement of the machine-checked conclusion, with no logarithm
convention or coefficient denominator left implicit. -/
theorem coefficient_exit_bound (n : ℕ) (hn : 2 ≤ n) :
    ∃ j : ℕ, 1 ≤ j ∧ j ≤ Nat.log2 (n * n) + 1 ∧
      ((3 : ℕ) ^ oddCount n j < (2 : ℕ) ^ j ∨
        3 * (2 : ℕ) ^ j < (3 : ℕ) ^ oddCount n j) :=
  hypothesis_M n hn

#check hypothesis_M
#print hypothesis_M
#print axioms balanced_minimal_return_period_two
#print axioms balanced_return_trivial
#print axioms hypothesis_M
#print axioms coefficient_exit_bound
end HypothesisMAssembly
