#!/usr/bin/env python3
"""Replay the pinned Hypothesis M Lean project; Python standard library only.

The default run downloads the manifest-pinned dependencies and Mathlib cache.
--check-only validates the packaged sources without running Lean or networking.
--offline requires every pinned dependency and needed cache already present.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent
STANDARD_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_'.]*(?:\.[A-Za-z_][A-Za-z0-9_']*)*\Z")


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def read_json(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_check() -> dict:
    manifest = read_json("SOURCE_MANIFEST.json")
    entries = manifest["files"]
    if not entries:
        raise RuntimeError("The frozen source manifest is empty.")
    for row in entries:
        rel = Path(row["path"])
        if rel.is_absolute() or ".." in rel.parts:
            raise RuntimeError(f"Unsafe manifest path: {rel}")
        path = ROOT / rel
        if not path.is_file():
            raise RuntimeError(f"Missing packaged source: {rel}")
        if path.stat().st_size != row["bytes"] or sha256(path) != row["sha256"]:
            raise RuntimeError(f"Source checksum mismatch: {rel}")
    pins = read_json("DEPENDENCY_PINS.json")
    if (ROOT / "lean-toolchain").read_text().strip() != pins["lean_toolchain"]:
        raise RuntimeError("The declared toolchain differs from the pinned toolchain.")
    dependencies = read_json("lake-manifest.json")["packages"]
    mathlib = next(p for p in dependencies if p["name"] == "mathlib")
    if mathlib["rev"] != pins["mathlib_commit"]:
        raise RuntimeError("Mathlib revision differs from DEPENDENCY_PINS.json.")
    finals = read_json("FINAL_THEOREMS.json")
    if not finals["theorems"]:
        raise RuntimeError("No final theorem is named for the axiom audit.")
    for name in [finals["module"], *finals["theorems"]]:
        if not NAME.fullmatch(name):
            raise RuntimeError(f"Invalid Lean identifier in theorem manifest: {name}")
    if finals["module"] not in pins["project_modules"]:
        raise RuntimeError("Final module is absent from the project module inventory.")
    return {"status": "PASS", "files": len(entries), "source_manifest_sha256":
            sha256(ROOT / "SOURCE_MANIFEST.json")}


def module_order() -> list[str]:
    modules = read_json("DEPENDENCY_PINS.json")["project_modules"]
    names = set(modules)
    imports = {}
    for module in modules:
        text = (ROOT / (module.replace(".", "/") + ".lean")).read_text(encoding="utf-8")
        found = set()
        for line in text.splitlines():
            match = re.match(r"^(?:public\s+)?import\s+(.+)$", line)
            if match:
                found.update(x for x in match.group(1).split("--", 1)[0].split() if x in names)
        imports[module] = found
    ordered = []
    remaining = list(modules)
    while remaining:
        ready = [m for m in remaining if imports[m].issubset(ordered)]
        if not ready:
            raise RuntimeError(f"Cyclic or unresolved local imports: {remaining}")
        for module in ready:
            ordered.append(module)
            remaining.remove(module)
    return ordered


def verify_dependency_commits(env: dict[str, str]) -> list[dict]:
    checked = []
    manifest = read_json("lake-manifest.json")
    packages_dir = ROOT / manifest.get("packagesDir", ".lake/packages")
    for package in manifest["packages"]:
        if package["type"] != "git":
            raise RuntimeError(f"Unsupported dependency kind for {package['name']}")
        path = packages_dir / package["name"]
        if not path.is_dir():
            raise RuntimeError(f"Pinned dependency is unavailable: {package['name']}")
        result = subprocess.run(["git", "-C", str(path), "rev-parse", "HEAD"],
                                env=env, capture_output=True, text=True, check=False)
        actual = result.stdout.strip()
        if result.returncode or actual != package["rev"]:
            raise RuntimeError(f"Dependency revision mismatch: {package['name']}; "
                               f"expected {package['rev']}, found {actual or result.stderr.strip()}")
        checked.append({"name": package["name"], "rev": actual})
    return checked


def parse_axioms(text: str, expected: list[str]) -> dict[str, list[str]]:
    observed = {}
    pattern = r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]"
    for theorem, values in re.findall(pattern, text, flags=re.DOTALL):
        observed[theorem] = [x.strip() for x in values.split(",") if x.strip()]
    for theorem in re.findall(r"'([^']+)' does not depend on any axioms", text):
        observed[theorem] = []
    for theorem in expected:
        if theorem not in observed:
            raise RuntimeError(f"Axiom audit did not print a closure for {theorem}.")
        extra = set(observed[theorem]) - STANDARD_AXIOMS
        if extra:
            raise RuntimeError(f"Unexpected axioms in {theorem}: {sorted(extra)}")
    return {theorem: observed[theorem] for theorem in expected}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true",
                        help="Verify packaged hashes/import order without Lean, downloads, or compilation.")
    parser.add_argument("--offline", action="store_true",
                        help="Require all pinned dependencies and cache locally; skip cache download.")
    parser.add_argument("--lean-bin", type=Path,
                        help="Directory containing the installed pinned lean and lake executables.")
    args = parser.parse_args()
    static = source_check()
    order = module_order()
    print(f"Frozen source validation: PASS ({static['files']} files)", flush=True)
    print("Compile order: " + ", ".join(order), flush=True)
    if args.check_only:
        print("No Lean command or network operation was executed.")
        return 0

    env = os.environ.copy()
    if args.lean_bin:
        tool_dir = args.lean_bin.expanduser().resolve()
        for executable in ("lean", "lake"):
            if not (tool_dir / executable).is_file():
                raise RuntimeError(f"Missing executable: {tool_dir / executable}")
        env["PATH"] = str(tool_dir) + os.pathsep + env.get("PATH", "")
    lean = shutil.which("lean", path=env.get("PATH"))
    lake = shutil.which("lake", path=env.get("PATH"))
    if not lean or not lake:
        raise RuntimeError("Install the toolchain in lean-toolchain, or pass --lean-bin DIRECTORY.")

    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S_%f_UTC")
    run_dir = ROOT / "replay_runs" / stamp
    run_dir.mkdir(parents=True)
    record = {"started_utc": utc_now(), "status": "RUNNING", "offline": args.offline,
              "python": sys.version, "static_validation": static, "compile_order": order,
              "steps": [], "claim": "A replay validates the packaged Lean statements and dependencies; "
              "it does not establish originality or full Collatz convergence."}
    started = time.monotonic()

    def run(label: str, command: list[str]) -> str:
        log = run_dir / f"{len(record['steps']) + 1:02d}_{label}.log"
        step = {"label": label, "command": command, "started_utc": utc_now(),
                "log": str(log.relative_to(ROOT))}
        record["steps"].append(step)
        print(f"Running {label}...", flush=True)
        with log.open("w", encoding="utf-8") as handle:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=handle,
                                    stderr=subprocess.STDOUT, text=True, check=False)
        text = log.read_text(encoding="utf-8", errors="replace")
        step.update(exit_code=result.returncode, completed_utc=utc_now(),
                    log_sha256=sha256(log))
        if result.returncode:
            raise RuntimeError(f"{label} failed with exit code {result.returncode}; inspect {log}.")
        if "sorryAx" in text or "declaration uses 'sorry'" in text:
            raise RuntimeError(f"An admitted proof appeared in {label}; inspect {log}.")
        return text

    try:
        version = read_json("DEPENDENCY_PINS.json")["lean_version"]
        lean_version = run("lean_version", [lean, "--version"])
        lake_version = run("lake_version", [lake, "--version"])
        if not re.search(rf"\b{re.escape(version)}\b", lean_version):
            raise RuntimeError(f"Lean version is not the pinned {version}: {lean_version.strip()}")
        if version not in lake_version:
            raise RuntimeError(f"Lake is not paired with Lean {version}: {lake_version.strip()}")
        record["lean_version"] = lean_version.strip()
        record["lake_version"] = lake_version.strip()
        manifest_before = sha256(ROOT / "lake-manifest.json")
        if args.offline:
            record["dependencies"] = verify_dependency_commits(env)
        else:
            run("mathlib_cache", [lake, "exe", "cache", "get"])
            record["dependencies"] = verify_dependency_commits(env)
        if sha256(ROOT / "lake-manifest.json") != manifest_before:
            raise RuntimeError("Lake changed the pinned manifest; replay stopped without accepting the change.")
        run("knight_dependency", [lake, "build", "Knight2026"])
        output_dir = ROOT / ".lake/build/lib/lean"
        output_dir.mkdir(parents=True, exist_ok=True)
        for module in order:
            source = module.replace(".", "/") + ".lean"
            output = output_dir / (module.replace(".", "/") + ".olean")
            output.parent.mkdir(parents=True, exist_ok=True)
            run("compile_" + module.replace(".", "_"),
                [lake, "env", "lean", source, "-o", str(output)])
        finals = read_json("FINAL_THEOREMS.json")
        audit = run_dir / "ReplayAxiomAudit.lean"
        lines = ["import " + finals["module"], ""]
        for theorem in finals["theorems"]:
            lines.extend(["#check " + theorem, "#print axioms " + theorem])
        audit.write_text("\n".join(lines) + "\n", encoding="utf-8")
        audit_text = run("final_axiom_audit", [lake, "env", "lean", str(audit)])
        record["final_axioms"] = parse_axioms(audit_text, finals["theorems"])
        record["source_validation_after_build"] = source_check()
        record["status"] = "PASS"
    except Exception as error:
        record["status"] = "FAIL"
        record["error"] = str(error)
    finally:
        record["completed_utc"] = utc_now()
        record["elapsed_seconds"] = time.monotonic() - started
        report = run_dir / "REPLAY_RECORD.json"
        report.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        print(f"Replay {record['status']}: {report}", flush=True)
        if record["status"] == "FAIL":
            print(record["error"], file=sys.stderr)
    return 0 if record["status"] == "PASS" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError) as error:
        print(f"Replay stopped: {error}", file=sys.stderr)
        raise SystemExit(1)
