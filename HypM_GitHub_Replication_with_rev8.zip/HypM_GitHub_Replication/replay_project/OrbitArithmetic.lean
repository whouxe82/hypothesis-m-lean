import MStatement

/-! Actual shortcut-Collatz orbit arithmetic used by the assembly.
Every theorem in this module is universally quantified; no experimental
range or certificate is used as a substitute for its proof. -/
namespace HypothesisMOrbit
open HypothesisMTarget

theorem orbit_add (n a b : ℕ) : orbit n (a + b) = orbit (orbit n a) b := by
  induction b with
  | zero => simp [orbit]
  | succ b ih => simpa [orbit, Nat.add_assoc] using congrArg shortcut ih

theorem orbit_step_first (n a : ℕ) : orbit n (a + 1) = orbit (shortcut n) a := by
  simpa [orbit, Nat.add_comm] using orbit_add n 1 a

theorem shortcut_even (n : ℕ) (h : n % 2 = 0) :
    2 * shortcut n = n := by
  simp only [shortcut, h, ↓reduceIte]
  omega

theorem shortcut_odd (n : ℕ) (h : n % 2 = 1) :
    2 * shortcut n = 3 * n + 1 := by
  have hne : ¬ n % 2 = 0 := by omega
  simp only [shortcut, hne, ↓reduceIte]
  omega

theorem shortcut_pos {n : ℕ} (hn : 0 < n) : 0 < shortcut n := by
  by_cases h : n % 2 = 0
  · have := shortcut_even n h
    omega
  · have hm : n % 2 = 1 := by omega
    have := shortcut_odd n hm
    omega

theorem orbit_pos {n : ℕ} (hn : 0 < n) (j : ℕ) : 0 < orbit n j := by
  induction j with
  | zero => exact hn
  | succ j ih => exact shortcut_pos ih

/-- Equal length-k parity blocks imply divisibility of the seed difference
by 2^k. This is the actual orbit-to-congruence bridge. -/
theorem same_parities_dvd (k n m : ℕ)
    (h : ∀ t < k, orbit n t % 2 = orbit m t % 2) :
    (2 : ℤ) ^ k ∣ (n : ℤ) - (m : ℤ) := by
  induction k generalizing n m with
  | zero => simp
  | succ k ih =>
    have h0 : n % 2 = m % 2 := by simpa [orbit] using h 0 (by omega)
    have ht : ∀ t < k, orbit (shortcut n) t % 2 = orbit (shortcut m) t % 2 := by
      intro t ht
      simpa [orbit_step_first] using h (t + 1) (by omega)
    obtain ⟨z, hz⟩ := ih (shortcut n) (shortcut m) ht
    have hmul : (2 : ℤ) ^ (k + 1) ∣
        2 * ((shortcut n : ℤ) - (shortcut m : ℤ)) := by
      refine ⟨z, ?_⟩
      rw [hz, pow_succ]
      ring
    by_cases he : n % 2 = 0
    · have hn := shortcut_even n he
      have hm := shortcut_even m (by omega)
      have hni : 2 * (shortcut n : ℤ) = (n : ℤ) := by exact_mod_cast hn
      have hmi : 2 * (shortcut m : ℤ) = (m : ℤ) := by exact_mod_cast hm
      have heq : 2 * ((shortcut n : ℤ) - (shortcut m : ℤ)) =
          (n : ℤ) - (m : ℤ) := by linarith
      rwa [heq] at hmul
    · have ho : n % 2 = 1 := by omega
      have hn := shortcut_odd n ho
      have hm := shortcut_odd m (by omega)
      have hni : 2 * (shortcut n : ℤ) = 3 * (n : ℤ) + 1 := by exact_mod_cast hn
      have hmi : 2 * (shortcut m : ℤ) = 3 * (m : ℤ) + 1 := by exact_mod_cast hm
      have heq : 2 * ((shortcut n : ℤ) - (shortcut m : ℤ)) =
          3 * ((n : ℤ) - (m : ℤ)) := by linarith
      rw [heq] at hmul
      have hc : IsCoprime ((2 : ℤ) ^ (k + 1)) 3 := by
        exact (by norm_num : IsCoprime (2 : ℤ) 3).pow_left
      exact hc.dvd_of_dvd_mul_left hmul

theorem same_blocks_dvd (n i j k : ℕ)
    (h : ∀ t < k, orbit n (i + t) % 2 = orbit n (j + t) % 2) :
    (2 : ℤ) ^ k ∣ (orbit n i : ℤ) - (orbit n j : ℤ) := by
  apply same_parities_dvd
  intro t ht
  simpa [orbit_add] using h t ht

/-- Congruent integer states separated by less than their modulus coincide. -/
theorem collision_of_close (n i j k : ℕ)
    (hpar : ∀ t < k, orbit n (i + t) % 2 = orbit n (j + t) % 2)
    (hclose : |(orbit n i : ℤ) - (orbit n j : ℤ)| < (2 : ℤ) ^ k) :
    orbit n i = orbit n j := by
  have hd := same_blocks_dvd n i j k hpar
  have hz : (orbit n i : ℤ) - (orbit n j : ℤ) = 0 := by
    by_contra hne
    have hle := Int.le_of_dvd (abs_pos.mpr hne) ((dvd_abs _ _).mpr hd)
    linarith
  exact_mod_cast (sub_eq_zero.mp hz)

theorem return_of_collision (n i j : ℕ) (hij : i ≤ j)
    (heq : orbit n i = orbit n j) :
    orbit (orbit n i) (j - i) = orbit n i := by
  rw [← orbit_add, Nat.add_sub_of_le hij]
  exact heq.symm

#print axioms same_parities_dvd
#print axioms collision_of_close
#print axioms return_of_collision
end HypothesisMOrbit
