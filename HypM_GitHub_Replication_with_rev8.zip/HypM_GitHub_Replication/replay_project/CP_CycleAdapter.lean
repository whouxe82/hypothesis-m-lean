import CriticalPrefix
import BalancedBridge
import OrbitArithmetic
import Mathlib.Data.Nat.Periodic

/-! Conversion of a repeated actual orbit segment to a balanced cyclic word.
All periodicity and two-copy hypotheses are explicit. -/
namespace HypothesisMCycleAdapter
open HypothesisMTarget HypothesisMCritical HypothesisMBalanced HypothesisMOrbit
open scoped BigOperators

theorem orbit_periodic (n p : ℕ) (hret : orbit n p = n) :
    Function.Periodic (orbit n) p := by
  intro t
  rw [Nat.add_comm t p, orbit_add, hret]

theorem orbit_mod (n p t : ℕ) (hret : orbit n p = n) :
    orbit n (t % p) = orbit n t :=
  (orbit_periodic n p hret).map_mod_nat t

def cycleBits (n p : ℕ) (s : ZMod p) : ℤ :=
  if orbit n s.val % 2 = 1 then 1 else 0

theorem cycleBits_binary (n p : ℕ) (s : ZMod p) :
    cycleBits n p s = 0 ∨ cycleBits n p s = 1 := by
  unfold cycleBits
  split_ifs <;> simp

theorem cycleBits_natCast (n p : ℕ) [NeZero p] (hret : orbit n p = n) (t : ℕ) :
    cycleBits n p (t : ZMod p) = if orbit n t % 2 = 1 then 1 else 0 := by
  simp only [cycleBits, ZMod.val_natCast, orbit_mod n p t hret]

theorem cycleBits_at_add (n p : ℕ) [NeZero p] (hret : orbit n p = n)
    (s : ZMod p) (i : ℕ) :
    cycleBits n p (s + (i : ZMod p)) =
      if orbit n (s.val + i) % 2 = 1 then 1 else 0 := by
  unfold cycleBits
  rw [ZMod.val_add, ZMod.val_natCast, Nat.add_mod_mod, orbit_mod n p _ hret]

theorem orbitWord_count_sum (n start len : ℕ) :
    ((orbitWord n start len).count true : ℤ) =
      ∑ i ∈ Finset.range len, if orbit n (start + i) % 2 = 1 then (1 : ℤ) else 0 := by
  have he (len : ℕ) : (oddCount n (start + len) : ℤ) = (oddCount n start : ℤ) +
      ∑ i ∈ Finset.range len, if orbit n (start + i) % 2 = 1 then (1 : ℤ) else 0 := by
    induction len with
    | zero => simp
    | succ len ih =>
      rw [Finset.sum_range_succ, Nat.add_succ, oddCount]
      by_cases h : orbit n (start + len) % 2 = 1 <;> simp [h] at * <;> omega
  have hc := congrArg (fun a : ℕ => (a : ℤ)) (orbitWord_count_add n start len)
  push_cast at hc
  have hh := he len
  omega

theorem cyclicWeight_eq_actual (n p : ℕ) [NeZero p] (hret : orbit n p = n)
    (s : ZMod p) (a : ℕ) :
    cyclicWeight (cycleBits n p) s a = ((orbitWord n s.val a).count true : ℤ) := by
  rw [orbitWord_count_sum]
  unfold cyclicWeight
  apply Finset.sum_congr rfl
  intro i hi
  exact cycleBits_at_add n p hret s i

theorem cycleBits_total (n p : ℕ) [NeZero p] (hret : orbit n p = n) :
    (∑ s : ZMod p, cycleBits n p s) = ((orbitWord n 0 p).count true : ℤ) := by
  rw [← cyclic_weight_period (cycleBits n p) (0 : ZMod p),
      cyclicWeight_eq_actual n p hret]
  simp

/-- A complete double copy within a coefficient-confined prefix gives
cyclic balance to the returned orbit, for every cyclic start and length. -/
theorem returned_orbit_cyclically_balanced (n L start p : ℕ) [NeZero p]
    (hnoexit : ¬ CoefficientExitWithin n L)
    (hfit : start + 2 * p ≤ L)
    (hret : orbit (orbit n start) p = orbit n start) :
    CyclicallyBalanced (cycleBits (orbit n start) p) := by
  intro s t a ha
  rw [cyclicWeight_eq_actual _ p hret s a,
      cyclicWeight_eq_actual _ p hret t a]
  have hb := actual_blocks_balanced n L (start + s.val) (start + t.val) a hnoexit
    (by have := ZMod.val_lt s; omega) (by have := ZMod.val_lt t; omega)
  rw [orbitWord_shift_general n start s.val a,
      orbitWord_shift_general n start t.val a] at hb
  exact_mod_cast hb

theorem orbitWord_length (n start len : ℕ) : (orbitWord n start len).length = len := by
  induction len generalizing start with
  | zero => rfl
  | succ len ih => simp [orbitWord, ih]

theorem orbitWord_getElem (n start len t : ℕ) (h : t < len) :
    (orbitWord n start len)[t]'(by simpa [orbitWord_length] using h) =
      decide (orbit n (start + t) % 2 = 1) := by
  induction len generalizing start t with
  | zero => omega
  | succ len ih =>
    cases t with
    | zero => simp [orbitWord]
    | succ t =>
      simpa [orbitWord, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using
        ih (start + 1) t (by omega)

theorem orbitWord_rotate (n p s : ℕ) [NeZero p] (hret : orbit n p = n) :
    (orbitWord n 0 p).rotate s = orbitWord n s p := by
  apply List.ext_getElem
  · simp [orbitWord_length]
  · intro k hk1 hk2
    have hp : 0 < p := Nat.pos_of_ne_zero (NeZero.ne p)
    have hk : k < p := by simpa [orbitWord_length] using hk2
    simp only [List.getElem_rotate, orbitWord_length]
    rw [orbitWord_getElem n 0 p ((k + s) % p) (Nat.mod_lt _ hp),
        orbitWord_getElem n s p k hk]
    simp only [Nat.zero_add, orbit_mod n p _ hret, Nat.add_comm k s]

theorem orbitWord_append (n start a b : ℕ) :
    orbitWord n start (a + b) = orbitWord n start a ++ orbitWord n (start + a) b := by
  induction a generalizing start with
  | zero => simp [orbitWord]
  | succ a ih =>
    have he : start + 1 + a = start + (a + 1) := by omega
    simp only [Nat.succ_add, orbitWord, List.cons_append]
    rw [ih, he]

theorem orbitWord_endpoints (n start p : ℕ) (hp : 2 ≤ p) :
    orbitWord n start p = decide (orbit n start % 2 = 1) ::
      (orbitWord n (start + 1) (p - 2) ++
        [decide (orbit n (start + (p - 1)) % 2 = 1)]) := by
  conv_lhs => rw [show p = ((p - 2) + 1) + 1 by omega]
  rw [orbitWord, orbitWord_append]
  have he : start + 1 + (p - 2) = start + (p - 1) := by omega
  simp [orbitWord, he]

theorem orbitWord_eq_of_pointwise (n s t len : ℕ)
    (h : ∀ i, i < len → (orbit n (s + i) % 2 = 1 ↔ orbit n (t + i) % 2 = 1)) :
    orbitWord n s len = orbitWord n t len := by
  apply List.ext_getElem
  · simp [orbitWord_length]
  · intro i hi1 hi2
    have hi : i < len := by simpa [orbitWord_length] using hi1
    rw [orbitWord_getElem n s len i hi, orbitWord_getElem n t len i hi]
    exact decide_eq_decide.mpr (h i hi)

/-- Endpoint-letter witnesses become the two explicit list rotations
needed by the integer cycle arithmetic. -/
theorem endpoint_letters_to_rotations (n p s t : ℕ) [NeZero p]
    (hp : 2 ≤ p) (hret : orbit n p = n)
    (hfs : cycleBits n p (s : ZMod p) = 1)
    (hft : cycleBits n p (t : ZMod p) = 0)
    (hls : cycleBits n p ((s : ZMod p) + (p - 1 : ℕ)) = 0)
    (hlt : cycleBits n p ((t : ZMod p) + (p - 1 : ℕ)) = 1)
    (hmid : ∀ i : ℕ, 0 < i → i + 1 < p →
      cycleBits n p ((s : ZMod p) + (i : ZMod p)) =
        cycleBits n p ((t : ZMod p) + (i : ZMod p))) :
    ∃ u : List Bool,
      (orbitWord n 0 p).rotate s = true :: (u ++ [false]) ∧
      (orbitWord n 0 p).rotate t = false :: (u ++ [true]) := by
  have hc (a b : ℕ) : cycleBits n p ((a : ZMod p) + (b : ZMod p)) =
      if orbit n (a + b) % 2 = 1 then 1 else 0 := by
    rw [← Nat.cast_add, cycleBits_natCast n p hret]
  rw [cycleBits_natCast n p hret] at hfs hft
  rw [hc] at hls hlt
  have hs1 : orbit n s % 2 = 1 := by split_ifs at hfs with h <;> simp_all
  have ht0 : ¬ orbit n t % 2 = 1 := by split_ifs at hft with h <;> simp_all
  have hs0 : ¬ orbit n (s + (p - 1)) % 2 = 1 := by split_ifs at hls with h <;> simp_all
  have ht1 : orbit n (t + (p - 1)) % 2 = 1 := by split_ifs at hlt with h <;> simp_all
  have hm : orbitWord n (s + 1) (p - 2) = orbitWord n (t + 1) (p - 2) := by
    apply orbitWord_eq_of_pointwise
    intro i hi
    have he := hmid (i + 1) (by omega) (by omega)
    rw [hc, hc] at he
    have hiff : (orbit n (s + (i + 1)) % 2 = 1) ↔
        (orbit n (t + (i + 1)) % 2 = 1) := by
      split_ifs at he with hs ht ht <;> simp_all
    simpa [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using hiff
  refine ⟨orbitWord n (s + 1) (p - 2), ?_, ?_⟩
  · rw [orbitWord_rotate n p s hret, orbitWord_endpoints n s p hp]
    simp [hs1, hs0]
  · rw [orbitWord_rotate n p t hret, orbitWord_endpoints n t p hp, ← hm]
    simp [ht0, ht1]

theorem balanced_cycle_rotations (n p : ℕ) [NeZero p]
    (hret : orbit n p = n)
    (hbal : CyclicallyBalanced (cycleBits n p))
    (hprim : NoShortPeriod (cycleBits n p))
    (hq0 : 0 < (orbitWord n 0 p).count true)
    (hqp : (orbitWord n 0 p).count true < p) :
    ∃ s t : ℕ, ∃ u : List Bool,
      (orbitWord n 0 p).rotate s = true :: (u ++ [false]) ∧
      (orbitWord n 0 p).rotate t = false :: (u ++ [true]) := by
  obtain ⟨s, hs, t, ht, hfs, hft, hls, hlt, hmid⟩ :=
    balanced_primitive_endpoint_letters (cycleBits n p) (cycleBits_binary n p)
      hbal hprim (cycleBits_total n p hret) hq0 hqp
  obtain ⟨u, hu, hv⟩ := endpoint_letters_to_rotations n p s t (by omega)
    hret hfs hft hls hlt hmid
  exact ⟨s, t, u, hu, hv⟩

/-- The full balanced primitive cycle-word exclusion once its actual
positive integer cycle certificate has been supplied. -/
theorem balanced_primitive_orbit_period_two (n p : ℕ) [NeZero p]
    (hret : orbit n p = n)
    (hbal : CyclicallyBalanced (cycleBits n p))
    (hprim : NoShortPeriod (cycleBits n p))
    (hq0 : 0 < (orbitWord n 0 p).count true)
    (hqp : (orbitWord n 0 p).count true < p)
    (hpos : 0 < bsDenominator p ((orbitWord n 0 p).count true))
    (hint : bsIsInteger p ((orbitWord n 0 p).count true) (orbitWord n 0 p)) :
    p = 2 ∧ (orbitWord n 0 p).count true = 1 := by
  obtain ⟨s, t, u, hu, hv⟩ := balanced_cycle_rotations n p hret hbal hprim hq0 hqp
  have hc := endpoint_rotations_force_period_two (orbitWord n 0 p) u s t hu hv
    (by simpa [orbitWord_length] using hpos) (by simpa [orbitWord_length] using hint)
  simpa [orbitWord_length] using hc.2

#print axioms returned_orbit_cyclically_balanced
#print axioms balanced_primitive_orbit_period_two
end HypothesisMCycleAdapter
