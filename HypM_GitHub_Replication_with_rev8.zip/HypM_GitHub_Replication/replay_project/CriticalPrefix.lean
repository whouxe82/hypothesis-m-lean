import MStatement
import PhaseCells

/-!
Exact coefficient dynamics and finite word structure for Hypothesis M.
This module supplies bridges from the frozen natural-number orbit to the
rational critical map. Every assertion is proved without additional axioms.
-/

namespace HypothesisMCritical
open HypothesisMTarget HypothesisMPhaseCells

def coefficient (n t : ℕ) : ℚ := (3 : ℚ) ^ oddCount n t / (2 : ℚ) ^ t

def orbitWord (n start : ℕ) : ℕ → List Bool
  | 0 => []
  | len + 1 => decide (orbit n start % 2 = 1) :: orbitWord n (start + 1) len

theorem coefficient_zero (n : ℕ) : coefficient n 0 = 1 := by
  simp [coefficient, oddCount]

theorem coefficient_pos (n t : ℕ) : 0 < coefficient n t := by
  unfold coefficient
  positivity

theorem coefficient_ne_three (n t : ℕ) : coefficient n t ≠ 3 := by
  intro h
  cases t with
  | zero => norm_num [coefficient, oddCount] at h
  | succ t =>
    have hp : (2 : ℚ) ^ (t + 1) ≠ 0 := by positivity
    have he := (div_eq_iff hp).mp h
    have heN : (3 : ℕ) ^ oddCount n (t + 1) = 3 * 2 ^ (t + 1) := by
      exact_mod_cast he
    have hm := congrArg (fun a : ℕ => a % 2) heN
    simp [Nat.pow_mod, pow_succ, Nat.mul_mod] at hm

theorem coefficient_gt_one (n t : ℕ) (ht : 0 < t)
    (h : 1 ≤ coefficient n t) : 1 < coefficient n t := by
  have hne : coefficient n t ≠ 1 := by
    intro he
    have hp : (2 : ℚ) ^ t ≠ 0 := by positivity
    have heq := (div_eq_iff hp).mp he
    have heN : (3 : ℕ) ^ oddCount n t = 2 ^ t := by
      norm_num at heq
      exact_mod_cast heq
    obtain ⟨t, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : t ≠ 0)
    have hm := congrArg (fun a : ℕ => a % 2) heN
    simp [Nat.pow_mod, pow_succ] at hm
  exact lt_of_le_of_ne h hne.symm

theorem coefficient_bounds_of_no_exit (n L : ℕ)
    (h : ¬ CoefficientExitWithin n L) (t : ℕ) (ht : t ≤ L) :
    1 ≤ coefficient n t ∧ coefficient n t < 3 := by
  by_cases hz : t = 0
  · subst t
    simp [coefficient_zero]
  have ht1 : 1 ≤ t := by omega
  have hlo : (2 : ℕ) ^ t ≤ (3 : ℕ) ^ oddCount n t := by
    by_contra hh
    exact h ⟨t, ht1, ht, Or.inl (by omega)⟩
  have hhi : (3 : ℕ) ^ oddCount n t ≤ 3 * (2 : ℕ) ^ t := by
    by_contra hh
    exact h ⟨t, ht1, ht, Or.inr (by omega)⟩
  have hp : (0 : ℚ) < 2 ^ t := by positivity
  have hl : (1 : ℚ) ≤ coefficient n t := by
    unfold coefficient
    apply (le_div_iff₀ hp).2
    norm_num
    exact_mod_cast hlo
  have hu : coefficient n t ≤ 3 := by
    unfold coefficient
    apply (div_le_iff₀ hp).2
    exact_mod_cast hhi
  exact ⟨hl, lt_of_le_of_ne hu (coefficient_ne_three n t)⟩

theorem coefficient_succ (n t : ℕ) :
    coefficient n (t + 1) =
      if orbit n t % 2 = 1 then 3 * coefficient n t / 2
      else coefficient n t / 2 := by
  by_cases h : orbit n t % 2 = 1
  · simp [coefficient, oddCount, h, pow_succ]
    ring
  · simp [coefficient, oddCount, h, pow_succ]
    ring

theorem coefficient_step_of_confined (n t : ℕ)
    (hlo : 1 ≤ coefficient n (t + 1))
    (hhi : coefficient n (t + 1) < 3) :
    criticalBit (coefficient n t) = decide (orbit n t % 2 = 1) ∧
    criticalStep (coefficient n t) = coefficient n (t + 1) := by
  have hs := coefficient_succ n t
  by_cases h : orbit n t % 2 = 1
  · simp only [h, ↓reduceIte] at hs
    have hc : coefficient n t < 2 := by linarith
    simp [criticalBit, criticalStep, h, hc, hs]
  · simp only [h, ↓reduceIte] at hs
    have hc : ¬ coefficient n t < 2 := by linarith
    simp [criticalBit, criticalStep, h, hc, hs]

theorem orbitWord_eq_critical (n start len : ℕ)
    (hconf : ∀ t, start < t → t ≤ start + len →
      1 ≤ coefficient n t ∧ coefficient n t < 3) :
    orbitWord n start len = parityWord len (coefficient n start) := by
  induction len generalizing start with
  | zero => rfl
  | succ len ih =>
    have hc := hconf (start + 1) (by omega) (by omega)
    have hs := coefficient_step_of_confined n start hc.1 hc.2
    rw [orbitWord, parityWord, hs.1, hs.2]
    congr 1
    apply ih
    intro t ht hu
    exact hconf t (by omega) (by omega)

theorem same_actual_six_diameter (n i j : ℕ)
    (hi : ∀ t, i ≤ t → t ≤ i + 6 → 1 ≤ coefficient n t ∧ coefficient n t < 3)
    (hj : ∀ t, j ≤ t → t ≤ j + 6 → 1 ≤ coefficient n t ∧ coefficient n t < 3)
    (hword : orbitWord n i 6 = orbitWord n j 6) :
    |coefficient n i - coefficient n j| ≤ 4 / 9 := by
  apply sameWord_diameter _ _ (hi i le_rfl (by omega)).1
    (hi i le_rfl (by omega)).2 (hj j le_rfl (by omega)).1
    (hj j le_rfl (by omega)).2
  rw [← orbitWord_eq_critical n i 6 (fun t ht hu => hi t (by omega) hu),
      ← orbitWord_eq_critical n j 6 (fun t ht hu => hj t (by omega) hu)]
  exact hword

def criticalCount : ℕ → ℚ → ℕ
  | 0, _ => 0
  | len + 1, c => (if c < 2 then 1 else 0) + criticalCount len (criticalStep c)

theorem criticalStep_bounds (c : ℚ) (hl : 1 ≤ c) (hu : c < 3) :
    1 ≤ criticalStep c ∧ criticalStep c < 3 := by
  unfold criticalStep
  split_ifs with h <;> constructor <;> linarith

/-- Prefix odd counts decrease with phase and have total variation at most one.
The proof is algebraic and does not use logarithms or a word-classification theorem. -/
theorem criticalCount_order (len : ℕ) (c d : ℚ)
    (hc : 1 ≤ c) (hcd : c ≤ d) (hd : d < 3) :
    criticalCount len d ≤ criticalCount len c ∧
    criticalCount len c ≤ criticalCount len d + 1 := by
  induction len generalizing c d with
  | zero => simp [criticalCount]
  | succ len ih =>
    have hd1 : 1 ≤ d := le_trans hc hcd
    have hc3 : c < 3 := lt_of_le_of_lt hcd hd
    have hcb := criticalStep_bounds c hc hc3
    have hdb := criticalStep_bounds d hd1 hd
    by_cases hcl : c < 2
    · by_cases hdl : d < 2
      · have hord : criticalStep c ≤ criticalStep d := by
          simp only [criticalStep, hcl, hdl, ↓reduceIte]
          linarith
        have h := ih _ _ hcb.1 hord hdb.2
        simp only [criticalCount, hcl, hdl, ↓reduceIte]
        omega
      · have hord : criticalStep d ≤ criticalStep c := by
          simp only [criticalStep, hcl, hdl, ↓reduceIte]
          linarith
        have h := ih _ _ hdb.1 hord hcb.2
        simp only [criticalCount, hcl, hdl, ↓reduceIte]
        omega
    · have hdl : ¬ d < 2 := by linarith
      have hord : criticalStep c ≤ criticalStep d := by
        simp only [criticalStep, hcl, hdl, ↓reduceIte]
        linarith
      have h := ih _ _ hcb.1 hord hdb.2
      simp only [criticalCount, hcl, hdl, ↓reduceIte]
      omega

theorem criticalCount_balanced (len : ℕ) (c d : ℚ)
    (hc1 : 1 ≤ c) (hc3 : c < 3) (hd1 : 1 ≤ d) (hd3 : d < 3) :
    criticalCount len c ≤ criticalCount len d + 1 := by
  rcases le_total c d with h | h
  · exact (criticalCount_order len c d hc1 h hd3).2
  · exact (criticalCount_order len d c hd1 h hc3).1.trans (Nat.le_add_right _ _)

theorem parityWord_eq_of_counts (len : ℕ) (c d : ℚ)
    (heq : ∀ t, t ≤ len → criticalCount t c = criticalCount t d) :
    parityWord len c = parityWord len d := by
  induction len generalizing c d with
  | zero => rfl
  | succ len ih =>
    have hone := heq 1 (by omega)
    have hb : (if c < 2 then (1 : ℕ) else 0) = (if d < 2 then 1 else 0) := by
      simpa [criticalCount] using hone
    have hbit : criticalBit c = criticalBit d := by
      unfold criticalBit
      split_ifs at hb ⊢ <;> simp_all
    rw [parityWord, parityWord, hbit]
    congr 1
    apply ih
    intro t ht
    have h := heq (t + 1) (by omega)
    simp only [criticalCount] at h
    omega

open scoped BigOperators

def phaseRank (len : ℕ) (c : ℚ) : ℕ :=
  ∑ i ∈ Finset.range len, (criticalCount (i + 1) 1 - criticalCount (i + 1) c)

theorem phaseRank_le (len : ℕ) (c : ℚ) (hc1 : 1 ≤ c) (hc3 : c < 3) :
    phaseRank len c ≤ len := by
  have hb (i : ℕ) : criticalCount (i + 1) 1 - criticalCount (i + 1) c ≤ 1 := by
    have h := (criticalCount_order (i + 1) 1 c le_rfl hc1 hc3).2
    omega
  calc
    phaseRank len c ≤ ∑ _i ∈ Finset.range len, (1 : ℕ) :=
      Finset.sum_le_sum (fun i _ => hb i)
    _ = len := by simp

theorem equal_rank_equal_word (len : ℕ) (c d : ℚ)
    (hc1 : 1 ≤ c) (hc3 : c < 3) (hd1 : 1 ≤ d) (hd3 : d < 3)
    (hrank : phaseRank len c = phaseRank len d) :
    parityWord len c = parityWord len d := by
  have ordered (c d : ℚ) (hc1 : 1 ≤ c) (hc3 : c < 3)
      (hd1 : 1 ≤ d) (hd3 : d < 3) (hcd : c ≤ d)
      (he : phaseRank len c = phaseRank len d) :
      parityWord len c = parityWord len d := by
    apply parityWord_eq_of_counts
    intro t ht
    cases t with
    | zero => rfl
    | succ t =>
      have hm (i : ℕ) (_ : i ∈ Finset.range len) :
          criticalCount (i + 1) 1 - criticalCount (i + 1) c ≤
          criticalCount (i + 1) 1 - criticalCount (i + 1) d := by
        have h := (criticalCount_order (i + 1) c d hc1 hcd hd3).1
        omega
      have heq := (Finset.sum_eq_sum_iff_of_le hm).mp he t (Finset.mem_range.mpr (by omega))
      have hc := (criticalCount_order (t + 1) 1 c le_rfl hc1 hc3).1
      have hd := (criticalCount_order (t + 1) 1 d le_rfl hd1 hd3).1
      omega
  rcases le_total c d with h | h
  · exact ordered c d hc1 hc3 hd1 hd3 h hrank
  · exact (ordered d c hd1 hd3 hc1 hc3 h hrank.symm).symm

theorem critical_repeated_blocks (len : ℕ) (c : ℕ → ℚ)
    (hc : ∀ i, i ≤ len + 1 → 1 ≤ c i ∧ c i < 3) :
    ∃ i j : ℕ, i < j ∧ j ≤ len + 1 ∧ parityWord len (c i) = parityWord len (c j) := by
  classical
  have hm : Set.MapsTo (fun i => phaseRank len (c i))
      (Finset.range (len + 2)) (Finset.range (len + 1)) := by
    intro i hi
    have hib : i ≤ len + 1 := by have := Finset.mem_range.mp hi; omega
    have hb := phaseRank_le len (c i) (hc i hib).1 (hc i hib).2
    apply Finset.mem_range.mpr
    change phaseRank len (c i) < len + 1
    omega
  obtain ⟨i, hi, j, hj, hne, he⟩ := Finset.exists_ne_map_eq_of_card_lt_of_maps_to
    (by simp : (Finset.range (len + 1)).card < (Finset.range (len + 2)).card) hm
  have hib : i ≤ len + 1 := by have := Finset.mem_range.mp hi; omega
  have hjb : j ≤ len + 1 := by have := Finset.mem_range.mp hj; omega
  have hw := equal_rank_equal_word len (c i) (c j) (hc i hib).1 (hc i hib).2
    (hc j hjb).1 (hc j hjb).2 he
  rcases lt_or_gt_of_ne hne with hij | hji
  · exact ⟨i, j, hij, hjb, hw⟩
  · exact ⟨j, i, hji, hib, hw.symm⟩

theorem actual_repeated_blocks (n L len : ℕ)
    (h : ¬ CoefficientExitWithin n L) (hlen : 2 * len + 1 ≤ L) :
    ∃ i j : ℕ, i < j ∧ j ≤ len + 1 ∧ orbitWord n i len = orbitWord n j len := by
  have hb (i : ℕ) (hi : i ≤ len + 1) :
      1 ≤ coefficient n i ∧ coefficient n i < 3 :=
    coefficient_bounds_of_no_exit n L h i (by omega)
  obtain ⟨i, j, hij, hj, hw⟩ := critical_repeated_blocks len (coefficient n) hb
  refine ⟨i, j, hij, hj, ?_⟩
  rw [orbitWord_eq_critical n i len, orbitWord_eq_critical n j len]
  · exact hw
  · intro t ht hu
    exact coefficient_bounds_of_no_exit n L h t (by omega)
  · intro t ht hu
    exact coefficient_bounds_of_no_exit n L h t (by omega)

theorem orbit_shift (n s t : ℕ) : orbit (orbit n s) t = orbit n (s + t) := by
  induction t with
  | zero => simp [orbit]
  | succ t ih => simp [orbit, ih, Nat.add_assoc]

theorem orbitWord_shift_general (n s t len : ℕ) :
    orbitWord n (s + t) len = orbitWord (orbit n s) t len := by
  induction len generalizing t with
  | zero => rfl
  | succ len ih =>
    simp only [orbitWord, orbit_shift]
    rw [show s + t + 1 = s + (t + 1) by omega, ih]

theorem orbitWord_shift (n start len : ℕ) :
    orbitWord n start len = orbitWord (orbit n start) 0 len := by
  simpa using orbitWord_shift_general n start 0 len

theorem orbitWord_take (n start len small : ℕ) (h : small ≤ len) :
    (orbitWord n start len).take small = orbitWord n start small := by
  induction small generalizing start len with
  | zero => simp [orbitWord]
  | succ small ih =>
    cases len with
    | zero => omega
    | succ len =>
      simp only [orbitWord, List.take_succ_cons]
      congr 1
      exact ih (start + 1) len (by omega)

theorem same_orbitWord_parity (n i j len : ℕ)
    (hword : orbitWord n i len = orbitWord n j len) (t : ℕ) (ht : t < len) :
    orbit n (i + t) % 2 = orbit n (j + t) % 2 := by
  induction len generalizing i j t with
  | zero => omega
  | succ len ih =>
    have hh := List.cons.inj hword
    cases t with
    | zero =>
      have hhead := hh.1
      have hi2 := Nat.mod_lt (orbit n i) (by decide : 0 < 2)
      have hj2 := Nat.mod_lt (orbit n j) (by decide : 0 < 2)
      by_cases hi : orbit n i % 2 = 1 <;>
        by_cases hj : orbit n j % 2 = 1 <;> simp [hi, hj] at hhead ⊢ <;> omega
    | succ t =>
      have hp := ih (i + 1) (j + 1) hh.2 t (by omega)
      simpa [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using hp

theorem parityWord_count (len : ℕ) (c : ℚ) :
    (parityWord len c).count true = criticalCount len c := by
  induction len generalizing c with
  | zero => rfl
  | succ len ih =>
    by_cases h : c < 2 <;>
      simp [parityWord, criticalCount, criticalBit, h, ih, Nat.add_comm]

theorem orbitWord_count_add (n start len : ℕ) :
    oddCount n (start + len) = oddCount n start + (orbitWord n start len).count true := by
  induction len generalizing start with
  | zero => simp [orbitWord]
  | succ len ih =>
    rw [show start + (len + 1) = (start + 1) + len by omega, ih, oddCount]
    by_cases h : orbit n start % 2 = 1 <;>
      simp [orbitWord, h, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]

theorem orbitWord_count_eq_critical (n L start len : ℕ)
    (h : ¬ CoefficientExitWithin n L) (hlen : start + len ≤ L) :
    (orbitWord n start len).count true = criticalCount len (coefficient n start) := by
  rw [orbitWord_eq_critical n start len, parityWord_count]
  intro t ht hu
  exact coefficient_bounds_of_no_exit n L h t (by omega)

/-- Any equal-length blocks contained in a coefficient-confined prefix are balanced. -/
theorem actual_blocks_balanced (n L s t len : ℕ)
    (h : ¬ CoefficientExitWithin n L) (hs : s + len ≤ L) (ht : t + len ≤ L) :
    (orbitWord n s len).count true ≤ (orbitWord n t len).count true + 1 := by
  rw [orbitWord_count_eq_critical n L s len h hs,
      orbitWord_count_eq_critical n L t len h ht]
  have hsb := coefficient_bounds_of_no_exit n L h s (by omega)
  have htb := coefficient_bounds_of_no_exit n L h t (by omega)
  exact criticalCount_balanced len _ _ hsb.1 hsb.2 htb.1 htb.2

end HypothesisMCritical
