import OrbitArithmetic
import CriticalPrefix
import HypothesisMCore

namespace HypothesisMAffine
open HypothesisMTarget HypothesisMOrbit HypothesisMCritical

def normalized (n t : ℕ) : ℚ := (orbit n t : ℚ) / coefficient n t

theorem shortcut_cast (n : ℕ) : (shortcut n : ℚ) =
    if n % 2 = 1 then (3 * (n : ℚ) + 1) / 2 else (n : ℚ) / 2 := by
  by_cases h : n % 2 = 1
  · rw [if_pos h]
    have hn : 2 * (shortcut n : ℚ) = 3 * (n : ℚ) + 1 := by
      exact_mod_cast shortcut_odd n h
    linarith
  · rw [if_neg h]
    have he : n % 2 = 0 := by omega
    have hn : 2 * (shortcut n : ℚ) = (n : ℚ) := by
      exact_mod_cast shortcut_even n he
    linarith

theorem normalized_zero (n : ℕ) : normalized n 0 = n := by
  simp [normalized, orbit, coefficient_zero]

theorem normalized_succ (n t : ℕ) : normalized n (t + 1) =
    normalized n t + if orbit n t % 2 = 1 then 1 / (3 * coefficient n t) else 0 := by
  have hc : coefficient n t ≠ 0 := ne_of_gt (coefficient_pos n t)
  unfold normalized
  rw [coefficient_succ, orbit, shortcut_cast]
  by_cases h : orbit n t % 2 = 1
  · simp only [h, ↓reduceIte]
    field_simp
    <;> ring
  · simp only [h, ↓reduceIte, add_zero]
    field_simp

theorem normalized_bounds (n t : ℕ)
    (hconf : ∀ s, s ≤ t → 1 ≤ coefficient n s) :
    (n : ℚ) ≤ normalized n t ∧ normalized n t ≤ (n : ℚ) + (t : ℚ) / 3 := by
  induction t with
  | zero => simp [normalized_zero]
  | succ t ih =>
    have ht := ih (fun s hs => hconf s (by omega))
    have hc := hconf t (by omega)
    rw [normalized_succ]
    by_cases h : orbit n t % 2 = 1
    · rw [if_pos h]
      have hp : (0 : ℚ) < 3 * coefficient n t := by linarith
      have hpos : (0 : ℚ) ≤ 1 / (3 * coefficient n t) := by positivity
      have hle : (1 : ℚ) / (3 * coefficient n t) ≤ 1 / 3 := by
        apply (div_le_iff₀ hp).2
        linarith
      push_cast
      constructor <;> linarith
    · rw [if_neg h]
      push_cast
      constructor <;> linarith

/-- The affine error of an actual confined orbit lies between zero and time. -/
theorem affine_error_bounds (n t : ℕ)
    (hconf : ∀ s, s ≤ t → 1 ≤ coefficient n s)
    (hupper : coefficient n t ≤ 3) :
    ∃ e : ℚ, 0 ≤ e ∧ e ≤ (t : ℚ) ∧
      (orbit n t : ℚ) = coefficient n t * (n : ℚ) + e := by
  have hb := normalized_bounds n t hconf
  have hc := coefficient_pos n t
  refine ⟨coefficient n t * (normalized n t - (n : ℚ)), ?_, ?_, ?_⟩
  · exact mul_nonneg hc.le (sub_nonneg.mpr hb.1)
  · have hmul := mul_le_mul_of_nonneg_left hb.2 hc.le
    have htime : (0 : ℚ) ≤ (t : ℚ) := by positivity
    have huppermul := mul_le_mul_of_nonneg_right hupper htime
    nlinarith
  · unfold normalized
    field_simp
    <;> ring

theorem orbit_gt_seed (n t : ℕ) (hn : 0 < n) (ht : 0 < t)
    (hconf : ∀ s, s ≤ t → 1 ≤ coefficient n s)
    (hupper : coefficient n t ≤ 3) : n < orbit n t := by
  obtain ⟨e, he0, het, heq⟩ := affine_error_bounds n t hconf hupper
  have hc := coefficient_gt_one n t ht (hconf t le_rfl)
  have hnq : (0 : ℚ) < (n : ℚ) := by exact_mod_cast hn
  have hh : (n : ℚ) < (orbit n t : ℚ) := by nlinarith
  exact_mod_cast hh

/-- The exact 4/9 cell estimate and the affine error bound force a return.
All hypotheses refer to actual shortcut-Collatz states or their coefficients. -/
theorem collision_from_diameter (n i j k : ℕ)
    (hk : 6 ≤ k) (hij : i ≤ j) (hj : j ≤ k + 1)
    (hn : n < 2 ^ (k + 1))
    (hconf : ∀ s, s ≤ j → 1 ≤ coefficient n s ∧ coefficient n s < 3)
    (hdia : |coefficient n i - coefficient n j| ≤ 4 / 9)
    (hpar : ∀ t < k, orbit n (i + t) % 2 = orbit n (j + t) % 2) :
    orbit n i = orbit n j := by
  obtain ⟨ei, hei0, heii, heqi⟩ := affine_error_bounds n i
    (fun s hs => (hconf s (by omega)).1) (hconf i hij).2.le
  obtain ⟨ej, hej0, hejj, heqj⟩ := affine_error_bounds n j
    (fun s hs => (hconf s hs).1) (hconf j le_rfl).2.le
  have hc := abs_le.mp hdia
  have hnn : (0 : ℚ) ≤ (n : ℚ) := by positivity
  have hcL := mul_le_mul_of_nonneg_right hc.1 hnn
  have hcU := mul_le_mul_of_nonneg_right hc.2 hnn
  have hji : (i : ℚ) ≤ (j : ℚ) := by exact_mod_cast hij
  have hjk : (j : ℚ) ≤ (k : ℚ) + 1 := by exact_mod_cast hj
  have hnq : (n : ℚ) < 2 * (2 : ℚ) ^ k := by
    have hh : (n : ℚ) < (2 : ℚ) ^ (k + 1) := by exact_mod_cast hn
    simpa [pow_succ, mul_comm] using hh
  have hmargin : 9 * ((k : ℚ) + 1) < (2 : ℚ) ^ k := by
    exact_mod_cast HypothesisM.collision_margin k hk
  have hlow : -((2 : ℚ) ^ k) < (orbit n i : ℚ) - (orbit n j : ℚ) := by
    nlinarith
  have hupp : (orbit n i : ℚ) - (orbit n j : ℚ) < (2 : ℚ) ^ k := by
    nlinarith
  apply collision_of_close n i j k hpar
  have habs : |(orbit n i : ℚ) - (orbit n j : ℚ)| < (2 : ℚ) ^ k :=
    abs_lt.mpr ⟨hlow, hupp⟩
  exact_mod_cast habs

#print axioms affine_error_bounds
#print axioms orbit_gt_seed
#print axioms collision_from_diameter
end HypothesisMAffine
