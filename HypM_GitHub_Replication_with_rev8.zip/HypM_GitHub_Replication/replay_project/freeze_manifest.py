#!/usr/bin/env python3
"""Maintainer-only source freeze; do not run this to bypass a replay mismatch.

This is separate from replay.py. A verifier should use the supplied manifest.
After an authorized source change, the maintainer can deliberately create a new
freeze and preserve the previous package/version separately.
"""
from pathlib import Path
import datetime as dt
import hashlib
import json

root = Path(__file__).resolve().parent
paths = sorted(root.glob("*.lean"))
paths += sorted((root / "Knight2026").glob("*.lean"))
paths += sorted((root / "provenance").glob("*"))
paths += [root / x for x in ["lean-toolchain", "lakefile.toml", "lake-manifest.json",
    "DEPENDENCY_PINS.json", "FINAL_THEOREMS.json", "LICENSE.Apache-2.0",
    "README.md", "replay.py", "freeze_manifest.py"]]
rows = [{"path": str(p.relative_to(root)), "bytes": p.stat().st_size,
         "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths if p.is_file()]
record = {"created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
          "algorithm": "SHA-256", "files": sorted(rows, key=lambda x: x["path"])}
(root / "SOURCE_MANIFEST.json").write_text(json.dumps(record, indent=2) + "\n")
print(f"Frozen {len(rows)} files. Preserve this manifest with its source package.")
