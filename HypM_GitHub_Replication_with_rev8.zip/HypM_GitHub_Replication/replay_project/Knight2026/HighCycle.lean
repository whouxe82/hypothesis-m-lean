/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Knight2026.HighCycle

The high-cycle (Christoffel word) vector and its properties.

## Overview

This file defines:
1. The high-cycle vector `vh` with 1s at positions `⌊k·i/x⌋` (Definition 4.1)
2. The structure `vh = 1·u·0` and `vh^R = 0·u·1` (Theorem 5.2)
3. The key algebraic identity linking `g(vh)` and `g(vh^R)` via the inner word u
4. Theorems 4.4, 4.6, 4.7 from Halbeisen-Hungerbühler (axiomatized)

## Design Notes

### Christoffel word representation
The high-cycle vector is defined by its 1-positions: `d_i = ⌊k·i/x⌋` for i = 0, ..., x-1.
We define this as a function computing the bit list directly. The floor-function definition
makes closed-form simplification impossible (unlike the circuit), but we never need a
closed form -- the proof works by structural decomposition into `1·u·0`.

### The vh = 1u0 decomposition is the crux
The entire proof of Theorem 5.4 rests on expressing `g(vh)` and `g(vh^R)` in terms of
`g(u)`. Specifically:
  - `g(vh) = g(1·u·0) = 2·g(u) + 3^{x-1}`     (shift u right by 1, add leading 1)
  - `g(vh^R) = g(0·u·1) = 6·g(u) + 2^{k-1}`   (shift u right by 1 AND multiply by 3
                                                   for the trailing 1, add 2^{k-1})

These identities are the key lemmas. We state them precisely and their proofs require
careful manipulation of the `onePositions`/`bsNumerator` definitions.

### Why axiomatize the Halbeisen-Hungerbühler results?
Theorems 4.4 (vh minimizes f among rotations), 4.6 (f(vh) maximized at k = ⌈x·log₂3⌉),
and 4.7 (vh gives the high cycle) establish that vh is indeed the high-cycle vector.
These are combinatorial/analytic results from a different paper. The main theorem 5.4
only needs: "IF f(vh) and f(vh^R) are both integers, contradiction." The identification
of vh with the high cycle provides the mathematical context but is not needed for the
algebraic contradiction.

We axiomatize these so that the full theorem statement is faithful to the paper, while
keeping the proof effort focused on the elementary algebraic core.
-/

import Knight2026.Defs
import Knight2026.ParityVec
import Knight2026.BsLemmas

/-- Auxiliary: the floor map i ↦ k*i/x is strictly monotone when k > x > 0. -/
private theorem floor_strictMono (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (i j : ℕ) (hij : i < j) : k * i / x < k * j / x := by
  have h2 : x ≤ k * (j - i) := by nlinarith [show 1 ≤ j - i from by omega]
  have h3 : 1 ≤ k * (j - i) / x := (Nat.one_le_div_iff hx).mpr h2
  have h4 : k * i / x + k * (j - i) / x ≤ k * j / x := by
    calc k * i / x + k * (j - i) / x
        ≤ (k * i + k * (j - i)) / x := Nat.add_div_le_add_div _ _ _
      _ = k * j / x := by rw [← Nat.left_distrib, Nat.add_sub_cancel' (le_of_lt hij)]
  omega

/-! ## The High-Cycle (Christoffel) Vector -/

/-- The 1-positions of the high-cycle vector: `d_i = ⌊k·i/x⌋` for i = 0, ..., x-1.
    Returns the sorted list of positions where the Christoffel word has a 1.

    **Requires** x > 0 (a cycle must have at least one odd step). -/
def highCyclePositions (k x : ℕ) : List ℕ :=
  (List.range x).map (fun i => (k * i) / x)

/-- Build the high-cycle bit vector from its 1-positions.
    Position j gets `true` iff j ∈ highCyclePositions k x. -/
def highCycleBits (k x : ℕ) : List Bool :=
  (List.range k).map (fun j => j ∈ highCyclePositions k x)

/-- The high-cycle vector has the correct length. -/
theorem highCycleBits_length (k x : ℕ) :
    (highCycleBits k x).length = k := by
  simp [highCycleBits]

/-- The high-cycle vector has exactly x ones.
    This requires k and x to be coprime (aperiodic Christoffel word).

    When gcd(k,x) > 1, the Christoffel word is periodic and we can reduce to the
    aperiodic case. For the main theorem, we handle aperiodicity separately. -/
theorem highCycleBits_count (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (highCycleBits k x).count true = x := by
  simp only [highCycleBits, List.count_eq_countP, List.countP_map, Function.comp_def]
  conv_lhs => arg 1; ext j; rw [beq_true]
  rw [List.countP_eq_length_filter]
  have hnodup_pos : (highCyclePositions k x).Nodup := by
    apply List.Nodup.map _ List.nodup_range
    intro a b hab
    rcases lt_trichotomy a b with h | h | h
    · exact absurd hab (ne_of_lt (floor_strictMono k x hx hxk a b h))
    · exact h
    · exact absurd hab (ne_of_gt (floor_strictMono k x hx hxk b a h))
  have hlt : ∀ p ∈ highCyclePositions k x, p < k := by
    intro p hp
    simp only [highCyclePositions, List.mem_map, List.mem_range] at hp
    obtain ⟨i, hi, rfl⟩ := hp
    exact Nat.div_lt_of_lt_mul (by nlinarith)
  have hperm : List.Perm
      ((List.range k).filter (fun j => decide (j ∈ highCyclePositions k x)))
      (highCyclePositions k x) := by
    rw [List.perm_ext_iff_of_nodup (List.Nodup.filter _ List.nodup_range) hnodup_pos]
    intro a
    simp only [List.mem_filter, List.mem_range, decide_eq_true_eq]
    exact ⟨fun ⟨_, h⟩ => h, fun h => ⟨hlt a h, h⟩⟩
  rw [hperm.length_eq]
  simp [highCyclePositions]

/-- Build a ParityVec for the high cycle. -/
def highCycleVec (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) (hpos : 3 ^ x < 2 ^ k) : ParityVec k x where
  bits := highCycleBits k x
  length_eq := highCycleBits_length k x
  count_eq := highCycleBits_count k x hx hxk hcop
  pos_denom := hpos

/-! ## Christoffel Word Structure: vh = 1·u·0 (Theorem 5.2) -/

/-- The first position is always 0: `d_0 = ⌊k·0/x⌋ = 0`. -/
theorem highCycle_first_pos (k x : ℕ) (hx : 0 < x) :
    (k * 0) / x = 0 := by
  simp

/-- **Theorem 5.2 (part 1).** The high-cycle vector starts with `true`.
    Since d_0 = 0, position 0 is a 1-position. -/
theorem highCycleBits_head (k x : ℕ) (hx : 0 < x) (hk : 0 < k) :
    (highCycleBits k x).head? = some true := by
  simp only [highCycleBits, List.head?_map, List.head?_range, show k ≠ 0 from by omega,
    ↓reduceIte, Option.map]
  congr 1
  simp only [decide_eq_true_eq, highCyclePositions, List.mem_map, List.mem_range]
  exact ⟨0, hx, by simp⟩

/-- **Theorem 5.2 (part 2).** The high-cycle vector ends with `false`.
    Position k-1 is never a 1-position (when k and x are coprime and x < k). -/
theorem highCycleBits_last (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (highCycleBits k x).getLast? = some false := by
  simp only [highCycleBits, List.getLast?_map, List.getLast?_range, show k ≠ 0 from by omega,
    ↓reduceIte, Option.map]
  congr 1
  simp only [decide_eq_false_iff_not, highCyclePositions, List.mem_map, List.mem_range]
  intro ⟨i, hi, heq⟩
  obtain ⟨k', rfl⟩ : ∃ k', k = k' + 1 := ⟨k - 1, by omega⟩
  have h1 : k' * x ≤ (k' + 1) * i := by
    simp only [Nat.add_sub_cancel] at heq
    calc k' * x = ((k' + 1) * i / x) * x := by rw [heq]
      _ ≤ (k' + 1) * i := Nat.div_mul_le_self ((k' + 1) * i) x
  have h2 : (k' + 1) * (i + 1) ≤ (k' + 1) * x := Nat.mul_le_mul_left (k' + 1) (by omega)
  nlinarith

/-- **Theorem 5.2 (combined).** `vh = 1·u·0` -/
theorem highCycleBits_form_1u0 (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    hasForm_1u0 (highCycleBits k x) := by
  refine ⟨highCycleBits_head k x hx (by omega), highCycleBits_last k x hx hxk hcop, ?_⟩
  rw [highCycleBits_length]; omega

/-- **Theorem 5.2 (reverse).** `vh^R = 0·u^R·1`, i.e., `vh^R = 0·u·1`
    (Note: u is actually a palindrome, so u^R = u, but we don't need this.) -/
theorem highCycleBits_rev_form_0u1 (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    hasForm_0u1 (highCycleBits k x).reverse := by
  refine ⟨?_, ?_, ?_⟩
  · rw [List.head?_reverse]
    exact highCycleBits_last k x hx hxk hcop
  · rw [List.getLast?_reverse]
    exact highCycleBits_head k x hx (by omega)
  · rw [List.length_reverse, highCycleBits_length]; omega

/-! ## Theorem 5.1: vh^R is a rotation of vh -/

-- Characterization: j ∈ positions ↔ ((j+1)*x-1) % k < x
set_option maxHeartbeats 6400000 in
private lemma cohn_fwd_char (k x i j : ℕ) (hx : 0 < x) (hxk : x < k)
    (hi : i < x) (hjk : j < k) (hji : k * i / x = j) :
    ((j + 1) * x - 1) % k < x := by
  have h_lo : j * x ≤ k * i := by
    have := Nat.div_mul_le_self (k * i) x; rw [hji] at this; linarith
  have h_hi : k * i < j * x + x := by
    have := Nat.lt_div_mul_add hx (a := k * i); rw [hji] at this; linarith
  have h1 : k * i < (j + 1) * x := by linarith
  have h2 : (j + 1) * x ≤ k * i + x := by linarith
  have h_sub : (j + 1) * x - 1 + 1 = (j + 1) * x :=
    Nat.succ_pred_eq_of_pos (Nat.mul_pos (by omega) hx)
  have h_comm : i * k = k * i := Nat.mul_comm i k
  have h3 : i * k ≤ (j + 1) * x - 1 := by omega
  have h_ik : (i + 1) * k = k * i + k := by ring
  have h4 : (j + 1) * x - 1 < (i + 1) * k := by omega
  rw [Nat.mod_def, Nat.div_eq_of_lt_le h3 h4]; omega

set_option maxHeartbeats 6400000 in
private lemma cohn_bwd_char (k x j : ℕ) (hx : 0 < x) (hxk : x < k)
    (hjk : j < k) (hcop : Nat.Coprime k x)
    (hmod : ((j + 1) * x - 1) % k < x) :
    ∃ i, i < x ∧ k * i / x = j := by
  set m := ((j + 1) * x - 1) / k
  set s := ((j + 1) * x - 1) % k
  have hs_lt : s < x := hmod
  have h_sub : (j + 1) * x - 1 + 1 = (j + 1) * x :=
    Nat.succ_pred_eq_of_pos (Nat.mul_pos (by omega) hx)
  have h_eq : k * m + s = (j + 1) * x - 1 := by
    have := Nat.div_add_mod ((j + 1) * x - 1) k; omega
  have hm_lt : m < x := by
    by_contra hm; push_neg at hm
    have : k * x ≤ k * m := Nat.mul_le_mul_left k hm
    have : (j + 1) * x ≤ k * x := Nat.mul_le_mul_right x (by omega); omega
  have : (j + 1) * x = j * x + x := by ring
  exact ⟨m, hm_lt, Nat.div_eq_of_lt_le (by omega) (by omega)⟩

set_option maxHeartbeats 6400000 in
private lemma cohn_mem_hcp (k x j : ℕ) (hx : 0 < x) (hxk : x < k)
    (hjk : j < k) (hcop : Nat.Coprime k x) :
    j ∈ highCyclePositions k x ↔ ((j + 1) * x - 1) % k < x := by
  simp only [highCyclePositions, List.mem_map, List.mem_range]
  exact ⟨fun ⟨i, hi, hji⟩ => cohn_fwd_char k x i j hx hxk hi hjk hji,
         fun h => cohn_bwd_char k x j hx hxk hjk hcop h⟩

-- Complement: a < x ↔ b < x when (a+b) % k = x-1
private lemma cohn_compl_lt {a b x k : ℕ} (ha : a < k) (hb : b < k)
    (hx : 0 < x) (hxk : x ≤ k) (hsum : (a + b) % k = x - 1) :
    a < x ↔ b < x := by
  have : a + b = x - 1 ∨ a + b = k + x - 1 := by
    rcases Nat.lt_or_ge (a + b) k with h | h
    · left; rwa [Nat.mod_eq_of_lt h] at hsum
    · right; rw [Nat.mod_eq_sub_mod h, Nat.mod_eq_of_lt (by omega)] at hsum; omega
  rcases this with h | h <;> constructor <;> intro <;> omega

-- Modular identity: ((j + r) % k + 1) % k = (j + r + 1) % k
private lemma cohn_mod_add_one (j r k : ℕ) : ((j + r) % k + 1) % k = (j + r + 1) % k := by
  rcases k with _ | k
  · simp [Nat.mod_zero]
  · have h1 : j + r + 1 = (j + r) % (k + 1) + 1 + (k + 1) * ((j + r) / (k + 1)) := by
      have := Nat.mul_comm (k + 1) ((j + r) / (k + 1))
      have := (Nat.div_add_mod (j + r) (k + 1)).symm
      linarith
    rw [h1, Nat.add_mul_mod_self_left]

-- Helper: if a % k = b % k and a ≥ 1 and b ≥ 1, then (a-1) % k = (b-1) % k
private lemma cohn_mod_sub_one {a b k : ℕ} (ha : 1 ≤ a) (hb : 1 ≤ b)
    (h : a % k = b % k) (hk : 0 < k) : (a - 1) % k = (b - 1) % k := by
  rcases Nat.eq_or_lt_of_le (Nat.zero_le (a % k)) with hr | hr
  · -- a % k = 0
    have ham : a % k = 0 := by linarith
    have hbm : b % k = 0 := by omega
    have hqa : 1 ≤ a / k := by
      have := Nat.div_pos (Nat.le_of_dvd (by omega) (Nat.dvd_of_mod_eq_zero ham)) hk; omega
    have hqb : 1 ≤ b / k := by
      have := Nat.div_pos (Nat.le_of_dvd (by omega) (Nat.dvd_of_mod_eq_zero hbm)) hk; omega
    have ha_rw : a - 1 = k * (a / k - 1) + (k - 1) := by
      have hd := (Nat.div_add_mod a k).symm
      have hkq : k * (a / k) = k * (a / k - 1) + k * 1 := by
        rw [← Nat.mul_add, Nat.sub_one_add_one_eq_of_pos (by omega)]
      omega
    have hb_rw : b - 1 = k * (b / k - 1) + (k - 1) := by
      have hd := (Nat.div_add_mod b k).symm
      have hkq : k * (b / k) = k * (b / k - 1) + k * 1 := by
        rw [← Nat.mul_add, Nat.sub_one_add_one_eq_of_pos (by omega)]
      omega
    rw [ha_rw, hb_rw, Nat.mul_add_mod, Nat.mul_add_mod]
  · -- a % k > 0
    have ha_rw : a - 1 = k * (a / k) + (a % k - 1) := by
      have := (Nat.div_add_mod a k).symm; omega
    have hb_rw : b - 1 = k * (b / k) + (b % k - 1) := by
      have := (Nat.div_add_mod b k).symm; omega
    rw [ha_rw, hb_rw, Nat.mul_add_mod, Nat.mul_add_mod, h]

-- Modular sum: (rev_char + rot_char) % k = x - 1
private lemma cohn_modsum (k x j r : ℕ) (hx : 0 < x) (hxk : x < k) (hjk : j < k)
    (hr : r < k) (hrx : r * x % k = 1) :
    (((k - j) * x - 1) % k + ((j + r + 1) * x - 1) % k) % k = x - 1 := by
  have hkj_pos : 1 ≤ (k - j) * x := by nlinarith [show 1 ≤ k - j from by omega]
  have hjr_pos : 1 ≤ (j + r + 1) * x := by nlinarith
  have h_distrib : (k - j) * x + (j + r + 1) * x = (k + r + 1) * x := by
    have h1 : (k - j) + (j + r + 1) = k + r + 1 := by omega
    nlinarith
  have h_sum : (k - j) * x - 1 + ((j + r + 1) * x - 1) = (k + r + 1) * x - 2 := by omega
  have hrx_eq : r * x = k * (r * x / k) + 1 := by
    have := (Nat.div_add_mod (r * x) k).symm; omega
  have h_rw : (k + r + 1) * x - 2 = k * (x + r * x / k) + (x - 1) := by
    have : (k + r + 1) * x = k * x + r * x + x := by ring
    have : k * x + r * x + x = k * x + (k * (r * x / k) + 1) + x := by omega
    have : k * x + (k * (r * x / k) + 1) + x = k * (x + r * x / k) + (x + 1) := by ring
    omega
  have h_goal : ((k + r + 1) * x - 2) % k = x - 1 := by
    rw [h_rw, Nat.mul_add_mod, Nat.mod_eq_of_lt (show x - 1 < k by omega)]
  have h_total : ((k - j) * x - 1 + ((j + r + 1) * x - 1)) % k = x - 1 := by
    rw [h_sum]; exact h_goal
  rwa [Nat.add_mod, Nat.mod_mod, Nat.mod_mod, ← Nat.add_mod]

-- Rotate mod: characterization at (j+r)%k equals characterization at j+r+1
private lemma cohn_rotmod (k x j r : ℕ) (hx : 0 < x) (hxk : x < k) (hr : r < k) :
    (((j + r) % k + 1) * x - 1) % k = ((j + r + 1) * x - 1) % k := by
  have hk : 0 < k := by omega
  have hA : 1 ≤ ((j + r) % k + 1) * x := by nlinarith [show 1 ≤ (j + r) % k + 1 from by omega]
  have hB : 1 ≤ (j + r + 1) * x := by nlinarith
  apply cohn_mod_sub_one hA hB _ hk
  exact Nat.ModEq.mul_right x (cohn_mod_add_one j r k)

-- Modular inverse existence
private lemma cohn_mod_inv_exists (k x : ℕ) (hk : 1 < k) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    ∃ r, r < k ∧ r * x % k = 1 := by
  have hcop' : Nat.Coprime x k := hcop.symm
  haveI : NeZero k := ⟨by omega⟩
  haveI hfact : Fact (1 < k) := ⟨hk⟩
  set u := ZMod.unitOfCoprime x hcop'
  use (u⁻¹ : (ZMod k)ˣ).val.val
  refine ⟨ZMod.val_lt _, ?_⟩
  have hmul : (u : ZMod k) * (u⁻¹ : (ZMod k)ˣ).val = 1 := Units.mul_inv u
  rw [ZMod.coe_unitOfCoprime] at hmul
  have h1 : ((x : ZMod k) * (u⁻¹ : (ZMod k)ˣ).val).val = (1 : ZMod k).val := by rw [hmul]
  have hval1 : (1 : ZMod k).val = 1 := ZMod.val_one k
  rw [ZMod.val_mul, ZMod.val_natCast_of_lt (show x < k by omega), hval1] at h1
  rw [show (u⁻¹ : (ZMod k)ˣ).val.val * x % k = x * (u⁻¹ : (ZMod k)ˣ).val.val % k from by ring_nf]
  exact h1

set_option maxHeartbeats 6400000 in
/-- **Theorem 5.1 (Cohn).**
    The reverse of an upper Christoffel word is a rotation of it.
    Therefore f(vh) and f(vh^R) are in the same rational Collatz cycle.

    The rotation distance is the multiplicative inverse of x modulo k. -/
theorem christoffel_reverse_is_rotation (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    ∃ n, (highCycleBits k x).reverse = (highCycleBits k x).rotate n := by
  obtain ⟨r, hr_lt, hrx⟩ := cohn_mod_inv_exists k x (by omega) hx hxk hcop
  use r
  apply List.ext_getElem
  · simp [highCycleBits_length]
  · intro j h1 h2
    simp only [highCycleBits_length, List.length_reverse] at h1
    have hlen : (highCycleBits k x).length = k := highCycleBits_length k x
    rw [List.getElem_reverse, List.getElem_rotate]
    simp only [highCycleBits, hlen, List.length_map, List.length_range,
      List.getElem_map, List.getElem_range]
    have hj : j < k := h1
    have hk1j : k - 1 - j < k := by omega
    have hjr : (j + r) % k < k := Nat.mod_lt _ (by omega)
    apply decide_eq_decide.mpr
    rw [cohn_mem_hcp k x _ hx hxk hk1j hcop, show k - 1 - j + 1 = k - j from by omega]
    rw [cohn_mem_hcp k x _ hx hxk hjr hcop, cohn_rotmod k x j r hx hxk hr_lt]
    exact cohn_compl_lt (Nat.mod_lt _ (by omega)) (Nat.mod_lt _ (by omega)) hx (by omega)
      (cohn_modsum k x j r hx hxk hj hr_lt hrx)

/-! ## The Key Algebraic Identities -/

/-- The inner word `u` extracted from `vh = 1·u·0`. -/
def highCycleInner (k x : ℕ) : List Bool :=
  innerWord (highCycleBits k x)

/-- The high-cycle vector decomposes as `true :: inner ++ [false]`. -/
private theorem highCycleBits_decompose (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    highCycleBits k x = true :: (highCycleInner k x) ++ [false] := by
  set v := highCycleBits k x with hv
  have hne : v ≠ [] := by
    intro h; have := highCycleBits_length k x; rw [← hv, h] at this; simp at this; omega
  -- Decompose: v = head :: rest with rest nonempty
  obtain ⟨a, rest, ha_eq⟩ := List.exists_cons_of_ne_nil hne
  have hrest_ne : rest ≠ [] := by
    intro h; rw [ha_eq, h] at hne
    have := highCycleBits_length k x; rw [← hv, ha_eq, h] at this; simp at this; omega
  -- a = true (from head)
  have ha : a = true := by
    have h := highCycleBits_head k x (by omega) (by omega)
    rw [← hv, ha_eq] at h; simp at h; exact h
  -- rest.getLast = false
  have hb : rest.getLast hrest_ne = false := by
    have h := highCycleBits_last k x (by omega) hxk hcop
    rw [← hv, ha_eq, List.getLast?_cons, List.getLast?_eq_getLast hrest_ne] at h
    exact Option.some_injective _ h
  -- rest = rest.dropLast ++ [false]
  have hrest_eq : rest = rest.dropLast ++ [false] := by
    conv_lhs => rw [(List.dropLast_append_getLast hrest_ne).symm, hb]
  -- Combine
  rw [ha_eq, ha, hrest_eq]
  -- Now: true :: rest.dropLast ++ [false] = true :: highCycleInner k x ++ [false]
  congr 2
  -- rest.dropLast = highCycleInner k x = innerWord v = v.tail.dropLast
  -- Since v = a :: rest, v.tail = rest, so innerWord v = rest.dropLast
  unfold highCycleInner innerWord
  rw [← hv, ha_eq]
  simp

/-- The inner word has x-1 ones. -/
private theorem highCycleInner_count (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (onePositions (highCycleInner k x)).length = x - 1 := by
  have hdecomp := highCycleBits_decompose k x hx hxk hcop
  have hcount := highCycleBits_count k x (by omega) hxk hcop
  rw [hdecomp] at hcount
  rw [onePositions_length]
  simp only [List.count_cons, List.count_append, List.count_nil] at hcount
  norm_num at hcount
  omega

/-- **Key Identity 1.** `g(vh) = 2·g(u) + 3^{x-1}` -/
theorem g_vh_eq (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (bsNumerator (highCycleBits k x) : ℤ) =
      2 * (bsNumerator (highCycleInner k x) : ℤ) + (3 : ℤ) ^ (x - 1) := by
  rw [highCycleBits_decompose k x hx hxk hcop]
  push_cast [bsNumerator_cons_true_append_false]
  rw [highCycleInner_count k x hx hxk hcop]

/-! ### Proof that the inner (central) word is a palindrome

The key identity: for coprime k, x and 1 ≤ i ≤ x-1,
  ⌊k·i/x⌋ + ⌊k·(x-i)/x⌋ = k - 1.
This follows from the fact that k·i/x is not an integer (by coprimality),
so ⌊a⌋ + ⌊n - a⌋ = n - 1 for non-integer a.

This symmetry means position j (1 ≤ j ≤ k-2) is a 1-position of the
Christoffel word iff position (k-1-j) is also a 1-position, which gives
the palindrome property of the inner word. -/

/-- If a + b < 2x, a < x, b < x, a > 0, and x | (a + b), then a + b = x. -/
private lemma mod_sum_eq (a b x : ℕ) (ha : a < x) (hb : b < x) (hapos : 0 < a)
    (hmod : (a + b) % x = 0) : a + b = x := by
  obtain ⟨q, hq⟩ := Nat.dvd_of_mod_eq_zero hmod
  nlinarith [show q ≤ 1 by nlinarith, show 1 ≤ q by nlinarith]

/-- The remainders k·i mod x and k·(x-i) mod x sum to x when k·i is not divisible by x. -/
private lemma mod_complement_sum (k x i : ℕ) (hx : 0 < x) (hi : i < x)
    (hmod : k * i % x ≠ 0) :
    k * i % x + k * (x - i) % x = x := by
  apply mod_sum_eq _ _ x (Nat.mod_lt _ hx) (Nat.mod_lt _ hx) (Nat.pos_of_ne_zero hmod)
  rw [← Nat.add_mod, ← Nat.left_distrib, Nat.add_sub_cancel' (by omega),
      Nat.mul_comm, Nat.mul_mod_right]

/-- The floor identity: ⌊k·i/x⌋ + ⌊k·(x-i)/x⌋ = k - 1 when x ∤ k·i. -/
private lemma floor_complement (k x i : ℕ) (hx : 0 < x) (hi : i < x) (hk : 0 < k)
    (hmod : k * i % x ≠ 0) :
    k * i / x + k * (x - i) / x = k - 1 := by
  have hd1 := Nat.div_add_mod (k * i) x
  have hd2 := Nat.div_add_mod (k * (x - i)) x
  have hkx : k * i + k * (x - i) = k * x := by
    rw [← Nat.left_distrib, Nat.add_sub_cancel' (by omega)]
  have hms := mod_complement_sum k x i hx hi hmod
  have key : x * (k * i / x + k * (x - i) / x + 1) = x * k := by nlinarith
  have := Nat.mul_left_cancel (show 0 < x by omega) key; omega

/-- Coprimality ensures x does not divide k·i for 1 ≤ i < x. -/
private lemma coprime_mod_ne_zero (k x i : ℕ) (hcop : Nat.Coprime k x)
    (hi1 : 0 < i) (hi2 : i < x) : k * i % x ≠ 0 := by
  intro h
  have : x ∣ i := hcop.symm.dvd_of_dvd_mul_left (Nat.dvd_of_mod_eq_zero h)
  exact Nat.not_dvd_of_pos_of_lt hi1 hi2 this

/-- If m is a 1-position (1 ≤ m ≤ k-2), then k-1-m is also a 1-position. -/
private lemma mem_positions_symm (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) (m : ℕ) (hm1 : 0 < m) (hm2 : m < k - 1)
    (hm : m ∈ highCyclePositions k x) :
    k - 1 - m ∈ highCyclePositions k x := by
  simp only [highCyclePositions, List.mem_map, List.mem_range] at hm ⊢
  obtain ⟨i, hi, rfl⟩ := hm
  have hi0 : 0 < i := by
    by_contra h; push_neg at h; interval_cases i; simp at hm1
  refine ⟨x - i, by omega, ?_⟩
  have := floor_complement k x i (by omega) hi (by omega) (coprime_mod_ne_zero k x i hcop hi0 hi)
  omega

/-- If m is not a 1-position (1 ≤ m ≤ k-2), then k-1-m is also not. -/
private lemma not_mem_positions_symm (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) (m : ℕ) (hm1 : 0 < m) (hm2 : m < k - 1)
    (hm : m ∉ highCyclePositions k x) :
    k - 1 - m ∉ highCyclePositions k x := by
  intro hmem; apply hm
  have h := mem_positions_symm k x hx hxk hcop (k - 1 - m) (by omega) (by omega) hmem
  rwa [show k - 1 - (k - 1 - m) = m from by omega] at h

/-- Membership in positions is symmetric around k/2. -/
private lemma decide_mem_symm (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) (m : ℕ) (hm1 : 0 < m) (hm2 : m < k - 1) :
    decide (m ∈ highCyclePositions k x) = decide (k - 1 - m ∈ highCyclePositions k x) := by
  by_cases h : m ∈ highCyclePositions k x
  · simp [h, mem_positions_symm k x hx hxk hcop m hm1 hm2 h]
  · simp [h, not_mem_positions_symm k x hx hxk hcop m hm1 hm2 h]

/-- The inner word equals a map over range(k-2). -/
private lemma highCycleInner_eq_map (k x : ℕ) (hxk : x < k) :
    highCycleInner k x =
      (List.range (k - 2)).map (fun n => decide (n + 1 ∈ highCyclePositions k x)) := by
  apply List.ext_getElem
  · simp [show (highCycleInner k x).length = k - 2 from by
      unfold highCycleInner innerWord; simp [highCycleBits]; omega]
  · intro n hn1 hn2
    unfold highCycleInner innerWord at hn1 ⊢
    rw [List.getElem_dropLast, List.getElem_tail]
    simp [highCycleBits, List.getElem_map, List.getElem_range]

/-- **Palindrome property of Christoffel central word.**
    The inner word of the upper Christoffel word is a palindrome (central word).
    Proved using the floor identity ⌊k·i/x⌋ + ⌊k·(x-i)/x⌋ = k - 1. -/
theorem christoffel_inner_palindrome (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (highCycleInner k x).reverse = highCycleInner k x := by
  rw [highCycleInner_eq_map k x hxk]
  apply List.ext_getElem (by simp)
  intro n hn1 hn2
  simp only [List.length_reverse, List.length_map, List.length_range] at hn1
  simp only [List.length_map, List.length_range] at hn2
  rw [List.getElem_reverse]
  simp only [List.getElem_map, List.length_map, List.length_range, List.getElem_range]
  rw [show k - 2 - 1 - n + 1 = k - 1 - (n + 1) from by omega]
  exact (decide_mem_symm k x hx hxk hcop (n + 1) (by omega) (by omega)).symm

/-- The reverse decomposes as `false :: inner^R ++ [true]`. -/
private theorem highCycleBits_rev_decompose (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (highCycleBits k x).reverse =
      false :: (highCycleInner k x).reverse ++ [true] := by
  rw [highCycleBits_decompose k x hx hxk hcop]
  simp [List.reverse_cons, List.reverse_append]

/-- The inner word's reverse has the same length as the inner word. -/
private theorem highCycleInner_rev_length (k x : ℕ) :
    (highCycleInner k x).reverse.length = (highCycleInner k x).length :=
  List.length_reverse ..

/-- The inner word has length k-2. -/
private theorem highCycleInner_length (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (highCycleInner k x).length = k - 2 := by
  have hdecomp := highCycleBits_decompose k x hx hxk hcop
  have hlen := highCycleBits_length k x
  have hlen2 : (true :: highCycleInner k x ++ [false]).length =
      (highCycleInner k x).length + 2 := by
    simp [List.length_append]
  rw [hdecomp] at hlen; rw [hlen2] at hlen; omega

/-- **Key Identity 2.** `g(vh^R) = 6·g(u) + 2^{k-1}` -/
theorem g_vhR_eq (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    (bsNumerator (highCycleBits k x).reverse : ℤ) =
      6 * (bsNumerator (highCycleInner k x) : ℤ) + (2 : ℤ) ^ (k - 1) := by
  rw [highCycleBits_rev_decompose k x hx hxk hcop]
  push_cast [bsNumerator_cons_false_append_true]
  rw [christoffel_inner_palindrome k x hx hxk hcop]
  rw [highCycleInner_length k x hx hxk hcop]
  congr 1
  congr 1
  omega

/-! ## Halbeisen-Hungerbühler Results (Axiomatized) -/

/-- **Theorem 4.4.** Axiomatized.
    f(vh) ≤ f(v) for every rotation v of vh. The high-cycle vector gives
    the smallest member of its cycle. -/
axiom highCycle_minimizes_rotation (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) (hpos : 3 ^ x < 2 ^ k) (n : ℕ) :
    bsFormula k x (highCycleBits k x) ≤ bsFormula k x ((highCycleBits k x).rotate n)

/-- **Theorem 4.7.** Axiomatized.
    f(vh) ≥ f(v) for the smallest member v of ANY (k,x)-cycle.
    The high cycle contains the largest "smallest member". -/
axiom highCycle_maximizes_over_cycles (k x : ℕ) (hx : 0 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) (hpos : 3 ^ x < 2 ^ k) (v : ParityVec k x) :
    bsFormula k x v.bits ≤ bsFormula k x (highCycleBits k x)
