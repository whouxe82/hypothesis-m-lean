/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Knight2026.Defs

Core definitions for formalizing "Collatz High Cycles Do Not Exist" by Kevin Knight.

## Design Rationale

### Parity vectors as `List Bool` with length/count constraints

We represent parity vectors as `List Bool` bundled with proofs of:
- length = k
- count of `true` entries = x
- the positivity constraint k > x * log₂(3)  (approximated as 2^k > 3^x)

**Why `List Bool` over alternatives:**
- `Fin k → Bool` (function representation): Clean mathematically, but rotations become
  awkward (require modular arithmetic on indices). Pattern matching on first/last elements
  (needed for Theorem 5.2: vh = 1u0) is unnatural.
- `Finset (Fin k)` (set of 1-positions): Natural for the Böhm-Sontacchi formula, but
  loses ordering information and makes rotation/reversal harder.
- `List Bool` (our choice): Rotation is `List.rotate`, reversal is `List.reverse`,
  extracting the inner word u from vh = 1u0 is just `v.tail.dropLast`. The Böhm-Sontacchi
  formula indexes 1-positions, which we compute via `onePositions`.
- `Vector Bool k` (length-indexed): Would give length at the type level, but Mathlib
  support is thinner than for `List`. We bundle length as a proof instead.

### Working in ℤ for the main theorem

The key insight of the proof is that `3 * f(vh) - f(vh^R) + 1 = 2^{k-1} / (2^k - 3^x)`.
We never need to show this is irrational -- we just need to show `2^{k-1}` is not divisible
by the odd number `2^k - 3^x`. This is pure integer divisibility, so we work in ℤ.

The rational formula `f(v) = g(v) / (2^k - 3^x)` only appears conceptually. The actual
proof manipulates numerators: if f(vh) and f(vh^R) are both integers, then
`3 * g(vh) - g(vh^R) + (2^k - 3^x)` must be divisible by `(2^k - 3^x)`, which forces
`2^{k-1}` to be divisible by `(2^k - 3^x)`. Since `2^k - 3^x` is odd, contradiction.

### Separating g (numerator) from f (rational formula)

We define `g` (the numerator) as the primary computable object, returning a natural number.
The rational `f = g / (2^k - 3^x)` is defined separately and used only for stating
cycle membership properties. The main theorem (5.4) is stated purely in terms of
divisibility of g values, avoiding ℚ entirely.
-/

import Mathlib.Data.List.Basic
import Mathlib.Data.List.Rotate
import Mathlib.Data.Rat.Defs
import Mathlib.Tactic

/-! ## Parity Vectors -/

/-- The positions of `true` entries in a `List Bool`, in order.
    For v = [true, true, false, true, false], returns [0, 1, 3]. -/
def onePositions : List Bool → List ℕ
  | [] => []
  | (true :: rest) => 0 :: (onePositions rest).map (· + 1)
  | (false :: rest) => (onePositions rest).map (· + 1)

/-- A `ParityVec k x` is a binary vector of length `k` with exactly `x` ones,
    satisfying the positivity constraint `2^k > 3^x` (equivalently k > x·log₂3).

    This is the central data type. Every Collatz cycle of length k with x odd steps
    corresponds to a parity vector recording which steps are odd (1) vs even (0). -/
structure ParityVec (k x : ℕ) where
  /-- The underlying binary vector -/
  bits : List Bool
  /-- The vector has length k -/
  length_eq : bits.length = k
  /-- The vector has exactly x ones -/
  count_eq : bits.count true = x
  /-- Positivity: the denominator 2^k - 3^x is positive -/
  pos_denom : 3 ^ x < 2 ^ k

/-! ## The Böhm-Sontacchi Numerator g(v) -/

/-- The numerator of the Böhm-Sontacchi formula:
    `g(v) = Σ_{i=0}^{x-1} 2^{d_i(v)} · 3^{x-i-1}`
    where d_0 < d_1 < ... < d_{x-1} are the positions of 1s in v.

    This is a natural number (all terms are positive). -/
def bsNumeratorAux : List ℕ → ℕ → ℕ
  | [], _ => 0
  | d :: rest, i => 2 ^ d * 3 ^ i + bsNumeratorAux rest (i - 1)

/-- The numerator of the Böhm-Sontacchi formula:
    `g(v) = Σ_{i=0}^{x-1} 2^{d_i(v)} · 3^{x-i-1}`
    where d_0 < d_1 < ... < d_{x-1} are the positions of 1s in v.

    This is a natural number (all terms are positive). -/
def bsNumerator (v : List Bool) : ℕ :=
  let positions := onePositions v
  let x := positions.length
  bsNumeratorAux positions (x - 1)

/-- The denominator of the Böhm-Sontacchi formula: `2^k - 3^x`.
    Returns an integer since we need it to be positive (not always the case for arbitrary k, x). -/
def bsDenominator (k x : ℕ) : ℤ :=
  (2 : ℤ) ^ k - (3 : ℤ) ^ x

/-- The Böhm-Sontacchi cycle formula as a rational number:
    `f(v) = g(v) / (2^k - 3^x)` -/
def bsFormula (k x : ℕ) (v : List Bool) : ℚ :=
  (bsNumerator v : ℚ) / (bsDenominator k x : ℚ)

/-! ## Rotation and Reversal -/

/-- Left-rotate a list by n positions. Uses Mathlib's `List.rotate`. -/
def rotateVec (v : List Bool) (n : ℕ) : List Bool :=
  v.rotate n

/-- Reverse a parity vector. -/
def reverseVec (v : List Bool) : List Bool :=
  v.reverse

/-! ## The "integrality" predicate -/

/-- `f(v)` is an integer iff `(2^k - 3^x)` divides `g(v)`. This is the key predicate
    that the paper's proof targets: we show the high cycle cannot have this property.

    Working with divisibility in ℤ is much cleaner than working with ℚ integrality. -/
def bsIsInteger (k x : ℕ) (v : List Bool) : Prop :=
  (bsDenominator k x : ℤ) ∣ (bsNumerator v : ℤ)

/-! ## Key Identities and Lemmas (Specifications) -/

/-- The high-cycle parity vector has the form 1·u·0.
    This extracts the inner word u. -/
def innerWord (v : List Bool) : List Bool :=
  v.tail.dropLast

/-- Predicate that a vector has the form `true :: u ++ [false]`. -/
def hasForm_1u0 (v : List Bool) : Prop :=
  v.head? = some true ∧ v.getLast? = some false ∧ v.length ≥ 2

/-- Predicate that a vector has the form `false :: u ++ [true]`. -/
def hasForm_0u1 (v : List Bool) : Prop :=
  v.head? = some false ∧ v.getLast? = some true ∧ v.length ≥ 2
