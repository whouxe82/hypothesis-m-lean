/-
  Knight 2023/2026: Main theorem — No high cycle consists of integers (Theorem 5.4).
-/
import Knight2026.Defs
import Knight2026.ParityVec
import Knight2026.BsLemmas
import Knight2026.HighCycle

import Mathlib.Tactic

/-! ## Rotation preserves integrality -/

/-- An odd integer dividing 2*a must divide a. -/
private theorem odd_dvd_of_dvd_two_mul (d a : ℤ) (hodd : ¬ (2 : ℤ) ∣ d)
    (h : d ∣ 2 * a) : d ∣ a := by
  have hgcd : Int.gcd d 2 = 1 := by
    have hle : (Int.gcd d 2 : ℤ) ∣ (2 : ℤ) := Int.gcd_dvd_right d 2
    have hle' : Int.gcd d 2 ≤ 2 := by
      exact_mod_cast Int.le_of_dvd (by norm_num) hle
    have hne : Int.gcd d 2 ≠ 2 := by
      intro heq
      apply hodd
      have h1 := Int.gcd_dvd_left (a := d) (b := (2 : ℤ))
      rw [heq] at h1
      exact h1
    have hpos : 0 < Int.gcd d 2 := Int.gcd_pos_of_ne_zero_right d (by norm_num)
    omega
  have hcop : IsCoprime d 2 := by
    rwa [show (2 : ℤ) = ↑(2 : ℕ) from by norm_num, Int.isCoprime_iff_gcd_eq_one]
  rw [show 2 * a = a * 2 from by ring] at h
  exact hcop.dvd_of_dvd_mul_right h

/-- 3^x % 2 = 1 for all x. -/
private theorem three_pow_mod_two' (x : ℕ) : (3 : ℤ) ^ x % 2 = 1 := by
  induction x with
  | zero => norm_num
  | succ n ih => rw [pow_succ, Int.mul_emod, ih]; norm_num

/-- The denominator D = 2^k - 3^x is odd (not divisible by 2). -/
private theorem bsDenom_odd (k x : ℕ) (hk : 0 < k) :
    ¬ (2 : ℤ) ∣ bsDenominator k x := by
  unfold bsDenominator
  intro ⟨c, hc⟩
  have h2 : (2 : ℤ) ∣ 2 ^ k := dvd_pow_self 2 (by omega : k ≠ 0)
  have h3 : (2 : ℤ) ∣ 3 ^ x := by
    have : (3 : ℤ) ^ x = 2 ^ k - (2 ^ k - 3 ^ x) := by ring
    rw [this, hc]; exact dvd_sub (dvd_pow_self 2 (by omega : k ≠ 0)) ⟨c, rfl⟩
  have h0 : (3 : ℤ) ^ x % 2 = 0 := by obtain ⟨m, hm⟩ := h3; rw [hm]; omega
  linarith [three_pow_mod_two' x]

/-- Rotation by 1 preserves bsIsInteger. -/
private theorem rotate_one_preserves (k x : ℕ) (v : List Bool)
    (hk : 0 < k) (hlen : v.length = k) (hcount : v.count true = x)
    (hint : bsIsInteger k x v) :
    bsIsInteger k x (v.rotate 1) := by
  unfold bsIsInteger at *
  rcases v with _ | ⟨b, rest⟩
  · simp at hlen; omega
  · simp only [List.rotate_cons_succ, List.rotate_zero]
    have hodd := bsDenom_odd k x hk
    cases b with
    | false =>
      -- g(false :: rest) = 2 * g(rest ++ [false])
      -- by bsNumerator_cons_false and bsNumerator_append_false
      have : (bsNumerator (false :: rest) : ℤ) = 2 * (bsNumerator (rest ++ [false]) : ℤ) := by
        push_cast [bsNumerator_cons_false, bsNumerator_append_false]; ring
      rw [this] at hint
      exact odd_dvd_of_dvd_two_mul _ _ hodd hint
    | true =>
      -- 2 * g(rest ++ [true]) = 3 * g(true :: rest) + D
      have hxcount : (onePositions rest).length = x - 1 := by
        rw [onePositions_length]
        simp only [List.count_cons, beq_self_eq_true, ↓reduceIte] at hcount
        omega
      have hklen : rest.length = k - 1 := by simp at hlen; omega
      -- The algebraic identity
      have halg : 2 * (bsNumerator (rest ++ [true]) : ℤ) =
          3 * (bsNumerator (true :: rest) : ℤ) + bsDenominator k x := by
        push_cast [bsNumerator_cons_true, bsNumerator_append_true]
        unfold bsDenominator
        rw [hxcount, hklen]
        have hx1 : (3 : ℤ) ^ x = 3 * 3 ^ (x - 1) := by
          have : x = (x - 1) + 1 := by
            simp only [List.count_cons, beq_self_eq_true, ↓reduceIte] at hcount; omega
          conv_lhs => rw [this, pow_succ]
          exact mul_comm _ _
        have hk1 : (2 : ℤ) ^ k = 2 * 2 ^ (k - 1) := by
          have : k = (k - 1) + 1 := by simp at hlen; omega
          conv_lhs => rw [this, pow_succ]
          exact mul_comm _ _
        linarith
      -- D | g(v) → D | 3*g(v) → D | (3*g(v) + D) = 2*g(rot v 1)
      obtain ⟨m, hm⟩ := hint
      have h2rot : bsDenominator k x ∣ (2 * (bsNumerator (rest ++ [true]) : ℤ)) := by
        rw [halg, hm]
        unfold bsDenominator
        exact ⟨3 * m + 1, by ring⟩
      exact odd_dvd_of_dvd_two_mul _ _ hodd h2rot

/-- **Böhm-Sontacchi.** Rotation preserves the integrality predicate.
    If `(2^k - 3^x) ∣ g(v)`, then `(2^k - 3^x) ∣ g(rotate v n)`. -/
private theorem count_true_rotate (v : List Bool) (n : ℕ) :
    (v.rotate n).count true = v.count true :=
  (v.rotate_perm n).count_eq true

theorem rotation_preserves_bsIsInteger (k x n : ℕ) (v : List Bool)
    (hlen : v.length = k) (hcount : v.count true = x)
    (hint : bsIsInteger k x v) :
    bsIsInteger k x (v.rotate n) := by
  rcases k with _ | k'
  · have hv : v = [] := by simp at hlen; exact hlen
    subst hv; simp [List.rotate] at hint ⊢; exact hint
  · induction n with
    | zero => simpa using hint
    | succ m ih =>
      have : v.rotate (m + 1) = (v.rotate m).rotate 1 := by
        rw [List.rotate_rotate, Nat.add_comm]
      rw [this]
      apply rotate_one_preserves (k' + 1) x
      · omega
      · rw [List.length_rotate]; exact hlen
      · rw [count_true_rotate]; exact hcount
      · exact ih

/-! ## The Cancellation Lemma -/

theorem cancellation_identity (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hcop : Nat.Coprime k x) :
    3 * (bsNumerator (highCycleBits k x) : ℤ)
      - (bsNumerator (highCycleBits k x).reverse : ℤ)
      + ((2 : ℤ) ^ k - (3 : ℤ) ^ x)
    = (2 : ℤ) ^ (k - 1) := by
  rw [g_vh_eq k x hx hxk hcop, g_vhR_eq k x hx hxk hcop]
  set g_u := (bsNumerator (highCycleInner k x) : ℤ)
  have h3 : (3 : ℤ) ^ x = 3 * 3 ^ (x - 1) := by
    have : x = x - 1 + 1 := by omega
    conv_lhs => rw [this, pow_succ]
    exact mul_comm _ _
  have h2 : (2 : ℤ) ^ k = 2 * 2 ^ (k - 1) := by
    have : k = k - 1 + 1 := by omega
    conv_lhs => rw [this, pow_succ]
    exact mul_comm _ _
  -- After rw, goal involves 3*(2*g_u + 3^{x-1}) - (6*g_u + 2^{k-1}) + (2^k - 3^x) = 2^{k-1}
  -- = 6*g_u + 3*3^{x-1} - 6*g_u - 2^{k-1} + 2^k - 3^x
  -- Use h3 and h2 to rewrite 3^x and 2^k, then linarith
  linarith

/-! ## Odd Denominator -/

private theorem three_pow_mod_two (x : ℕ) : (3 : ℤ) ^ x % 2 = 1 := by
  induction x with
  | zero => norm_num
  | succ n ih => rw [pow_succ, Int.mul_emod, ih]; norm_num

theorem bsDenominator_odd (k x : ℕ) (hk : 1 ≤ k) :
    ¬ (2 : ℤ) ∣ ((2 : ℤ) ^ k - (3 : ℤ) ^ x) := by
  intro ⟨c, hc⟩
  have h2 : (2 : ℤ) ∣ 2 ^ k := dvd_pow_self 2 (by omega : k ≠ 0)
  have h3 : (2 : ℤ) ∣ 3 ^ x := by
    have heq : (3 : ℤ) ^ x = 2 ^ k - (2 ^ k - 3 ^ x) := by ring
    rw [heq, hc]; exact dvd_sub h2 ⟨c, rfl⟩
  obtain ⟨m, hm⟩ := h3
  have h0 : (3 : ℤ) ^ x % 2 = 0 := by rw [hm]; omega
  have h1 := three_pow_mod_two x
  omega

/-! ## Powers of 2 have no odd divisors > 1 -/

theorem odd_not_dvd_pow_two (d : ℤ) (n : ℕ) (hd_pos : 1 < d)
    (hd_odd : ¬ (2 : ℤ) ∣ d) (hdvd : d ∣ (2 : ℤ) ^ n) : False := by
  have hd_natAbs_dvd : d.natAbs ∣ 2 ^ n := Int.natAbs_dvd_natAbs.mpr hdvd
  have hd_natAbs_gt : d.natAbs > 1 := by
    cases Int.natAbs_eq d with | inl h => omega | inr h => omega
  obtain ⟨p, hp_prime, hp_dvd⟩ := Nat.exists_prime_and_dvd (by omega : d.natAbs ≠ 1)
  have hp2 : p = 2 := by
    have : p ∣ 2 := hp_prime.dvd_of_dvd_pow (dvd_trans hp_dvd hd_natAbs_dvd)
    exact le_antisymm (Nat.le_of_dvd (by omega) this) hp_prime.two_le
  rw [hp2] at hp_dvd
  apply hd_odd
  exact Int.dvd_natAbs.mp (Int.natCast_dvd_natCast.mpr hp_dvd)

/-! ## D = 2^k - 3^x > 1 for x ≥ 2 -/

private theorem nine_pow_mod_eight (n : ℕ) : (9 : ℤ) ^ n % 8 = 1 := by
  induction n with
  | zero => norm_num
  | succ m ih => rw [pow_succ, Int.mul_emod, ih]; norm_num

theorem bsDenominator_gt_one (k x : ℕ) (hx : 1 < x) (hxk : x < k)
    (hpos : 3 ^ x < 2 ^ k) :
    1 < (2 : ℤ) ^ k - (3 : ℤ) ^ x := by
  suffices h : (2 : ℤ) ^ k ≠ 3 ^ x + 1 by
    have : (3 : ℤ) ^ x < (2 : ℤ) ^ k := by exact_mod_cast hpos
    omega
  intro h2k
  have hk4 : k ≥ 4 := by
    by_contra hk_lt; push_neg at hk_lt
    interval_cases k <;> interval_cases x <;> simp_all
  -- 2^k ≡ 0 (mod 8) for k ≥ 3
  have h2k_mod8 : (2 : ℤ) ^ k % 8 = 0 := by
    have h8 : (2 : ℤ) ^ k = 8 * 2 ^ (k - 3) := by
      have hk3 : k = 3 + (k - 3) := by omega
      conv_lhs => rw [hk3, pow_add]
      norm_num
    rw [h8]; omega
  -- From h2k: 2^k = 3^x + 1, so (3^x + 1) % 8 = 0
  have h_combo : ((3 : ℤ) ^ x + 1) % 8 = 0 := by rw [← h2k]; exact h2k_mod8
  -- But 3^x + 1 mod 8 is never 0 for x ≥ 2
  by_cases hx_even : x % 2 = 0
  · -- x even: 3^x = 9^{x/2}, 9^m mod 8 = 1, so 3^x+1 mod 8 = 2
    obtain ⟨m, rfl⟩ : ∃ m, x = 2 * m := ⟨x / 2, by omega⟩
    have h9 : (3 : ℤ) ^ (2 * m) = 9 ^ m := by rw [pow_mul]; norm_num
    rw [h9] at h_combo
    have := nine_pow_mod_eight m
    omega
  · -- x odd: 3^x = 9^{(x-1)/2} * 3, mod 8 = 3, so 3^x+1 mod 8 = 4
    obtain ⟨m, rfl⟩ : ∃ m, x = 2 * m + 1 := ⟨x / 2, by omega⟩
    have h3x : (3 : ℤ) ^ (2 * m + 1) = 9 ^ m * 3 := by
      rw [show 2 * m + 1 = 2 * m + 1 from rfl, pow_succ, pow_mul]; norm_num
    rw [h3x] at h_combo
    have : (9 : ℤ) ^ m * 3 % 8 = 3 := by
      rw [Int.mul_emod, nine_pow_mod_eight]; norm_num
    omega

/-! ## Main Theorem -/

/-- **Theorem 5.4.** No high cycle consists of integers. -/
theorem no_integer_high_cycles (k x : ℕ)
    (hx : 1 < x) (hxk : x < k) (hcop : Nat.Coprime k x)
    (hpos : 3 ^ x < 2 ^ k)
    (h_vh_int : bsIsInteger k x (highCycleBits k x))
    (h_vhR_int : bsIsInteger k x (highCycleBits k x).reverse) :
    False := by
  unfold bsIsInteger at h_vh_int h_vhR_int
  have h_dvd_combo : ((2 : ℤ) ^ k - (3 : ℤ) ^ x) ∣
      (3 * (bsNumerator (highCycleBits k x) : ℤ)
       - (bsNumerator (highCycleBits k x).reverse : ℤ)
       + ((2 : ℤ) ^ k - (3 : ℤ) ^ x)) := by
    obtain ⟨a, ha⟩ := h_vh_int
    obtain ⟨b, hb⟩ := h_vhR_int
    exact ⟨3 * a - b + 1, by rw [ha, hb]; unfold bsDenominator; ring⟩
  rw [cancellation_identity k x hx hxk hcop] at h_dvd_combo
  exact odd_not_dvd_pow_two _ _ (bsDenominator_gt_one k x hx hxk hpos)
    (bsDenominator_odd k x (by omega)) h_dvd_combo

/-! ## Corollary -/

theorem no_integer_high_cycles' (k x : ℕ)
    (hx : 1 < x) (hxk : x < k) (hcop : Nat.Coprime k x)
    (hpos : 3 ^ x < 2 ^ k)
    (h_vh_int : bsIsInteger k x (highCycleBits k x)) :
    False := by
  have ⟨n, hrot⟩ := christoffel_reverse_is_rotation k x (by omega) hxk hcop
  have h_vhR_int : bsIsInteger k x (highCycleBits k x).reverse := by
    rw [hrot]
    exact rotation_preserves_bsIsInteger k x n (highCycleBits k x)
      (highCycleBits_length k x) (highCycleBits_count k x (by omega) hxk hcop) h_vh_int
  exact no_integer_high_cycles k x hx hxk hcop hpos h_vh_int h_vhR_int
