/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Knight2026.Circuit

The circuit vector and Steiner's theorem that no non-trivial integer circuits exist.

## Overview

This file defines:
1. The circuit vector `vc = 1^x 0^{k-x}` (all ones followed by all zeros)
2. The closed-form simplification: `f(vc) = (3^x - 2^x) / (2^k - 3^x)` (Lemma 3.1)
3. Steiner's Theorem 3.4 (axiomatized, since it depends on Baker's transcendence theory)

## Design Notes

### Why axiomatize Steiner's theorem?
The no-circuit proof (Theorem 3.4) depends on Ellison's bound (Lemma 3.3):
  `2^k - 3^x > 2.56^x` for x > 17
This bound ultimately derives from Baker's theorem on linear forms in logarithms, which
is deep transcendence theory not available in Mathlib. Rather than formalizing all of
Baker's theory, we axiomatize the result.

The main contribution of the paper (Theorem 5.4, no high cycles) does NOT depend on
this -- it uses a completely elementary divisibility argument. So axiomatizing the circuit
result does not weaken the formalization of the paper's main result.

### The circuit vector is concrete
Unlike the high-cycle vector (which involves floor functions), the circuit vector has a
simple closed form. We can compute `g(vc)` directly and simplify.
-/

import Knight2026.Defs
import Knight2026.ParityVec
import Knight2026.BsLemmas

/-! ## The Circuit Vector -/

/-- The circuit parity vector: x ones followed by (k-x) zeros.
    `vc = 1^x 0^{k-x}` -/
def circuitBits (k x : ℕ) : List Bool :=
  List.replicate x true ++ List.replicate (k - x) false

/-- The circuit vector has the correct length (when x ≤ k). -/
theorem circuitBits_length (k x : ℕ) (h : x ≤ k) :
    (circuitBits k x).length = k := by
  simp [circuitBits, List.length_replicate]
  omega

/-- The circuit vector has exactly x ones. -/
theorem circuitBits_count (k x : ℕ) :
    (circuitBits k x).count true = x := by
  simp [circuitBits, List.count_append, List.count_replicate]

/-- The one-positions of the circuit vector are [0, 1, ..., x-1]. -/
private theorem onePositions_replicate_true (x : ℕ) :
    onePositions (List.replicate x true) = List.range x := by
  induction x with
  | zero => simp [onePositions]
  | succ n ih =>
    simp only [List.replicate_succ, onePositions, ih, List.range_succ_eq_map, List.map_map,
      Function.comp, Nat.zero_add]

private theorem onePositions_replicate_false (n : ℕ) :
    onePositions (List.replicate n false) = [] := by
  induction n with
  | zero => simp [onePositions]
  | succ m ih => simp only [List.replicate_succ, onePositions, ih, List.map_nil]

private theorem replicate_succ_append {α : Type*} (n : ℕ) (a : α) :
    List.replicate (n + 1) a = List.replicate n a ++ [a] := by
  induction n with
  | zero => simp
  | succ m ih =>
    -- Goal: replicate (m+2) a = replicate (m+1) a ++ [a]
    -- LHS = a :: replicate (m+1) a = a :: (replicate m a ++ [a]) (by ih)
    --      = (a :: replicate m a) ++ [a] = replicate (m+1) a ++ [a] = RHS
    conv_lhs => rw [List.replicate_succ, ih]
    simp [List.cons_append, List.replicate_succ]

private theorem onePositions_append_replicate_false (v : List Bool) (n : ℕ) :
    onePositions (v ++ List.replicate n false) = onePositions v := by
  induction n with
  | zero => simp
  | succ m ih =>
    rw [replicate_succ_append m false, ← List.append_assoc, onePositions_append_false]
    exact ih

theorem circuitBits_onePositions (k x : ℕ) (h : x ≤ k) :
    onePositions (circuitBits k x) = List.range x := by
  unfold circuitBits
  rw [onePositions_append_replicate_false]
  exact onePositions_replicate_true x

/-- Build a ParityVec for the circuit (requires x ≤ k and 3^x < 2^k). -/
def circuitVec (k x : ℕ) (hxk : x ≤ k) (hpos : 3 ^ x < 2 ^ k) : ParityVec k x where
  bits := circuitBits k x
  length_eq := circuitBits_length k x hxk
  count_eq := circuitBits_count k x
  pos_denom := hpos

/-! ## Closed-form for g(vc) -/

/-- **Lemma 3.1 (numerator form).**
    `g(vc) = Σ_{i=0}^{x-1} 2^i · 3^{x-i-1} = 3^x - 2^x`

    The numerator of the circuit formula simplifies to a geometric-series difference.
    This is proved by induction on x. -/
private theorem pow_three_ge_pow_two (n : ℕ) : 2 ^ n ≤ 3 ^ n :=
  Nat.pow_le_pow_left (by omega) n

private theorem bsNumeratorAux_range (x : ℕ) :
    bsNumeratorAux (List.range x) (x - 1) = 3 ^ x - 2 ^ x := by
  induction x with
  | zero => simp [bsNumeratorAux]
  | succ n ih =>
    rw [show n + 1 - 1 = n from by omega, List.range_succ]
    set ps := List.range n
    have hlen : ps.length = n := List.length_range
    rw [← hlen, bsNumeratorAux_append_singleton, hlen, ih]
    have h3 : 2 ^ n ≤ 3 ^ n := pow_three_ge_pow_two n
    cases n with
    | zero => simp
    | succ m =>
      have h3' : 2 ^ (m + 1) ≤ 3 ^ (m + 1) := pow_three_ge_pow_two (m + 1)
      zify [h3', pow_three_ge_pow_two (m + 2)]
      ring

theorem circuit_numerator_eq (k x : ℕ) (h : x ≤ k) :
    bsNumerator (circuitBits k x) = 3 ^ x - 2 ^ x := by
  show bsNumeratorAux (onePositions (circuitBits k x))
    ((onePositions (circuitBits k x)).length - 1) = 3 ^ x - 2 ^ x
  rw [circuitBits_onePositions k x h, List.length_range]
  exact bsNumeratorAux_range x

/-- **Lemma 3.1 (rational form).**
    `f(vc) = (3^x - 2^x) / (2^k - 3^x)` -/
theorem circuit_formula (k x : ℕ) (hxk : x ≤ k) (hpos : 3 ^ x < 2 ^ k) :
    bsFormula k x (circuitBits k x) =
      ((3 ^ x - 2 ^ x : ℤ) : ℚ) / ((2 ^ k - 3 ^ x : ℤ) : ℚ) := by
  unfold bsFormula bsDenominator
  congr 1
  rw [circuit_numerator_eq k x hxk]
  have h2x_le_3x : 2 ^ x ≤ 3 ^ x := pow_three_ge_pow_two x
  zify [h2x_le_3x]

/-! ## Steiner's Theorem (Axiomatized) -/

/-- **Lemma 3.3 (Ellison's bound).** Axiomatized.
    For integers k and x with x > 17 and 2^k > 3^x, we have 2^k - 3^x > 2.56^x.

    This is a consequence of Baker's theorem on linear forms in logarithms.
    We state it in a purely integer form to avoid real numbers. -/
axiom ellison_bound (k x : ℕ) (hx : x > 17) (hpos : 3 ^ x < 2 ^ k) :
    (256 : ℤ) ^ x < 100 ^ x * ((2 : ℤ) ^ k - 3 ^ x)
    -- Equivalent to: 2^k - 3^x > (2.56)^x, scaled to avoid rationals

/-- **Lemma 3.2.** If there is a non-trivial positive integer circuit of length k
    with x odd terms, then `2 · (3/2)^x ≥ 2^{k-x} - 1`.

    Restated in integer form: if `3^x - 2^x ≥ 2^k - 3^x` (i.e., f(vc) ≥ 1),
    then `2 · 3^x ≥ 2^k + 2^x`. -/
theorem circuit_lower_bound (k x : ℕ) (hpos : 3 ^ x < 2 ^ k)
    (hint : bsIsInteger k x (circuitBits k x))
    (hge1 : (3 : ℤ) ^ x - 2 ^ x ≥ 2 ^ k - 3 ^ x) :
    2 * (3 : ℤ) ^ x ≥ 2 ^ k + 2 ^ x := by
  linarith

/-- **Theorem 3.4 (Steiner, 1977).** Axiomatized.
    Non-trivial Collatz circuits do not exist.

    For all k, x with 2^k > 3^x and (k, x) ≠ (2, 1), the circuit formula
    `(3^x - 2^x) / (2^k - 3^x)` is not a positive integer.

    We axiomatize this because its proof requires Ellison's bound (Baker's theory)
    plus finite verification for x ≤ 17. The paper's MAIN result (Theorem 5.4)
    does NOT depend on this theorem. -/
axiom steiner_no_circuits (k x : ℕ) (hpos : 3 ^ x < 2 ^ k) (hne : (k, x) ≠ (2, 1)) :
    ¬ bsIsInteger k x (circuitBits k x)
