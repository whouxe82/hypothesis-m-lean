/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Knight2026.ParityVec

Properties of parity vectors, the Böhm-Sontacchi formula, and rotation.

## Overview

This file establishes:
1. Basic properties of `onePositions` (monotonicity, boundedness, length = count)
2. That rotation preserves length, count, and the positivity constraint
3. That rotation produces another member of the same rational cycle
4. The relationship between g(v), g(rotated v), and the rational cycle formula

## Design Notes

### onePositions properties
The positions list returned by `onePositions` is strictly increasing and bounded by the
list length. These are essential for connecting our definition to the paper's d_0 < d_1 < ...
< d_{x-1} notation. We prove these as standalone lemmas so they can be reused.

### Rotation as cycle membership
The paper uses the fact that rotating a parity vector produces another entry point into the
same rational Collatz cycle. We formalize this by showing that if `v` has a ParityVec
structure, then `rotateVec v n` also does, and both yield the same rational cycle.
-/

import Knight2026.Defs

/-! ## Properties of onePositions -/

/-- The length of `onePositions v` equals the count of `true` in `v`. -/
theorem onePositions_length : ∀ (v : List Bool),
    (onePositions v).length = v.count true := by
  intro v
  induction v with
  | nil => simp [onePositions]
  | cons b rest ih =>
    cases b <;> simp [onePositions, ih]

/-- All positions returned by `onePositions` are less than the list length. -/
theorem onePositions_bounded : ∀ (v : List Bool) (d : ℕ),
    d ∈ onePositions v → d < v.length := by
  intro v
  induction v with
  | nil => simp [onePositions]
  | cons b rest ih =>
    intro d hd
    cases b
    · -- b = false
      simp only [onePositions] at hd
      rw [List.mem_map] at hd
      obtain ⟨d', hd'_mem, rfl⟩ := hd
      simp only [List.length_cons]
      exact Nat.succ_lt_succ (ih d' hd'_mem)
    · -- b = true
      simp only [onePositions] at hd
      rcases List.mem_cons.mp hd with rfl | hd_rest
      · simp only [List.length_cons]; omega
      · rw [List.mem_map] at hd_rest
        obtain ⟨d', hd'_mem, rfl⟩ := hd_rest
        simp only [List.length_cons]
        exact Nat.succ_lt_succ (ih d' hd'_mem)

/-- Helper: map (· + 1) preserves Pairwise (· < ·). -/
private theorem map_succ_pairwise_lt (l : List ℕ) (h : l.Pairwise (· < ·)) :
    (l.map (· + 1)).Pairwise (· < ·) := by
  induction l with
  | nil => simp
  | cons a rest ih =>
    simp only [List.map_cons, List.pairwise_cons] at h ⊢
    exact ⟨fun b hb => by
      rw [List.mem_map] at hb
      obtain ⟨b', hb'_mem, rfl⟩ := hb
      exact Nat.succ_lt_succ (h.1 b' hb'_mem), ih h.2⟩

/-- `onePositions` returns a strictly increasing list. -/
theorem onePositions_strictMono (v : List Bool) :
    (onePositions v).Pairwise (· < ·) := by
  induction v with
  | nil => simp [onePositions]
  | cons b rest ih =>
    cases b
    · -- b = false: onePositions (false :: rest) = map (·+1) (onePositions rest)
      simp only [onePositions]
      exact map_succ_pairwise_lt _ ih
    · -- b = true: onePositions (true :: rest) = 0 :: map (·+1) (onePositions rest)
      simp only [onePositions, List.pairwise_cons]
      exact ⟨fun b hb => by
        rw [List.mem_map] at hb
        obtain ⟨b', _, rfl⟩ := hb
        omega, map_succ_pairwise_lt _ ih⟩

/-! ## Rotation preserves ParityVec structure -/

/-- Rotating a list preserves the count of any element.
    Follows from `List.perm_rotate` and `List.Perm.count_eq`. -/
theorem rotate_count (v : List Bool) (n : ℕ) (b : Bool) :
    (v.rotate n).count b = v.count b := by
  exact List.Perm.count_eq (List.rotate_perm v n) b

/-- A rotated ParityVec yields another valid ParityVec. -/
def ParityVec.rotate {k x : ℕ} (pv : ParityVec k x) (n : ℕ) : ParityVec k x where
  bits := pv.bits.rotate n
  length_eq := by rw [List.length_rotate]; exact pv.length_eq
  count_eq := by rw [rotate_count]; exact pv.count_eq
  pos_denom := pv.pos_denom

/-! ## Reversal preserves ParityVec structure -/

/-- Reversing a list preserves count. -/
theorem reverse_count (v : List Bool) (b : Bool) :
    v.reverse.count b = v.count b := by
  simp [List.count_reverse]

/-- A reversed ParityVec yields another valid ParityVec. -/
def ParityVec.reverse {k x : ℕ} (pv : ParityVec k x) : ParityVec k x where
  bits := pv.bits.reverse
  length_eq := by rw [List.length_reverse]; exact pv.length_eq
  count_eq := by rw [reverse_count]; exact pv.count_eq
  pos_denom := pv.pos_denom

/-! ## The Böhm-Sontacchi formula under rotation -/

/-- Rotation produces a member of the same rational Collatz cycle.
    If v' is a rotation of v, then f(v) and f(v') are both entry points
    of the same rational cycle, and all cycle members share the common
    denominator 2^k - 3^x. -/
theorem rotation_same_denominator (k x : ℕ) (v : List Bool) (n : ℕ) :
    bsFormula k x (v.rotate n) =
      (bsNumerator (v.rotate n) : ℚ) / (bsDenominator k x : ℚ) := by
  rfl
