import Knight2026.Defs
import Mathlib.Tactic

/-! ## Structural lemmas for onePositions -/

@[simp]
theorem onePositions_nil : onePositions [] = [] := rfl

@[simp]
theorem onePositions_cons_true (rest : List Bool) :
    onePositions (true :: rest) = 0 :: (onePositions rest).map (· + 1) := rfl

@[simp]
theorem onePositions_cons_false (rest : List Bool) :
    onePositions (false :: rest) = (onePositions rest).map (· + 1) := rfl

theorem onePositions_append_false (v : List Bool) :
    onePositions (v ++ [false]) = onePositions v := by
  induction v with
  | nil => simp [onePositions]
  | cons h t ih =>
    cases h <;> simp [onePositions, ih]

theorem onePositions_append_true (v : List Bool) :
    onePositions (v ++ [true]) = onePositions v ++ [v.length] := by
  induction v with
  | nil => simp [onePositions]
  | cons h t ih =>
    cases h <;> simp [onePositions, ih, List.map_append]

/-! ## Structural lemmas for bsNumeratorAux -/

@[simp]
theorem bsNumeratorAux_nil (i : ℕ) : bsNumeratorAux [] i = 0 := rfl

@[simp]
theorem bsNumeratorAux_cons (d : ℕ) (rest : List ℕ) (i : ℕ) :
    bsNumeratorAux (d :: rest) i = 2 ^ d * 3 ^ i + bsNumeratorAux rest (i - 1) := rfl

theorem bsNumeratorAux_map_succ (ps : List ℕ) (i : ℕ) :
    bsNumeratorAux (ps.map (· + 1)) i = 2 * bsNumeratorAux ps i := by
  induction ps generalizing i with
  | nil => simp
  | cons p rest ih =>
    simp only [List.map_cons, bsNumeratorAux_cons, ih]
    ring

/-! ## Decomposition of bsNumerator -/

theorem onePositions_length_cons_true (rest : List Bool) :
    (onePositions (true :: rest)).length = (onePositions rest).length + 1 := by
  simp [onePositions, List.length_map]

theorem onePositions_length_cons_false (rest : List Bool) :
    (onePositions (false :: rest)).length = (onePositions rest).length := by
  simp [onePositions, List.length_map]

/-! ## Simple cons/append lemmas for bsNumerator -/

/-- Prepending `false` doubles the numerator (shifts all positions by +1). -/
theorem bsNumerator_cons_false (rest : List Bool) :
    bsNumerator (false :: rest) = 2 * bsNumerator rest := by
  unfold bsNumerator
  simp only [onePositions_cons_false, List.length_map]
  exact bsNumeratorAux_map_succ (onePositions rest) ((onePositions rest).length - 1)

/-- Appending `false` preserves the numerator (no new 1-position). -/
theorem bsNumerator_append_false (v : List Bool) :
    bsNumerator (v ++ [false]) = bsNumerator v := by
  unfold bsNumerator
  rw [onePositions_append_false]

/-- Prepending `true` adds 3^(count of 1s in rest) and doubles. -/
theorem bsNumerator_cons_true (rest : List Bool) :
    bsNumerator (true :: rest) = 2 * bsNumerator rest + 3 ^ ((onePositions rest).length) := by
  unfold bsNumerator
  simp only [onePositions_cons_true, List.length_cons, List.length_map]
  set ps := onePositions rest
  set m := ps.length
  rw [show m + 1 - 1 = m from by omega]
  simp only [bsNumeratorAux_cons, pow_zero, one_mul]
  rw [bsNumeratorAux_map_succ]
  ring

/-! ## Combined decomposition lemmas -/

/-- The `onePositions` length equals the count of trues. -/
theorem onePositions_length (v : List Bool) :
    (onePositions v).length = v.count true := by
  induction v with
  | nil => simp [onePositions]
  | cons h t ih =>
    cases h <;> simp [onePositions, List.length_map, ih, List.count_cons]

theorem bsNumerator_cons_true_append_false (u : List Bool) :
    bsNumerator (true :: u ++ [false]) = 2 * bsNumerator u + 3 ^ ((onePositions u).length) := by
  unfold bsNumerator
  simp only [onePositions_cons_true, onePositions_append_false]
  simp only [List.length_cons, List.length_map]
  set ps := onePositions u
  set m := ps.length
  rw [show m + 1 - 1 = m from by omega]
  simp only [bsNumeratorAux_cons, pow_zero, one_mul]
  rw [bsNumeratorAux_map_succ]
  ring

theorem bsNumeratorAux_append_singleton (ps : List ℕ) (d : ℕ) :
    bsNumeratorAux (ps ++ [d]) ps.length = 3 * bsNumeratorAux ps (ps.length - 1) + 2 ^ d := by
  induction ps with
  | nil => simp [bsNumeratorAux]
  | cons p rest ih =>
    simp only [List.cons_append, bsNumeratorAux_cons, List.length_cons]
    rw [show rest.length + 1 - 1 = rest.length from by omega]
    rw [ih]
    ring

/-- Appending `true` triples and adds 2^(length). -/
theorem bsNumerator_append_true (v : List Bool) :
    bsNumerator (v ++ [true]) = 3 * bsNumerator v + 2 ^ v.length := by
  show bsNumeratorAux (onePositions (v ++ [true]))
    ((onePositions (v ++ [true])).length - 1) = _
  rw [onePositions_append_true]
  set qs := onePositions v ++ [v.length]
  have hlen : qs.length = (onePositions v).length + 1 := by simp [qs]
  rw [hlen, show (onePositions v).length + 1 - 1 = (onePositions v).length from by omega]
  -- Goal: bsNumeratorAux qs (onePositions v).length = ...
  -- qs = onePositions v ++ [v.length], so use bsNumeratorAux_append_singleton
  show bsNumeratorAux (onePositions v ++ [v.length]) (onePositions v).length = _
  rw [bsNumeratorAux_append_singleton]
  show _ = 3 * bsNumerator v + 2 ^ v.length
  unfold bsNumerator
  ring

theorem bsNumerator_cons_false_append_true (u : List Bool) :
    bsNumerator (false :: u ++ [true]) = 6 * bsNumerator u + 2 ^ (u.length + 1) := by
  unfold bsNumerator
  simp only [onePositions_cons_false, onePositions_append_true]
  -- After simp, the map is already distributed.
  -- Goal has: (onePositions u).map (· + 1) ++ [(false :: u).length]
  -- and (false :: u).length = u.length + 1
  set ps := onePositions u
  set m := ps.length
  simp only [List.length_cons]
  -- Now (false :: u).length became u.length + 1
  rw [List.length_append, List.length_map, List.length_singleton]
  rw [show m + 1 - 1 = m from by omega]
  have hlen : (ps.map (· + 1)).length = m := List.length_map ..
  rw [show m = (ps.map (· + 1)).length from hlen.symm]
  rw [bsNumeratorAux_append_singleton (ps.map (· + 1)) (u.length + 1)]
  rw [hlen]
  rw [bsNumeratorAux_map_succ]
  ring
