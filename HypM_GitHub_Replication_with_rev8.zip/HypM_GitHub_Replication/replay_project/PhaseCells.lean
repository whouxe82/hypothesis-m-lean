import Mathlib

/-!
Exact rational six-symbol coefficient cells for Hypothesis M.
This file proves statements about the explicit rational critical map. It does
not, by itself, formalize the bridge from a Collatz prefix to that map.
-/
namespace HypothesisMPhaseCells

def criticalBit (c : ℚ) : Bool := if c < 2 then true else false

def criticalStep (c : ℚ) : ℚ := if c < 2 then 3 * c / 2 else c / 2

def parityWord : ℕ → ℚ → List Bool
  | 0, _ => []
  | n + 1, c => criticalBit c :: parityWord n (criticalStep c)

theorem word_odd (n : ℕ) (c : ℚ) (h : c < 2) :
    parityWord (n + 1) c = true :: parityWord n (3 * c / 2) := by
  simp [parityWord, criticalBit, criticalStep, h]

theorem word_even (n : ℕ) (c : ℚ) (h : 2 ≤ c) :
    parityWord (n + 1) c = false :: parityWord n (c / 2) := by
  simp [parityWord, criticalBit, criticalStep, not_lt.mpr h]

theorem cell0 (c : ℚ) (hl : 1 ≤ c) (hu : c < 32 / 27) :
    parityWord 6 c = [true, true, false, true, true, false] := by
  have h0 : c < 2 := by linarith
  have h1 : (3 * c / 2) < 2 := by linarith
  have h2 : 2 ≤ (3 * (3 * c / 2) / 2) := by linarith
  have h3 : ((3 * (3 * c / 2) / 2) / 2) < 2 := by linarith
  have h4 : (3 * ((3 * (3 * c / 2) / 2) / 2) / 2) < 2 := by linarith
  have h5 : 2 ≤ (3 * (3 * ((3 * (3 * c / 2) / 2) / 2) / 2) / 2) := by linarith
  rw [word_odd 5 (c) h0,
    word_odd 4 ((3 * c / 2)) h1,
    word_even 3 ((3 * (3 * c / 2) / 2)) h2,
    word_odd 2 (((3 * (3 * c / 2) / 2) / 2)) h3,
    word_odd 1 ((3 * ((3 * (3 * c / 2) / 2) / 2) / 2)) h4,
    word_even 0 ((3 * (3 * ((3 * (3 * c / 2) / 2) / 2) / 2) / 2)) h5, parityWord]

theorem cell1 (c : ℚ) (hl : 32 / 27 ≤ c) (hu : c < 4 / 3) :
    parityWord 6 c = [true, true, false, true, false, true] := by
  have h0 : c < 2 := by linarith
  have h1 : (3 * c / 2) < 2 := by linarith
  have h2 : 2 ≤ (3 * (3 * c / 2) / 2) := by linarith
  have h3 : ((3 * (3 * c / 2) / 2) / 2) < 2 := by linarith
  have h4 : 2 ≤ (3 * ((3 * (3 * c / 2) / 2) / 2) / 2) := by linarith
  have h5 : ((3 * ((3 * (3 * c / 2) / 2) / 2) / 2) / 2) < 2 := by linarith
  rw [word_odd 5 (c) h0,
    word_odd 4 ((3 * c / 2)) h1,
    word_even 3 ((3 * (3 * c / 2) / 2)) h2,
    word_odd 2 (((3 * (3 * c / 2) / 2) / 2)) h3,
    word_even 1 ((3 * ((3 * (3 * c / 2) / 2) / 2) / 2)) h4,
    word_odd 0 (((3 * ((3 * (3 * c / 2) / 2) / 2) / 2) / 2)) h5, parityWord]

theorem cell2 (c : ℚ) (hl : 4 / 3 ≤ c) (hu : c < 16 / 9) :
    parityWord 6 c = [true, false, true, true, false, true] := by
  have h0 : c < 2 := by linarith
  have h1 : 2 ≤ (3 * c / 2) := by linarith
  have h2 : ((3 * c / 2) / 2) < 2 := by linarith
  have h3 : (3 * ((3 * c / 2) / 2) / 2) < 2 := by linarith
  have h4 : 2 ≤ (3 * (3 * ((3 * c / 2) / 2) / 2) / 2) := by linarith
  have h5 : ((3 * (3 * ((3 * c / 2) / 2) / 2) / 2) / 2) < 2 := by linarith
  rw [word_odd 5 (c) h0,
    word_even 4 ((3 * c / 2)) h1,
    word_odd 3 (((3 * c / 2) / 2)) h2,
    word_odd 2 ((3 * ((3 * c / 2) / 2) / 2)) h3,
    word_even 1 ((3 * (3 * ((3 * c / 2) / 2) / 2) / 2)) h4,
    word_odd 0 (((3 * (3 * ((3 * c / 2) / 2) / 2) / 2) / 2)) h5, parityWord]

theorem cell3 (c : ℚ) (hl : 16 / 9 ≤ c) (hu : c < 2) :
    parityWord 6 c = [true, false, true, false, true, true] := by
  have h0 : c < 2 := by linarith
  have h1 : 2 ≤ (3 * c / 2) := by linarith
  have h2 : ((3 * c / 2) / 2) < 2 := by linarith
  have h3 : 2 ≤ (3 * ((3 * c / 2) / 2) / 2) := by linarith
  have h4 : ((3 * ((3 * c / 2) / 2) / 2) / 2) < 2 := by linarith
  have h5 : (3 * ((3 * ((3 * c / 2) / 2) / 2) / 2) / 2) < 2 := by linarith
  rw [word_odd 5 (c) h0,
    word_even 4 ((3 * c / 2)) h1,
    word_odd 3 (((3 * c / 2) / 2)) h2,
    word_even 2 ((3 * ((3 * c / 2) / 2) / 2)) h3,
    word_odd 1 (((3 * ((3 * c / 2) / 2) / 2) / 2)) h4,
    word_odd 0 ((3 * ((3 * ((3 * c / 2) / 2) / 2) / 2) / 2)) h5, parityWord]

theorem cell4 (c : ℚ) (hl : 2 ≤ c) (hu : c < 64 / 27) :
    parityWord 6 c = [false, true, true, false, true, true] := by
  have h0 : 2 ≤ c := by linarith
  have h1 : (c / 2) < 2 := by linarith
  have h2 : (3 * (c / 2) / 2) < 2 := by linarith
  have h3 : 2 ≤ (3 * (3 * (c / 2) / 2) / 2) := by linarith
  have h4 : ((3 * (3 * (c / 2) / 2) / 2) / 2) < 2 := by linarith
  have h5 : (3 * ((3 * (3 * (c / 2) / 2) / 2) / 2) / 2) < 2 := by linarith
  rw [word_even 5 (c) h0,
    word_odd 4 ((c / 2)) h1,
    word_odd 3 ((3 * (c / 2) / 2)) h2,
    word_even 2 ((3 * (3 * (c / 2) / 2) / 2)) h3,
    word_odd 1 (((3 * (3 * (c / 2) / 2) / 2) / 2)) h4,
    word_odd 0 ((3 * ((3 * (3 * (c / 2) / 2) / 2) / 2) / 2)) h5, parityWord]

theorem cell5 (c : ℚ) (hl : 64 / 27 ≤ c) (hu : c < 8 / 3) :
    parityWord 6 c = [false, true, true, false, true, false] := by
  have h0 : 2 ≤ c := by linarith
  have h1 : (c / 2) < 2 := by linarith
  have h2 : (3 * (c / 2) / 2) < 2 := by linarith
  have h3 : 2 ≤ (3 * (3 * (c / 2) / 2) / 2) := by linarith
  have h4 : ((3 * (3 * (c / 2) / 2) / 2) / 2) < 2 := by linarith
  have h5 : 2 ≤ (3 * ((3 * (3 * (c / 2) / 2) / 2) / 2) / 2) := by linarith
  rw [word_even 5 (c) h0,
    word_odd 4 ((c / 2)) h1,
    word_odd 3 ((3 * (c / 2) / 2)) h2,
    word_even 2 ((3 * (3 * (c / 2) / 2) / 2)) h3,
    word_odd 1 (((3 * (3 * (c / 2) / 2) / 2) / 2)) h4,
    word_even 0 ((3 * ((3 * (3 * (c / 2) / 2) / 2) / 2) / 2)) h5, parityWord]

theorem cell6 (c : ℚ) (hl : 8 / 3 ≤ c) (hu : c < 3) :
    parityWord 6 c = [false, true, false, true, true, false] := by
  have h0 : 2 ≤ c := by linarith
  have h1 : (c / 2) < 2 := by linarith
  have h2 : 2 ≤ (3 * (c / 2) / 2) := by linarith
  have h3 : ((3 * (c / 2) / 2) / 2) < 2 := by linarith
  have h4 : (3 * ((3 * (c / 2) / 2) / 2) / 2) < 2 := by linarith
  have h5 : 2 ≤ (3 * (3 * ((3 * (c / 2) / 2) / 2) / 2) / 2) := by linarith
  rw [word_even 5 (c) h0,
    word_odd 4 ((c / 2)) h1,
    word_even 3 ((3 * (c / 2) / 2)) h2,
    word_odd 2 (((3 * (c / 2) / 2) / 2)) h3,
    word_odd 1 ((3 * ((3 * (c / 2) / 2) / 2) / 2)) h4,
    word_even 0 ((3 * (3 * ((3 * (c / 2) / 2) / 2) / 2) / 2)) h5, parityWord]

theorem phaseCases (c : ℚ) (hl : 1 ≤ c) (hu : c < 3) :
    (1 ≤ c ∧ c < 32 / 27 ∧ parityWord 6 c = [true, true, false, true, true, false]) ∨
    (32 / 27 ≤ c ∧ c < 4 / 3 ∧ parityWord 6 c = [true, true, false, true, false, true]) ∨
    (4 / 3 ≤ c ∧ c < 16 / 9 ∧ parityWord 6 c = [true, false, true, true, false, true]) ∨
    (16 / 9 ≤ c ∧ c < 2 ∧ parityWord 6 c = [true, false, true, false, true, true]) ∨
    (2 ≤ c ∧ c < 64 / 27 ∧ parityWord 6 c = [false, true, true, false, true, true]) ∨
    (64 / 27 ≤ c ∧ c < 8 / 3 ∧ parityWord 6 c = [false, true, true, false, true, false]) ∨
    (8 / 3 ≤ c ∧ c < 3 ∧ parityWord 6 c = [false, true, false, true, true, false]) := by
  by_cases h0 : c < 32 / 27
  · exact Or.inl ⟨hl, h0, cell0 c hl h0⟩
  · right
    have l1 : 32 / 27 ≤ c := le_of_not_gt h0
    by_cases h1 : c < 4 / 3
    · exact Or.inl ⟨l1, h1, cell1 c l1 h1⟩
    · right
      have l2 : 4 / 3 ≤ c := le_of_not_gt h1
      by_cases h2 : c < 16 / 9
      · exact Or.inl ⟨l2, h2, cell2 c l2 h2⟩
      · right
        have l3 : 16 / 9 ≤ c := le_of_not_gt h2
        by_cases h3 : c < 2
        · exact Or.inl ⟨l3, h3, cell3 c l3 h3⟩
        · right
          have l4 : 2 ≤ c := le_of_not_gt h3
          by_cases h4 : c < 64 / 27
          · exact Or.inl ⟨l4, h4, cell4 c l4 h4⟩
          · right
            have l5 : 64 / 27 ≤ c := le_of_not_gt h4
            by_cases h5 : c < 8 / 3
            · exact Or.inl ⟨l5, h5, cell5 c l5 h5⟩
            · right
              have l6 : 8 / 3 ≤ c := le_of_not_gt h5
              exact ⟨l6, hu, cell6 c l6 hu⟩

/-- Matching six critical symbols confines two coefficients to a common
exact rational cell, whose diameter is at most 4/9. -/
theorem sameWord_diameter (a b : ℚ)
    (ha1 : 1 ≤ a) (ha3 : a < 3) (hb1 : 1 ≤ b) (hb3 : b < 3)
    (heq : parityWord 6 a = parityWord 6 b) : |a - b| ≤ 4 / 9 := by
  rcases phaseCases a ha1 ha3 with ⟨haL, haU, haW⟩ | ⟨haL, haU, haW⟩ | ⟨haL, haU, haW⟩ | ⟨haL, haU, haW⟩ | ⟨haL, haU, haW⟩ | ⟨haL, haU, haW⟩ | ⟨haL, haU, haW⟩
  all_goals rcases phaseCases b hb1 hb3 with ⟨hbL, hbU, hbW⟩ | ⟨hbL, hbU, hbW⟩ | ⟨hbL, hbU, hbW⟩ | ⟨hbL, hbU, hbW⟩ | ⟨hbL, hbU, hbW⟩ | ⟨hbL, hbU, hbW⟩ | ⟨hbL, hbU, hbW⟩
  all_goals rw [haW, hbW] at heq
  all_goals norm_num at heq
  all_goals exact abs_le.mpr ⟨by linarith, by linarith⟩

#print axioms sameWord_diameter

end HypothesisMPhaseCells
