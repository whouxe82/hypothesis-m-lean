import MStatement

/-!
Exact finite seed cases and the arithmetic horizon parameters for Hypothesis M.
All finite witnesses below are checked by Lean's ordinary `decide` tactic.
No universal statement of M is assumed or declared in this module.
-/

set_option maxRecDepth 200000
set_option maxHeartbeats 1000000

namespace HypothesisMTarget

/-- Every even seed exits the coefficient corridor at the first shortcut step. -/
theorem even_seed_meets_bound (n : ℕ) (heven : n % 2 = 0) :
    CoefficientExitWithin n (Nat.log2 (n * n) + 1) := by
  refine ⟨1, by omega, by omega, Or.inl ?_⟩
  simp [oddCount, orbit, heven]

/-- All seeds 2 through 63 meet the exact frozen seed-form bound. -/
theorem small_seeds_meet_bound (n : ℕ) (hn : 2 ≤ n) (hsmall : n < 64) :
    CoefficientExitWithin n (Nat.log2 (n * n) + 1) := by
  interval_cases n
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨4, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨5, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨4, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨6, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨4, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨5, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨4, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨7, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨2, by decide, by decide, by decide⟩
  · exact ⟨1, by decide, by decide, by decide⟩
  · exact ⟨3, by decide, by decide, by decide⟩

/-- The chosen integer horizon strictly exceeds log base two of the seed square. -/
theorem square_lt_horizon_power (n : ℕ) :
    n * n < 2 ^ (Nat.log2 (n * n) + 1) := Nat.lt_log2_self

/-- Seeds at least 64 have horizon at least 13. -/
theorem large_seed_horizon (n : ℕ) (hn : 64 ≤ n) :
    13 ≤ Nat.log2 (n * n) + 1 := by
  have hn0 : n ≠ 0 := by omega
  have hs0 : n * n ≠ 0 := Nat.mul_ne_zero hn0 hn0
  have hs : (2 : ℕ) ^ 12 ≤ n * n := by
    have h := Nat.mul_le_mul hn hn
    norm_num at h ⊢
    exact h
  have hl : 12 ≤ Nat.log2 (n * n) := (Nat.le_log2 hs0).mpr hs
  omega

/-- The half-horizon has the required block-window inequalities. -/
theorem half_horizon_bounds (L : ℕ) (hL : 13 ≤ L) :
    6 ≤ (L - 1) / 2 ∧
      2 * ((L - 1) / 2) + 1 ≤ L ∧ L ≤ 2 * ((L - 1) / 2) + 2 := by
  omega

/-- The square-root estimate used by the collision proof, in exact naturals. -/
theorem seed_lt_half_horizon_power (n L k : ℕ)
    (hL : L = Nat.log2 (n * n) + 1) (hk : k = (L - 1) / 2) :
    n < 2 ^ (k + 1) := by
  have hLpos : 1 ≤ L := by omega
  have hupper : L ≤ 2 * k + 2 := by omega
  have hs : n * n < 2 ^ L := by rw [hL]; exact square_lt_horizon_power n
  have hp : (2 : ℕ) ^ L ≤ 2 ^ (2 * k + 2) :=
    Nat.pow_le_pow_right (by omega) hupper
  have he : (2 : ℕ) ^ (2 * k + 2) = 2 ^ (k + 1) * 2 ^ (k + 1) := by
    rw [show 2 * k + 2 = (k + 1) + (k + 1) by omega, pow_add]
  rw [he] at hp
  exact Nat.mul_self_lt_mul_self_iff.mp (lt_of_lt_of_le hs hp)

/-- One packaged arithmetic interface for the large-seed branch. -/
theorem large_seed_parameters (n L k : ℕ) (hn : 64 ≤ n)
    (hL : L = Nat.log2 (n * n) + 1) (hk : k = (L - 1) / 2) :
    13 ≤ L ∧ 6 ≤ k ∧ 2 * k + 1 ≤ L ∧ L ≤ 2 * k + 2 ∧ n < 2 ^ (k + 1) := by
  have hlarge : 13 ≤ L := by rw [hL]; exact large_seed_horizon n hn
  obtain ⟨hk6, hlo, hup⟩ := half_horizon_bounds L hlarge
  rw [← hk] at hk6 hlo hup
  exact ⟨hlarge, hk6, hlo, hup, seed_lt_half_horizon_power n L k hL hk⟩

#print axioms even_seed_meets_bound
#print axioms small_seeds_meet_bound
#print axioms square_lt_horizon_power
#print axioms large_seed_horizon
#print axioms half_horizon_bounds
#print axioms seed_lt_half_horizon_power
#print axioms large_seed_parameters

end HypothesisMTarget
