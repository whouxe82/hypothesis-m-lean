import OrbitArithmetic
import CriticalPrefix
import Knight2026.BsLemmas

/-!
The exact Böhm–Sontacchi identity for words actually read from the frozen
shortcut orbit, and arithmetic consequences for positive return orbits.
-/

set_option maxHeartbeats 1000000

namespace HypothesisMWordAffine
open HypothesisMTarget HypothesisMOrbit HypothesisMCritical

theorem orbitWord_length (n start len : ℕ) :
    (orbitWord n start len).length = len := by
  induction len generalizing start with
  | zero => rfl
  | succ len ih => simp [orbitWord, ih]

/-- The exact affine identity for an actual parity block. -/
theorem orbit_word_affine (n start len : ℕ) :
    2 ^ len * orbit n (start + len) =
      3 ^ ((orbitWord n start len).count true) * orbit n start +
        bsNumerator (orbitWord n start len) := by
  induction len generalizing start with
  | zero => simp [orbitWord, bsNumerator]
  | succ len ih =>
    have ht := ih (start + 1)
    rw [show start + 1 + len = start + (len + 1) by omega] at ht
    have ht2 := congrArg (fun z : ℕ => 2 * z) ht
    by_cases ho : orbit n start % 2 = 1
    · have hs := shortcut_odd (orbit n start) ho
      change 2 * orbit n (start + 1) = 3 * orbit n start + 1 at hs
      have hs3 := congrArg
        (fun z : ℕ => 3 ^ ((orbitWord n (start + 1) len).count true) * z) hs
      simp only [orbitWord, ho, decide_true, List.count_cons_self,
        bsNumerator_cons_true, onePositions_length, pow_succ]
      nlinarith only [ht2, hs3]
    · have he : orbit n start % 2 = 0 := by omega
      have hs := shortcut_even (orbit n start) he
      change 2 * orbit n (start + 1) = orbit n start at hs
      have hs3 := congrArg
        (fun z : ℕ => 3 ^ ((orbitWord n (start + 1) len).count true) * z) hs
      simp only [orbitWord, ho, decide_false, List.count_cons_of_ne (by decide : false ≠ true),
        bsNumerator_cons_false, pow_succ]
      nlinarith only [ht2, hs3]

/-- A word with no odd symbols has zero additive numerator. -/
theorem numerator_zero_of_count_zero (w : List Bool) (h : w.count true = 0) :
    bsNumerator w = 0 := by
  induction w with
  | nil => rfl
  | cons b w ih =>
    cases b with
    | false =>
      have hw : w.count true = 0 := by simpa using h
      rw [bsNumerator_cons_false, ih hw]
    | true => simp at h

/-- A word containing an odd symbol has a positive additive numerator. -/
theorem numerator_pos_of_count_pos (w : List Bool) (h : 0 < w.count true) :
    0 < bsNumerator w := by
  induction w with
  | nil => simp at h
  | cons b w ih =>
    cases b with
    | false =>
      have hw : 0 < w.count true := by simpa using h
      rw [bsNumerator_cons_false]
      exact Nat.mul_pos (by omega) (ih hw)
    | true =>
      rw [bsNumerator_cons_true]
      have hp : 0 < (3 : ℕ) ^ (onePositions w).length := by positivity
      omega

/-- A positive return orbit of positive length must use an odd step. -/
theorem return_odd_count_pos (n p : ℕ) (hn : 0 < n) (hp : 0 < p)
    (hr : orbit n p = n) : 0 < (orbitWord n 0 p).count true := by
  have ha := orbit_word_affine n 0 p
  simp only [Nat.zero_add, orbit, hr] at ha
  by_contra hq
  have hq0 : (orbitWord n 0 p).count true = 0 := by omega
  have hb := numerator_zero_of_count_zero _ hq0
  rw [hq0, hb] at ha
  norm_num at ha
  have hpow : 1 < (2 : ℕ) ^ p := Nat.one_lt_two_pow (by omega)
  nlinarith only [ha, hn, hpow]

/-- The positive cycle denominator inequality follows from actual dynamics. -/
theorem return_power_lt (n p : ℕ) (hn : 0 < n) (hp : 0 < p)
    (hr : orbit n p = n) :
    3 ^ ((orbitWord n 0 p).count true) < 2 ^ p := by
  have hq := return_odd_count_pos n p hn hp hr
  have hb := numerator_pos_of_count_pos _ hq
  have ha := orbit_word_affine n 0 p
  simp only [Nat.zero_add, orbit, hr] at ha
  by_contra h
  have hle : 2 ^ p ≤ 3 ^ ((orbitWord n 0 p).count true) := by omega
  have hm := Nat.mul_le_mul_right n hle
  omega

/-- A positive return orbit has fewer odd steps than total steps. -/
theorem return_odd_count_lt (n p : ℕ) (hn : 0 < n) (hp : 0 < p)
    (hr : orbit n p = n) : (orbitWord n 0 p).count true < p := by
  have hpow := return_power_lt n p hn hp hr
  by_contra h
  have hq : p ≤ (orbitWord n 0 p).count true := by omega
  have hlo : (2 : ℕ) ^ p ≤ 3 ^ p := Nat.pow_le_pow_left (by omega) p
  have hhi : (3 : ℕ) ^ p ≤ 3 ^ ((orbitWord n 0 p).count true) :=
    Nat.pow_le_pow_right (by omega) hq
  omega

/-- Integrality of the Böhm–Sontacchi formula is proved from the return identity. -/
theorem return_bsIsInteger (n p : ℕ) (hr : orbit n p = n) :
    bsIsInteger p ((orbitWord n 0 p).count true) (orbitWord n 0 p) := by
  have ha := orbit_word_affine n 0 p
  simp only [Nat.zero_add, orbit, hr] at ha
  have hz : (2 : ℤ) ^ p * n =
      (3 : ℤ) ^ ((orbitWord n 0 p).count true) * n +
        (bsNumerator (orbitWord n 0 p) : ℤ) := by exact_mod_cast ha
  unfold bsIsInteger bsDenominator
  refine ⟨(n : ℤ), ?_⟩
  nlinarith only [hz]

/-- Positivity of the integer denominator. -/
theorem return_bsDenominator_pos (n p : ℕ) (hn : 0 < n) (hp : 0 < p)
    (hr : orbit n p = n) :
    0 < bsDenominator p ((orbitWord n 0 p).count true) := by
  have h := return_power_lt n p hn hp hr
  unfold bsDenominator
  have hz : (3 : ℤ) ^ ((orbitWord n 0 p).count true) < (2 : ℤ) ^ p := by
    exact_mod_cast h
  omega

/-- The complete arithmetic interface required by balanced-cycle exclusion. -/
theorem positive_return_data (n p : ℕ) (hn : 0 < n) (hp : 0 < p)
    (hr : orbit n p = n) :
    0 < (orbitWord n 0 p).count true ∧
      (orbitWord n 0 p).count true < p ∧
      3 ^ ((orbitWord n 0 p).count true) < 2 ^ p ∧
      0 < bsDenominator p ((orbitWord n 0 p).count true) ∧
      bsIsInteger p ((orbitWord n 0 p).count true) (orbitWord n 0 p) := by
  exact ⟨return_odd_count_pos n p hn hp hr, return_odd_count_lt n p hn hp hr,
    return_power_lt n p hn hp hr, return_bsDenominator_pos n p hn hp hr,
    return_bsIsInteger n p hr⟩

#print axioms orbit_word_affine
#print axioms return_odd_count_pos
#print axioms return_power_lt
#print axioms return_odd_count_lt
#print axioms return_bsIsInteger
#print axioms return_bsDenominator_pos
#print axioms positive_return_data

end HypothesisMWordAffine
