import Knight2026.NoHighCycles
import Mathlib.Tactic

/-!
Precisely scoped formal components of the Hypothesis M proof.
This file does not claim to formalize all of Hypothesis M.
The balanced-word classification and the finite-prefix-to-cycle bridge
are not assumptions hidden inside a final theorem here: no final M theorem
is declared. Each result below states all of its hypotheses explicitly.
-/

namespace HypothesisM

theorem collision_margin (k : ℕ) (hk : 6 ≤ k) :
    9 * (k + 1) < 2 ^ k := by
  induction k, hk using Nat.le_induction with
  | base => norm_num
  | succ k hk ih =>
      rw [pow_succ]
      omega

theorem two_copies_fit (i j k L : ℕ)
    (hi : 1 ≤ i) (hij : i < j) (hj : j ≤ k + 1)
    (hL : 2 * k + 1 ≤ L) :
    i + 2 * (j - i) ≤ L := by
  omega

theorem branchP_block_end (k q : ℕ) :
    (q + 1) + (k + 2) = k + q + 3 := by omega

theorem branchP_two_copies (k q : ℕ) (hk : q + 4 ≤ k) :
    1 + 2 * q ≤ k + q + 3 := by omega

theorem canonical_numerator_identity (p q : ℕ) (b : ℤ)
    (hp : 1 ≤ p) (hq : 1 ≤ q) :
    3 * ((3 : ℤ) ^ (q - 1) + 2 * b)
      - (6 * b + (2 : ℤ) ^ (p - 1))
      + ((2 : ℤ) ^ p - (3 : ℤ) ^ q)
      = (2 : ℤ) ^ (p - 1) := by
  have hp' : p = p - 1 + 1 := by omega
  have hq' : q = q - 1 + 1 := by omega
  have h2 : (2 : ℤ) ^ p = 2 * (2 : ℤ) ^ (p - 1) := by
    conv_lhs => rw [hp', pow_succ]
    ring
  have h3 : (3 : ℤ) ^ q = 3 * (3 : ℤ) ^ (q - 1) := by
    conv_lhs => rw [hq', pow_succ]
    ring
  rw [h2, h3]
  ring

theorem fixed_point_identity (D U V A f g : ℚ)
    (hf : D * f = U) (hg : D * g = V)
    (hnum : 3 * U - V + D = A) :
    D * (3 * f - g + 1) = A := by
  nlinarith

theorem canonical_denominator_one (p q : ℕ) (b : ℤ)
    (hp : 1 ≤ p) (hq : 1 ≤ q)
    (hpos : 0 < (2 : ℤ) ^ p - (3 : ℤ) ^ q)
    (hu : ((2 : ℤ) ^ p - (3 : ℤ) ^ q) ∣
      ((3 : ℤ) ^ (q - 1) + 2 * b))
    (hv : ((2 : ℤ) ^ p - (3 : ℤ) ^ q) ∣
      (6 * b + (2 : ℤ) ^ (p - 1))) :
    (2 : ℤ) ^ p - (3 : ℤ) ^ q = 1 := by
  have hdiv : ((2 : ℤ) ^ p - (3 : ℤ) ^ q) ∣
      (2 : ℤ) ^ (p - 1) := by
    rw [← canonical_numerator_identity p q b hp hq]
    exact dvd_add (dvd_sub (dvd_mul_of_dvd_right hu 3) hv) (dvd_refl _)
  have hodd := bsDenominator_odd p q hp
  by_contra hne
  exact odd_not_dvd_pow_two _ _ (by omega) hodd hdiv

theorem mod_eight_exclusion (p q : ℕ) (hp : 3 ≤ p) :
    (2 : ℤ) ^ p - (3 : ℤ) ^ q ≠ 1 := by
  have h3 : (3 : ℤ) ^ q % 8 = 1 ∨ (3 : ℤ) ^ q % 8 = 3 := by
    induction q with
    | zero => norm_num
    | succ q ih =>
        rcases ih with h | h <;> simp [pow_succ, Int.mul_emod, h]
  have h2 : (2 : ℤ) ^ p % 8 = 0 := by
    obtain ⟨r, rfl⟩ := Nat.exists_eq_add_of_le hp
    simp [pow_add, Int.mul_emod]
  intro heq
  have hm : ((3 : ℤ) ^ q + 1) % 8 = 0 := by
    have h : (3 : ℤ) ^ q + 1 = (2 : ℤ) ^ p := by omega
    rw [h]
    exact h2
  rcases h3 with h | h <;> omega

#print axioms collision_margin
#print axioms two_copies_fit
#print axioms branchP_block_end
#print axioms branchP_two_copies
#print axioms canonical_numerator_identity
#print axioms fixed_point_identity
#print axioms canonical_denominator_one
#print axioms mod_eight_exclusion

end HypothesisM
