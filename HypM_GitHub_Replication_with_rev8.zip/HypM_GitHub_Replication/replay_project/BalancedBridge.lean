import HypothesisMCore
import MStatement
import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.BigOperators.Fin

/-! Endpoint-rotation exclusion with every structural hypothesis explicit.
The generic derivation of endpoint rotations from cyclic balance is a
separate combinatorial obligation, not a hypothesis hidden in a definition. -/

namespace HypothesisMBalanced

open scoped BigOperators

def cyclicWeight {p : ℕ} [NeZero p] (w : ZMod p → ℤ) (s : ZMod p) (a : ℕ) : ℤ :=
  ∑ i ∈ Finset.range a, w (s + (i : ZMod p))

def CyclicallyBalanced {p : ℕ} [NeZero p] (w : ZMod p → ℤ) : Prop :=
  ∀ (s t : ZMod p) (a : ℕ), a ≤ p → cyclicWeight w s a ≤ cyclicWeight w t a + 1

def NoShortPeriod {p : ℕ} [NeZero p] (w : ZMod p → ℤ) : Prop :=
  ∀ a : ℕ, 0 < a → a < p → ¬ (∀ s : ZMod p, w (s + a) = w s)

/-- Exact cyclic averaging: every letter occurs `a` times. -/
theorem cyclic_weight_sum {p : ℕ} [NeZero p] (w : ZMod p → ℤ) (a : ℕ) :
    ∑ s : ZMod p, cyclicWeight w s a = (a : ℤ) * ∑ s : ZMod p, w s := by
  unfold cyclicWeight
  rw [Finset.sum_comm]
  have hs (i : ℕ) : (∑ s : ZMod p, w (s + (i : ZMod p))) = ∑ s : ZMod p, w s :=
    Equiv.sum_comp (Equiv.addRight (i : ZMod p)) w
  simp only [hs, Finset.sum_const, Finset.card_range, nsmul_eq_mul]

/-- Balance and averaging give strict one-unit bounds, including the
integral-average case without an endpoint exception. -/
theorem cyclic_weight_bounds {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (hbal : CyclicallyBalanced w) (s : ZMod p) (a : ℕ) (ha : a ≤ p) :
    (p : ℤ) * (cyclicWeight w s a - 1) < (a : ℤ) * ∑ t : ZMod p, w t ∧
    (a : ℤ) * ∑ t : ZMod p, w t < (p : ℤ) * (cyclicWeight w s a + 1) := by
  have hlo : (∑ _t : ZMod p, (cyclicWeight w s a - 1)) <
      ∑ t : ZMod p, cyclicWeight w t a := by
    apply Finset.sum_lt_sum
    · intro t _
      have hh := hbal s t a ha
      omega
    · exact ⟨s, Finset.mem_univ _, by omega⟩
  have hhi : (∑ t : ZMod p, cyclicWeight w t a) <
      ∑ _t : ZMod p, (cyclicWeight w s a + 1) := by
    apply Finset.sum_lt_sum
    · intro t _
      exact hbal t s a ha
    · exact ⟨s, Finset.mem_univ _, by omega⟩
  simpa only [cyclic_weight_sum, Finset.sum_const, Finset.card_univ,
    ZMod.card, nsmul_eq_mul] using And.intro hlo hhi

/-- At an integral average every cyclic factor has that exact weight. -/
theorem cyclic_weight_integral {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (hbal : CyclicallyBalanced w) (s : ZMod p) (a : ℕ) (ha : a ≤ p)
    (z : ℤ) (hz : (a : ℤ) * ∑ t : ZMod p, w t = (p : ℤ) * z) :
    cyclicWeight w s a = z := by
  have hp : 0 < (p : ℤ) := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne p)
  obtain ⟨hl, hu⟩ := cyclic_weight_bounds w hbal s a ha
  rw [hz] at hl hu
  have h1 : cyclicWeight w s a - 1 < z := by nlinarith
  have h2 : z < cyclicWeight w s a + 1 := by nlinarith
  omega

theorem cyclic_weight_add {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (s : ZMod p) (a b : ℕ) :
    cyclicWeight w s (a + b) = cyclicWeight w s a + cyclicWeight w (s + a) b := by
  unfold cyclicWeight
  rw [Finset.sum_range_add]
  simp only [Nat.cast_add, add_assoc]

theorem cyclic_weight_succ {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (s : ZMod p) (a : ℕ) :
    cyclicWeight w s (a + 1) = cyclicWeight w s a + w (s + a) := by
  simp only [cyclicWeight, Finset.sum_range_succ]

theorem cyclic_weight_shift {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (s : ZMod p) (a : ℕ) :
    cyclicWeight w (s + 1) a + w s = cyclicWeight w s a + w (s + a) := by
  have h := cyclic_weight_add w s 1 a
  rw [Nat.add_comm 1 a, cyclic_weight_succ] at h
  simpa [cyclicWeight, add_comm] using h.symm

theorem cyclic_weight_period {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (s : ZMod p) : cyclicWeight w s p = ∑ t : ZMod p, w t := by
  let e : Fin p ≃ ZMod p :=
    { toFun := fun i => (i.val : ZMod p)
      invFun := fun z => ⟨z.val, z.val_lt⟩
      left_inv := fun i => Fin.ext (ZMod.val_natCast_of_lt i.isLt)
      right_inv := fun z => ZMod.natCast_zmod_val z }
  have hfin : (∑ i : Fin p, w (s + (i.val : ZMod p))) = ∑ t : ZMod p, w (s + t) := by
    apply Fintype.sum_equiv e
    intro i
    rfl
  rw [Fin.sum_univ_eq_sum_range (fun j : ℕ => w (s + (j : ZMod p))) p] at hfin
  change cyclicWeight w s p = _ at hfin
  rw [hfin]
  exact Equiv.sum_comp (Equiv.addLeft s) w

def cyclicHeight {p : ℕ} [NeZero p] (w : ZMod p → ℤ) (j : ℕ) : ℤ :=
  (p : ℤ) * cyclicWeight w 0 j - (∑ t : ZMod p, w t) * (j : ℤ)

theorem cyclic_height_period {p : ℕ} [NeZero p] (w : ZMod p → ℤ) (j : ℕ) :
    cyclicHeight w (j + p) = cyclicHeight w j := by
  simp only [cyclicHeight, cyclic_weight_add, cyclic_weight_period, Nat.cast_add]
  ring

theorem cyclic_height_mod {p : ℕ} [NeZero p] (w : ZMod p → ℤ) (j : ℕ) :
    cyclicHeight w j = cyclicHeight w (j % p) := by
  have hp : 0 < p := Nat.pos_of_ne_zero (NeZero.ne p)
  induction j using Nat.strong_induction_on with
  | h j ih =>
    by_cases hj : j < p
    · rw [Nat.mod_eq_of_lt hj]
    · have hsub : j - p < j := by omega
      have he : j = (j - p) + p := by omega
      have hm : j % p = (j - p) % p := Nat.mod_eq_sub_mod (by omega)
      rw [hm]
      calc
        cyclicHeight w j = cyclicHeight w ((j - p) + p) := congrArg _ he
        _ = cyclicHeight w (j - p) := cyclic_height_period w _
        _ = cyclicHeight w ((j - p) % p) := ih _ hsub

theorem cyclic_height_difference {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (s a : ℕ) :
    cyclicHeight w (s + a) - cyclicHeight w s =
      (p : ℤ) * cyclicWeight w s a - (a : ℤ) * ∑ t : ZMod p, w t := by
  simp only [cyclicHeight, cyclic_weight_add, zero_add, Nat.cast_add]
  ring

/-- Rotations at height extrema dominate the rational average in opposite
directions for every prefix. This proves the extremum step without logs. -/
theorem height_extrema {p : ℕ} [NeZero p] (w : ZMod p → ℤ) :
    ∃ s < p, ∃ t < p, ∀ a : ℕ,
      (a : ℤ) * ∑ z : ZMod p, w z ≤ (p : ℤ) * cyclicWeight w s a ∧
      (p : ℤ) * cyclicWeight w t a ≤ (a : ℤ) * ∑ z : ZMod p, w z := by
  have hp : 0 < p := Nat.pos_of_ne_zero (NeZero.ne p)
  have hn : (Finset.range p).Nonempty := ⟨0, Finset.mem_range.mpr hp⟩
  obtain ⟨s, hs, hmin⟩ := Finset.exists_min_image (Finset.range p) (cyclicHeight w) hn
  obtain ⟨t, ht, hmax⟩ := Finset.exists_max_image (Finset.range p) (cyclicHeight w) hn
  refine ⟨s, Finset.mem_range.mp hs, t, Finset.mem_range.mp ht, ?_⟩
  intro a
  have hmin' := hmin ((s + a) % p) (Finset.mem_range.mpr (Nat.mod_lt _ hp))
  have hmax' := hmax ((t + a) % p) (Finset.mem_range.mpr (Nat.mod_lt _ hp))
  rw [← cyclic_height_mod w (s + a)] at hmin'
  rw [← cyclic_height_mod w (t + a)] at hmax'
  have hs' := cyclic_height_difference w s a
  have ht' := cyclic_height_difference w t a
  constructor <;> linarith

/-- An integral block average makes that block length a period of the
letters, by subtracting two adjacent factor weights. -/
theorem integral_average_period {p : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (hbal : CyclicallyBalanced w) (a : ℕ) (ha : a ≤ p) (z : ℤ)
    (hz : (a : ℤ) * ∑ t : ZMod p, w t = (p : ℤ) * z) :
    ∀ s : ZMod p, w (s + a) = w s := by
  intro s
  have hs := cyclic_weight_shift w s a
  rw [cyclic_weight_integral w hbal (s + 1) a ha z hz,
    cyclic_weight_integral w hbal s a ha z hz] at hs
  omega

/-- A primitive balanced cyclic word has coprime length and weight. -/
theorem balanced_primitive_coprime {p q : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (hbal : CyclicallyBalanced w) (hprim : NoShortPeriod w)
    (hq : ∑ t : ZMod p, w t = (q : ℤ)) : Nat.Coprime p q := by
  rw [Nat.coprime_iff_gcd_eq_one]
  by_contra hg
  have hp : 0 < p := Nat.pos_of_ne_zero (NeZero.ne p)
  have hgpos : 0 < p.gcd q := Nat.gcd_pos_of_pos_left q hp
  have hg2 : 1 < p.gcd q := by omega
  have hgp : p.gcd q ≤ p := Nat.le_of_dvd hp (Nat.gcd_dvd_left p q)
  have ha0 : 0 < p / p.gcd q := Nat.div_pos hgp hgpos
  have hap : p / p.gcd q < p := Nat.div_lt_self hp hg2
  apply hprim (p / p.gcd q) ha0 hap
  apply integral_average_period w hbal _ (by omega) (q / p.gcd q)
  rw [hq]
  exact_mod_cast (show p / p.gcd q * q = p * (q / p.gcd q) from by
    calc
      p / p.gcd q * q = p / p.gcd q * ((q / p.gcd q) * p.gcd q) := by
        rw [Nat.div_mul_cancel (Nat.gcd_dvd_right p q)]
      _ = (p / p.gcd q * p.gcd q) * (q / p.gcd q) := by ring
      _ = p * (q / p.gcd q) := by rw [Nat.div_mul_cancel (Nat.gcd_dvd_left p q)])

/-- At height extrema, proper nonempty prefixes differ in weight by
exactly one when the length and total weight are coprime. -/
theorem extrema_prefix_difference {p q : ℕ} [NeZero p] (w : ZMod p → ℤ)
    (hbal : CyclicallyBalanced w) (hq : ∑ z : ZMod p, w z = (q : ℤ))
    (hcop : Nat.Coprime p q) (s t a : ℕ)
    (hs : (a : ℤ) * ∑ z : ZMod p, w z ≤ (p : ℤ) * cyclicWeight w s a)
    (ht : (p : ℤ) * cyclicWeight w t a ≤ (a : ℤ) * ∑ z : ZMod p, w z)
    (ha0 : 0 < a) (hap : a < p) :
    cyclicWeight w s a = cyclicWeight w t a + 1 := by
  have hp : 0 < (p : ℤ) := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne p)
  have hle := hbal (s : ZMod p) (t : ZMod p) a (by omega)
  have hge : cyclicWeight w t a ≤ cyclicWeight w s a := by nlinarith
  have hne : cyclicWeight w s a ≠ cyclicWeight w t a := by
    intro he
    have hae : (a : ℤ) * (q : ℤ) = (p : ℤ) * cyclicWeight w s a := by
      rw [hq] at hs ht
      rw [he] at hs ⊢
      omega
    have hdivZ : (p : ℤ) ∣ (a : ℤ) * (q : ℤ) := ⟨cyclicWeight w s a, hae⟩
    have hdivN : p ∣ a * q := by exact_mod_cast hdivZ
    have ha := Nat.le_of_dvd ha0 (hcop.dvd_of_dvd_mul_right hdivN)
    omega
  omega

/-- The combinatorial content of Claude's Lemma B, stated as endpoint
letters and equality of the common middle. The rotations are the minimum
and maximum of the periodic height, and no finite search is involved. -/
theorem balanced_primitive_endpoint_letters {p q : ℕ} [NeZero p]
    (w : ZMod p → ℤ) (hbinary : ∀ s, w s = 0 ∨ w s = 1)
    (hbal : CyclicallyBalanced w) (hprim : NoShortPeriod w)
    (hq : ∑ z : ZMod p, w z = (q : ℤ)) (hq0 : 0 < q) (hqp : q < p) :
    ∃ s < p, ∃ t < p,
      w (s : ZMod p) = 1 ∧ w (t : ZMod p) = 0 ∧
      w ((s : ZMod p) + (p - 1 : ℕ)) = 0 ∧
      w ((t : ZMod p) + (p - 1 : ℕ)) = 1 ∧
      ∀ i : ℕ, 0 < i → i + 1 < p →
        w ((s : ZMod p) + i) = w ((t : ZMod p) + i) := by
  have hp2 : 2 ≤ p := by omega
  have hcop := balanced_primitive_coprime w hbal hprim hq
  obtain ⟨s, hs, t, ht, hext⟩ := height_extrema w
  have hd (a : ℕ) (ha : 0 < a) (hap : a < p) :
      cyclicWeight w s a = cyclicWeight w t a + 1 :=
    extrema_prefix_difference w hbal hq hcop s t a (hext a).1 (hext a).2 ha hap
  have hfirst := hd 1 (by omega) (by omega)
  simp [cyclicWeight] at hfirst
  have hfs : w (s : ZMod p) = 1 := by
    obtain h | h := hbinary (s : ZMod p)
    · obtain h' | h' := hbinary (t : ZMod p) <;> omega
    · exact h
  have hft : w (t : ZMod p) = 0 := by omega
  have hlast := hd (p - 1) (by omega) (by omega)
  have hsp := cyclic_weight_succ w (s : ZMod p) (p - 1)
  have htp := cyclic_weight_succ w (t : ZMod p) (p - 1)
  rw [Nat.sub_add_cancel (by omega : 1 ≤ p), cyclic_weight_period] at hsp htp
  have hls : w ((s : ZMod p) + (p - 1 : ℕ)) = 0 := by
    obtain h | h := hbinary ((s : ZMod p) + (p - 1 : ℕ))
    · exact h
    · obtain h' | h' := hbinary ((t : ZMod p) + (p - 1 : ℕ)) <;> omega
  have hlt : w ((t : ZMod p) + (p - 1 : ℕ)) = 1 := by omega
  refine ⟨s, hs, t, ht, hfs, hft, hls, hlt, ?_⟩
  intro i hi hip
  have hdi := hd i hi (by omega)
  have hdi' := hd (i + 1) (by omega) hip
  rw [cyclic_weight_succ, cyclic_weight_succ] at hdi'
  omega

/-- If the two endpoint-swapped words both give integer positive fixed
points, their shared middle word is empty. -/
theorem endpoint_integrality_forces_empty (u : List Bool)
    (hpos : 0 < (2 : ℤ) ^ (u.length + 2) - (3 : ℤ) ^ (u.count true + 1))
    (hu : ((2 : ℤ) ^ (u.length + 2) - (3 : ℤ) ^ (u.count true + 1)) ∣
      (bsNumerator (true :: (u ++ [false])) : ℤ))
    (hv : ((2 : ℤ) ^ (u.length + 2) - (3 : ℤ) ^ (u.count true + 1)) ∣
      (bsNumerator (false :: (u ++ [true])) : ℤ)) :
    u = [] := by
  have hn1 : bsNumerator (true :: (u ++ [false])) =
      2 * bsNumerator u + 3 ^ u.count true := by
    simpa only [List.cons_append, onePositions_length] using
      bsNumerator_cons_true_append_false u
  have hn2 : bsNumerator (false :: (u ++ [true])) =
      6 * bsNumerator u + 2 ^ (u.length + 1) := by
    simpa only [List.cons_append] using bsNumerator_cons_false_append_true u
  rw [hn1] at hu
  rw [hn2] at hv
  have hu' : ((2 : ℤ) ^ (u.length + 2) - (3 : ℤ) ^ (u.count true + 1)) ∣
      ((3 : ℤ) ^ u.count true + 2 * (bsNumerator u : ℤ)) := by
    simpa [add_comm] using hu
  have hv' : ((2 : ℤ) ^ (u.length + 2) - (3 : ℤ) ^ (u.count true + 1)) ∣
      (6 * (bsNumerator u : ℤ) + (2 : ℤ) ^ (u.length + 1)) := by
    simpa using hv
  have hd := HypothesisM.canonical_denominator_one (u.length + 2)
    (u.count true + 1) (bsNumerator u) (by omega) (by omega) hpos
    (by simpa using hu') (by simpa using hv')
  have hlen : u.length = 0 := by
    by_contra h
    exact HypothesisM.mod_eight_exclusion (u.length + 2)
      (u.count true + 1) (by omega) hd
  simpa using hlen

/-- Two specified endpoint-swapped rotations of an integer cycle
certificate force period two and exactly one odd step. This is uniform in
the original word and its length; it is not a finite enumeration. -/
theorem endpoint_rotations_force_period_two (w u : List Bool) (a b : ℕ)
    (ha : w.rotate a = true :: (u ++ [false]))
    (hb : w.rotate b = false :: (u ++ [true]))
    (hpos : 0 < bsDenominator w.length (w.count true))
    (hint : bsIsInteger w.length (w.count true) w) :
    u = [] ∧ w.length = 2 ∧ w.count true = 1 := by
  have hlen : w.length = u.length + 2 := by
    have hh := congrArg List.length ha
    simpa using hh
  have hcount : w.count true = u.count true + 1 := by
    have hh := (w.rotate_perm a).count_eq true
    rw [ha] at hh
    simpa using hh.symm
  have hu := rotation_preserves_bsIsInteger w.length (w.count true) a w rfl rfl hint
  have hv := rotation_preserves_bsIsInteger w.length (w.count true) b w rfl rfl hint
  rw [ha] at hu
  rw [hb] at hv
  unfold bsIsInteger at hu hv
  unfold bsDenominator at hu hv hpos
  rw [hlen, hcount] at hu hv hpos
  have he := endpoint_integrality_forces_empty u hpos hu hv
  exact ⟨he, by simpa [he] using hlen, by simpa [he] using hcount⟩

#print axioms endpoint_integrality_forces_empty
#print axioms endpoint_rotations_force_period_two
#print axioms cyclic_weight_sum
#print axioms cyclic_weight_bounds
#print axioms cyclic_weight_integral
#print axioms integral_average_period
#print axioms balanced_primitive_coprime
#print axioms height_extrema
#print axioms extrema_prefix_difference
#print axioms balanced_primitive_endpoint_letters

end HypothesisMBalanced
