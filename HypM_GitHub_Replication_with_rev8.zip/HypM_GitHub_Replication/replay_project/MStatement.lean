import Mathlib.Tactic

/-!
The exact seed-form target for Hypothesis M.

This module defines the target proposition and checks three small examples.
It does not provide a proof of the universally quantified target.
All arithmetic in the target is natural-number arithmetic.
-/

namespace HypothesisMTarget

/-- One step of the shortcut Collatz map, extended to zero by the even branch. -/
def shortcut (n : ℕ) : ℕ :=
  if n % 2 = 0 then n / 2 else (3 * n + 1) / 2

/-- The state after exactly `j` shortcut steps, with the initial seed at time zero. -/
def orbit (n : ℕ) : ℕ → ℕ
  | 0 => n
  | j + 1 => shortcut (orbit n j)

/-- Number of odd input states among times `0,...,j-1`. -/
def oddCount (n : ℕ) : ℕ → ℕ
  | 0 => 0
  | j + 1 => oddCount n j + if orbit n j % 2 = 1 then 1 else 0

/-- Some positive time at most `B` has multiplicative coefficient outside `[1,3]`.
The positive denominator `2^j` is cleared exactly, so no real logarithm or
floating-point coefficient is used. -/
def CoefficientExitWithin (n B : ℕ) : Prop :=
  ∃ j : ℕ, 1 ≤ j ∧ j ≤ B ∧
    ((3 : ℕ) ^ oddCount n j < (2 : ℕ) ^ j ∨
      3 * (2 : ℕ) ^ j < (3 : ℕ) ^ oddCount n j)

/-- The frozen seed formulation of M. This is a definition of the target,
not an assertion that the target has been proved in this module. -/
def MStatement : Prop :=
  ∀ n : ℕ, 2 ≤ n → CoefficientExitWithin n (Nat.log2 (n * n) + 1)

/-- The excluded seed `1` fails the displayed bound. -/
theorem seed_one_fails_bound :
    ¬ CoefficientExitWithin 1 (Nat.log2 (1 * 1) + 1) := by
  intro h
  obtain ⟨j, hj, hbound, hexit⟩ := h
  have hvalue : Nat.log2 (1 * 1) + 1 = 1 := by decide
  rw [hvalue] at hbound
  have heq : j = 1 := by omega
  subst j
  exact (by decide :
    ¬ ((3 : ℕ) ^ oddCount 1 1 < (2 : ℕ) ^ 1 ∨
      3 * (2 : ℕ) ^ 1 < (3 : ℕ) ^ oddCount 1 1)) hexit

/-- Seed `2` exits below the interval at time `1`, within its bound `3`. -/
theorem seed_two_meets_bound :
    CoefficientExitWithin 2 (Nat.log2 (2 * 2) + 1) := by
  exact ⟨1, by decide, by decide, Or.inl (by decide)⟩

/-- Seed `3` exits below the interval at time `4`, exactly its stated bound. -/
theorem seed_three_meets_bound :
    CoefficientExitWithin 3 (Nat.log2 (3 * 3) + 1) := by
  exact ⟨4, by decide, by decide, Or.inl (by decide)⟩

#check MStatement
#print MStatement
#print axioms seed_one_fails_bound
#print axioms seed_two_meets_bound
#print axioms seed_three_meets_bound

end HypothesisMTarget
