import AffineOrbit
import BaseCases

namespace HypothesisMAssembly
open HypothesisMTarget HypothesisMCritical HypothesisMOrbit HypothesisMAffine

/-- The complete arithmetic and finite-word part of the M contradiction.
A confined prefix with a seed below the square-root threshold forces an
actual positive return, with two full copies still inside that prefix. -/
theorem confined_prefix_returns (n L k : ℕ)
    (hn : 2 ≤ n) (hk : 6 ≤ k) (hwindow : 2 * k + 1 ≤ L)
    (hseed : n < 2 ^ (k + 1))
    (hnoexit : ¬ CoefficientExitWithin n L) :
    ∃ i p : ℕ, 1 ≤ i ∧ i ≤ k ∧ 0 < p ∧ p ≤ k ∧
      i + 2 * p ≤ L ∧ n < orbit n i ∧
      orbit (orbit n i) p = orbit n i := by
  obtain ⟨i, j, hij, hj, hword⟩ := actual_repeated_blocks n L k hnoexit hwindow
  have hconf (s : ℕ) (hs : s ≤ L) :
      1 ≤ coefficient n s ∧ coefficient n s < 3 :=
    coefficient_bounds_of_no_exit n L hnoexit s hs
  have h6 : orbitWord n i 6 = orbitWord n j 6 := by
    have hh := congrArg (fun w : List Bool => w.take 6) hword
    simpa only [orbitWord_take n i k 6 hk, orbitWord_take n j k 6 hk] using hh
  have hdia : |coefficient n i - coefficient n j| ≤ 4 / 9 := by
    apply same_actual_six_diameter n i j
    · intro s hsi hsu
      exact hconf s (by omega)
    · intro s hsj hsu
      exact hconf s (by omega)
    · exact h6
  have heq : orbit n i = orbit n j :=
    collision_from_diameter n i j k hk hij.le hj hseed
      (fun s hs => hconf s (by omega)) hdia
      (same_orbitWord_parity n i j k hword)
  have hi : 1 ≤ i := by
    by_contra hh
    have hz : i = 0 := by omega
    have hgt := orbit_gt_seed n j (by omega) (by omega)
      (fun s hs => (hconf s (by omega)).1) (hconf j (by omega)).2.le
    simp [hz, orbit] at heq
    omega
  have hgrow : n < orbit n i :=
    orbit_gt_seed n i (by omega) (by omega)
      (fun s hs => (hconf s (by omega)).1) (hconf i (by omega)).2.le
  refine ⟨i, j - i, hi, by omega, by omega, by omega, ?_, hgrow, ?_⟩
  · exact HypothesisM.two_copies_fit i j k L hi hij hj hwindow
  · exact return_of_collision n i j hij.le heq

theorem period_two_states (n : ℕ) (hn : 0 < n) (hret : orbit n 2 = n) :
    n = 1 ∨ n = 2 := by
  have htwo : shortcut (shortcut n) = n := by simpa [orbit] using hret
  by_cases h0 : n % 2 = 0
  · have hs0 := shortcut_even n h0
    by_cases h1 : shortcut n % 2 = 0
    · have hs1 := shortcut_even (shortcut n) h1
      rw [htwo] at hs1
      omega
    · have hs1 := shortcut_odd (shortcut n) (by omega)
      rw [htwo] at hs1
      omega
  · have hs0 := shortcut_odd n (by omega)
    by_cases h1 : shortcut n % 2 = 0
    · have hs1 := shortcut_even (shortcut n) h1
      rw [htwo] at hs1
      omega
    · have hs1 := shortcut_odd (shortcut n) (by omega)
      rw [htwo] at hs1
      omega

#print axioms confined_prefix_returns
#print axioms period_two_states
end HypothesisMAssembly
