/-
  Independent statement audit for Hypothesis M (written by Claude, 22 Oct 2026).
  It is compiled AFTER the replay has built GPT's modules. It adds no lemmas to
  the proof; it only (1) checks the final theorem against the frozen target and
  against a statement Claude wrote out by hand from the mathematical definition,
  (2) spot-checks that the Lean definitions compute the real Collatz quantities,
  and (3) prints the definitions and axiom closure into the build log.
-/
import HypothesisMFinal

open HypothesisMTarget

/-! ## 1. Type checks -/

-- The proof has exactly the frozen target type.
example : MStatement := HypothesisMAssembly.hypothesis_M

-- Hand-written expansion of Theorem M:
--   for every n ≥ 2 there is j with 1 ≤ j ≤ ⌊log₂(n²)⌋ + 1 such that
--   C_j = 3^{a_j}/2^j satisfies C_j < 1 or C_j > 3 (denominators cleared).
example : ∀ n : ℕ, 2 ≤ n → ∃ j : ℕ, 1 ≤ j ∧ j ≤ Nat.log2 (n * n) + 1 ∧
    ((3 : ℕ) ^ oddCount n j < (2 : ℕ) ^ j ∨
      3 * (2 : ℕ) ^ j < (3 : ℕ) ^ oddCount n j) :=
  HypothesisMAssembly.hypothesis_M

/-! ## 2. Semantic spot checks: the definitions compute the real quantities -/

-- Shortcut map T(n) = n/2 (even), (3n+1)/2 (odd).
example : shortcut 6 = 3 := by decide
example : shortcut 7 = 11 := by decide
example : shortcut 27 = 41 := by decide
-- Orbit 7 → 11 → 17 → 26 → 13.
example : orbit 7 3 = 26 := by decide
example : orbit 7 4 = 13 := by decide
-- Odd inputs among times 0..j-1: orbit of 7 starts odd, odd, odd, even.
example : oddCount 7 3 = 3 := by decide
example : oddCount 7 4 = 3 := by decide
-- Seed 3: 3 → 5 → 8 → 4, odd at times 0,1 only, so a_4 = 2 and C_4 = 9/16 < 1.
example : oddCount 3 4 = 2 := by decide
-- The horizon: ⌊log₂ 49⌋ + 1 = 6 and ⌊log₂ 9⌋ + 1 = 4.
example : Nat.log2 (7 * 7) + 1 = 6 := by decide
example : Nat.log2 (3 * 3) + 1 = 4 := by decide
-- Seed 1 is correctly excluded: its bound is 1 and C_1 = 3/2 is inside [1,3].
example : ¬ CoefficientExitWithin 1 (Nat.log2 (1 * 1) + 1) := seed_one_fails_bound

/-! ## 3. Definitions and axiom closure, printed for the human reviewer -/

#print shortcut
#print orbit
#print oddCount
#print CoefficientExitWithin
#print MStatement
#print axioms HypothesisMAssembly.hypothesis_M
#print axioms HypothesisMAssembly.coefficient_exit_bound
#print axioms HypothesisMAssembly.balanced_return_trivial
