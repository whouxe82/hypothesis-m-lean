"""Fail the build unless every audited theorem depends only on Lean's standard axioms."""
import re, sys
STANDARD = {"propext", "Classical.choice", "Quot.sound"}
REQUIRED = {"HypothesisMAssembly.hypothesis_M", "HypothesisMAssembly.coefficient_exit_bound",
            "HypothesisMAssembly.balanced_return_trivial"}
text = open(sys.argv[1], encoding="utf-8").read()
found = {}
for name, axioms in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", text):
    found[name] = {a.strip() for a in axioms.split(",") if a.strip()}
for name in re.findall(r"'([^']+)' does not depend on any axioms", text):
    found[name] = set()
ok = True
for name in sorted(REQUIRED):
    if name not in found:
        print(f"MISSING axiom report for {name}"); ok = False
    elif not found[name] <= STANDARD:
        print(f"NONSTANDARD axioms in {name}: {sorted(found[name] - STANDARD)}"); ok = False
    else:
        print(f"OK  {name}: {sorted(found[name])}")
if "sorryAx" in text or "ofReduceBool" in text:
    print("Forbidden axiom (sorryAx / ofReduceBool) appears in log"); ok = False
print("AXIOM GATE:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
