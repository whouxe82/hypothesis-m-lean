"""Revision 8 axiom gate: fail unless each named theorem's axiom report exists and uses only
propext, Classical.choice and Quot.sound, and no sorryAx / ofReduceBool appears in the log.
Usage: python3 rev8_axiom_gate.py LOGFILE THEOREM [THEOREM ...]"""
import re, sys
STANDARD = {"propext", "Classical.choice", "Quot.sound"}
text = open(sys.argv[1], encoding="utf-8").read()
required = sys.argv[2:]
found = {}
for name, axioms in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", text):
    found[name] = {a.strip() for a in axioms.split(",") if a.strip()}
for name in re.findall(r"'([^']+)' does not depend on any axioms", text):
    found[name] = set()
ok = True
for name in required:
    if name not in found:
        print(f"MISSING axiom report for {name}"); ok = False
    elif not found[name] <= STANDARD:
        print(f"NONSTANDARD axioms in {name}: {sorted(found[name] - STANDARD)}"); ok = False
    else:
        print(f"OK  {name}: {sorted(found[name])}")
if "sorryAx" in text or "ofReduceBool" in text or "error:" in text:
    print("Forbidden axiom or compile error in log"); ok = False
print("REV8 AXIOM GATE:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
