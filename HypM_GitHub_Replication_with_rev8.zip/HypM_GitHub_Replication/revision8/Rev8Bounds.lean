/-!
# Revision 8: Corollary N2 bounds, `k + 1 ≤ M(k) ≤ 2k`

This module uses only core Lean (no Mathlib). Its definitions repeat, verbatim,
those of `MStatement.lean` (namespace `HypothesisMTarget`); the bridge module
`Rev8Bridge.lean` checks by `rfl` that they agree and derives the upper bound
from the formal Theorem 1 (`HypothesisMAssembly.hypothesis_M`).

* `n2_lower` (unconditional): for every `k ≥ 2` some seed `2 ≤ n < 2^k` does not
  leave the critical corridor within `k` steps, i.e. `M(k) ≥ k + 1`.
* `n2_upper` (from the seed form of Theorem 1): every seed `2 ≤ n < 2^k` leaves
  the corridor within `2k` steps, i.e. `M(k) ≤ 2k`.
-/

namespace HypMRev8

def shortcut (n : Nat) : Nat :=
  if n % 2 = 0 then n / 2 else (3 * n + 1) / 2

def orbit (n : Nat) : Nat → Nat
  | 0 => n
  | j + 1 => shortcut (orbit n j)

def oddCount (n : Nat) : Nat → Nat
  | 0 => 0
  | j + 1 => oddCount n j + if orbit n j % 2 = 1 then 1 else 0

def CoefficientExitWithin (n B : Nat) : Prop :=
  ∃ j : Nat, 1 ≤ j ∧ j ≤ B ∧
    ((3 : Nat) ^ oddCount n j < (2 : Nat) ^ j ∨
      3 * (2 : Nat) ^ j < (3 : Nat) ^ oddCount n j)

def MStatement : Prop :=
  ∀ n : Nat, 2 ≤ n → CoefficientExitWithin n (Nat.log2 (n * n) + 1)

/-! ## Upper bound from Theorem 1 -/

theorem exit_mono {n B B' : Nat} (h : CoefficientExitWithin n B) (hB : B ≤ B') :
    CoefficientExitWithin n B' := by
  obtain ⟨j, h1, h2, h3⟩ := h
  exact ⟨j, h1, Nat.le_trans h2 hB, h3⟩

theorem log2_square_lt {n k : Nat} (hn : 1 ≤ n) (hk : n < 2 ^ k) :
    Nat.log2 (n * n) < 2 * k := by
  have hsq : n * n < 2 ^ (2 * k) := by
    have : n * n < 2 ^ k * 2 ^ k := Nat.mul_lt_mul_of_lt_of_lt hk hk
    rwa [← Nat.pow_add, show k + k = 2 * k by omega] at this
  have hne : n * n ≠ 0 := Nat.mul_ne_zero (by omega) (by omega)
  exact (Nat.log2_lt hne).2 hsq

/-- Corollary N2, upper bound: `M(k) ≤ 2k`, from the seed form of Theorem 1. -/
theorem n2_upper (hM : MStatement) (k n : Nat) (hn : 2 ≤ n) (hk : n < 2 ^ k) :
    CoefficientExitWithin n (2 * k) :=
  exit_mono (hM n hn) (by have := log2_square_lt (by omega) hk; omega)

/-! ## Lifting: every parity pattern of length `L` is followed by a seed below `2^L` -/

theorem orbit_succ (n t : Nat) : orbit n (t + 1) = shortcut (orbit n t) := rfl

theorem oddCount_succ (n t : Nat) :
    oddCount n (t + 1) = oddCount n t + if orbit n t % 2 = 1 then 1 else 0 := rfl

theorem pow3_odd (a : Nat) : 3 ^ a % 2 = 1 := by
  induction a with
  | zero => rfl
  | succ a ih => rw [Nat.pow_succ, Nat.mul_mod, ih]

/-- Adding `2^(t+d)` to the seed shifts the state at time `t` by `3^a * 2^d`
and leaves the odd count unchanged. -/
theorem shift_lemma (n : Nat) : ∀ t d : Nat,
    orbit (n + 2 ^ (t + d)) t = orbit n t + 3 ^ oddCount n t * 2 ^ d ∧
    oddCount (n + 2 ^ (t + d)) t = oddCount n t := by
  intro t
  induction t with
  | zero => intro d; simp [orbit, oddCount]
  | succ t ih =>
    intro d
    have h := ih (d + 1)
    rw [show t + (d + 1) = t + 1 + d by omega] at h
    obtain ⟨ho, hc⟩ := h
    have hpow : 3 ^ oddCount n t * 2 ^ (d + 1) = 2 * (3 ^ oddCount n t * 2 ^ d) := by
      rw [Nat.pow_succ]; rw [Nat.mul_comm (2 ^ d) 2, ← Nat.mul_assoc, Nat.mul_comm (3 ^ oddCount n t) 2,
        Nat.mul_assoc]
    rw [hpow] at ho
    generalize hy : 3 ^ oddCount n t * 2 ^ d = y at ho
    generalize hx : orbit n t = x at ho
    have hcnt : oddCount n (t + 1) = oddCount n t + (if x % 2 = 1 then 1 else 0) := by
      rw [oddCount_succ, hx]
    have hpar : (x + 2 * y) % 2 = x % 2 := by omega
    refine ⟨?_, ?_⟩
    · rw [orbit_succ, orbit_succ, ho, hx]
      unfold shortcut
      by_cases hx2 : x % 2 = 0
      · have hc' : oddCount n (t + 1) = oddCount n t := by
          rw [hcnt]; simp [show ¬ x % 2 = 1 by omega]
        rw [hc', hy, ite_eq_left_of_eq_true _ _ (eq_true (show (x + 2 * y) % 2 = 0 by omega)),
          ite_eq_left_of_eq_true _ _ (eq_true hx2)]
        omega
      · have hc' : oddCount n (t + 1) = oddCount n t + 1 := by
          rw [hcnt]; simp [show x % 2 = 1 by omega]
        rw [hc', Nat.pow_succ, Nat.mul_comm (3 ^ oddCount n t) 3, Nat.mul_assoc, hy,
          ite_eq_right_of_eq_false _ _ (eq_false (show ¬ (x + 2 * y) % 2 = 0 by omega)),
          ite_eq_right_of_eq_false _ _ (eq_false hx2)]
        omega
    · rw [oddCount_succ, oddCount_succ, hc, ho, hx, hpar]

/-- Every 0/1 pattern of length `L` is the parity pattern of some seed `n < 2^L`. -/
theorem lift (b : Nat → Nat) (hb : ∀ t, b t < 2) : ∀ L : Nat,
    ∃ n, n < 2 ^ L ∧ ∀ t, t < L → orbit n t % 2 = b t := by
  intro L
  induction L with
  | zero => exact ⟨0, by decide, fun t ht => absurd ht (Nat.not_lt_zero t)⟩
  | succ L ih =>
    obtain ⟨n, hnL, hpar⟩ := ih
    have hL2 : 2 ^ (L + 1) = 2 * 2 ^ L := by rw [Nat.pow_succ, Nat.mul_comm]
    by_cases hL : orbit n L % 2 = b L
    · refine ⟨n, by omega, fun t ht => ?_⟩
      by_cases htL : t < L
      · exact hpar t htL
      · rw [show t = L by omega]; exact hL
    · refine ⟨n + 2 ^ L, by omega, fun t ht => ?_⟩
      by_cases htL : t < L
      · obtain ⟨ho, -⟩ := shift_lemma n t (L - t)
        rw [show t + (L - t) = L by omega] at ho
        rw [ho, ← hpar t htL]
        have hd : 2 ^ (L - t) = 2 * 2 ^ (L - t - 1) := by
          rw [show L - t = (L - t - 1) + 1 by omega, Nat.pow_succ, Nat.mul_comm]; simp
        rw [hd]
        generalize 3 ^ oddCount n t = a
        generalize 2 ^ (L - t - 1) = c
        rw [show a * (2 * c) = 2 * (a * c) by rw [Nat.mul_left_comm]]
        omega
      · rw [show t = L by omega]
        obtain ⟨ho, -⟩ := shift_lemma n L 0
        simp only [Nat.add_zero, Nat.pow_zero, Nat.mul_one] at ho
        rw [ho]
        have h3 := pow3_odd (oddCount n L)
        have hbL := hb L
        omega

/-! ## The critical count stays in the corridor -/

/-- The forced odd count: odd at time `t` exactly when `3^c < 2^(t+1)`. -/
def critBit (c t : Nat) : Nat := if 3 ^ c < 2 ^ (t + 1) then 1 else 0

def crit : Nat → Nat
  | 0 => 0
  | t + 1 => crit t + critBit (crit t) t

theorem crit_corridor : ∀ t, 2 ^ t ≤ 3 ^ crit t ∧ 3 ^ crit t ≤ 3 * 2 ^ t := by
  intro t
  induction t with
  | zero => simp [crit]
  | succ t ih =>
    obtain ⟨h1, h2⟩ := ih
    show 2 ^ (t + 1) ≤ 3 ^ (crit t + critBit (crit t) t) ∧
      3 ^ (crit t + critBit (crit t) t) ≤ 3 * 2 ^ (t + 1)
    unfold critBit
    rw [Nat.pow_succ 2 t]
    by_cases hc : 3 ^ crit t < 2 ^ t * 2
    · simp only [hc, ↓reduceIte]; rw [Nat.pow_succ]; omega
    · simp only [hc, ↓reduceIte, Nat.add_zero]; omega

/-- A seed following the critical pattern for `L` steps has the critical odd counts. -/
theorem follow_counts (n L : Nat)
    (hpar : ∀ t, t < L → orbit n t % 2 = critBit (crit t) t) :
    ∀ t, t ≤ L → oddCount n t = crit t := by
  intro t
  induction t with
  | zero => intro _; rfl
  | succ t ih =>
    intro ht
    have hct := ih (by omega)
    have hp := hpar t (by omega)
    rw [oddCount_succ, hct]
    show crit t + (if orbit n t % 2 = 1 then 1 else 0) = crit t + critBit (crit t) t
    unfold critBit at hp ⊢
    by_cases h : 3 ^ crit t < 2 ^ (t + 1)
    · simp only [h, ↓reduceIte] at hp ⊢; simp [hp]
    · simp only [h, ↓reduceIte] at hp ⊢; simp [hp]

/-- Corollary N2, lower bound (unconditional): `M(k) ≥ k + 1`. -/
theorem n2_lower (k : Nat) (hk : 2 ≤ k) :
    ∃ n, 2 ≤ n ∧ n < 2 ^ k ∧ ¬ CoefficientExitWithin n k := by
  obtain ⟨n, hn, hpar⟩ := lift (fun t => critBit (crit t) t)
    (fun t => by unfold critBit; split <;> omega) k
  have hcounts := follow_counts n k hpar
  refine ⟨n, ?_, hn, ?_⟩
  · -- `n` is odd (time 0) and is not `1` (time 1)
    have h0 := hpar 0 (by omega)
    have h1 := hpar 1 (by omega)
    have hb0 : critBit (crit 0) 0 = 1 := by decide
    have hb1 : critBit (crit 1) 1 = 1 := by decide
    rw [hb0, show orbit n 0 = n from rfl] at h0; rw [hb1] at h1
    by_cases hn1 : n = 1
    · subst hn1; exact absurd h1 (by decide)
    · omega
  · rintro ⟨j, hj1, hjk, hexit⟩
    rw [hcounts j hjk] at hexit
    have := crit_corridor j
    omega

end HypMRev8

#print axioms HypMRev8.n2_lower
#print axioms HypMRev8.n2_upper
