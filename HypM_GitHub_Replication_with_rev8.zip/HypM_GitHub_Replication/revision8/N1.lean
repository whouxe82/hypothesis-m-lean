/-
  Proposition N1 (integer formulation), core Lean 4 only.
  K = P/Q with 3 < K ≤ 9/2, i.e. 3*Q < P and 2*P ≤ 9*Q, Q > 0.
-/

namespace N1

/-! ## Definitions (the statement) -/

/-- All Bool lists of length `L` (proved below: membership ↔ length = L, and no duplicates). -/
def allWords : Nat → List (List Bool)
  | 0 => [[]]
  | k+1 => (allWords k).map (false :: ·) ++ (allWords k).map (true :: ·)

/-- The admissibility inequalities at time `j` with odd count `a`. -/
def ok (P Q j a : Nat) : Prop := 2^j ≤ 3^a ∧ Q * 3^a ≤ P * 2^j

instance (P Q j a : Nat) : Decidable (ok P Q j a) := by unfold ok; infer_instance

/-- K-admissibility, literally: for every 1 ≤ j ≤ L, with a_j = #true among the first j letters,
    2^j ≤ 3^(a_j) and Q*3^(a_j) ≤ P*2^j. -/
def Admissible (P Q : Nat) (w : List Bool) : Prop :=
  ∀ j, 1 ≤ j → j ≤ w.length →
    2^j ≤ 3^((w.take j).count true) ∧ Q * 3^((w.take j).count true) ≤ P * 2^j

/-- c_j: computed recursively; proved below to be the least `a` with 2^j ≤ 3^a. -/
def c : Nat → Nat
  | 0 => 0
  | j+1 => if 2^(j+1) ≤ 3^(c j) then c j else c j + 1

/-- j is a choice time. -/
def choice (P Q j : Nat) : Prop := Q * 3^(c j + 1) ≤ P * 2^j

instance (P Q j : Nat) : Decidable (choice P Q j) := by unfold choice; infer_instance

/-- B(L) = #{ j : 2 ≤ j ≤ L, j a choice time }. -/
def B (P Q : Nat) : Nat → Nat
  | 0 => 0
  | L+1 => B P Q L + (if 2 ≤ L+1 ∧ choice P Q (L+1) then 1 else 0)

/-! ## Decidability of `Admissible` via a cons-recursive checker -/

/-- Checker started at time `n` with current count `a`. -/
def admB (P Q : Nat) : Nat → Nat → List Bool → Bool
  | _, _, [] => true
  | n, a, b :: w => decide (ok P Q (n+1) (a + b.toNat)) && admB P Q (n+1) (a + b.toNat) w

theorem count_cons_true (b : Bool) (l : List Bool) :
    (b :: l).count true = b.toNat + l.count true := by
  cases b <;> simp [List.count_cons] <;> omega

theorem admB_iff (P Q : Nat) (w : List Bool) : ∀ n a,
    admB P Q n a w = true ↔
      ∀ j, 1 ≤ j → j ≤ w.length → ok P Q (n + j) (a + (w.take j).count true) := by
  induction w with
  | nil =>
    intro n a; simp [admB]; intro j h1 h2; omega
  | cons b w ih =>
    intro n a
    simp only [admB, Bool.and_eq_true, decide_eq_true_eq, ih]
    constructor
    · rintro ⟨h0, hrest⟩ j h1 h2
      cases j with
      | zero => omega
      | succ j =>
        cases j with
        | zero => simpa [count_cons_true] using h0
        | succ j =>
          have := hrest (j+1) (by omega) (by simp at h2; omega)
          simp only [List.take_succ_cons, count_cons_true] at this ⊢
          have e1 : n + 1 + (j + 1) = n + (j + 1 + 1) := by omega
          have e2 : a + b.toNat + List.count true (List.take (j+1) w)
              = a + (b.toNat + List.count true (List.take (j+1) w)) := by omega
          rw [e1, e2] at this; exact this
    · intro h
      refine ⟨?_, ?_⟩
      · have := h 1 (by omega) (by simp)
        simpa [count_cons_true] using this
      · intro j h1 h2
        have := h (j+1) (by omega) (by simp; omega)
        simp only [List.take_succ_cons, count_cons_true] at this
        have e1 : n + 1 + j = n + (j + 1) := by omega
        have e2 : a + b.toNat + List.count true (List.take j w)
            = a + (b.toNat + List.count true (List.take j w)) := by omega
        rw [e1, e2]; exact this

theorem admissible_iff (P Q : Nat) (w : List Bool) : Admissible P Q w ↔ admB P Q 0 0 w = true := by
  rw [admB_iff]; unfold Admissible ok; simp

instance (P Q : Nat) : DecidablePred (Admissible P Q) := fun w =>
  decidable_of_iff _ (admissible_iff P Q w).symm

/-- N(L): the number of K-admissible Bool lists of length L. -/
def N (P Q L : Nat) : Nat := (allWords L).countP (fun w => decide (Admissible P Q w))

/-! ## `allWords L` is exactly the lists of length L, without repetition -/

theorem mem_allWords : ∀ (L : Nat) (w : List Bool), w ∈ allWords L ↔ w.length = L := by
  intro L
  induction L with
  | zero => intro w; cases w <;> simp [allWords]
  | succ k ih =>
    intro w
    cases w with
    | nil => simp [allWords]
    | cons b w => cases b <;> simp [allWords, ih]

theorem nodup_allWords : ∀ L, (allWords L).Nodup := by
  intro L
  induction L with
  | zero => simp [allWords]
  | succ k ih =>
    simp only [allWords]
    rw [List.nodup_append]
    refine ⟨?_, ?_, ?_⟩
    · rw [List.Nodup, List.pairwise_map]; exact ih.imp (fun h e => h (by simpa using e))
    · rw [List.Nodup, List.pairwise_map]; exact ih.imp (fun h e => h (by simpa using e))
    · intro x hx y hy; simp at hx hy
      obtain ⟨u, -, rfl⟩ := hx; obtain ⟨v, -, rfl⟩ := hy; simp

/-! ## Facts about c_j -/

theorem c_spec : ∀ j, 2^j ≤ 3^(c j) ∧ 3^(c j) < 3 * 2^j := by
  intro j
  induction j with
  | zero => simp [c]
  | succ j ih =>
    simp only [c]
    split
    · rename_i h; refine ⟨h, ?_⟩; rw [Nat.pow_succ]; omega
    · rename_i h; rw [Nat.pow_succ, Nat.pow_succ]; omega

theorem c_le_of (j a : Nat) (h : 2^j ≤ 3^a) : c j ≤ a := by
  have := (c_spec j).2
  apply Nat.le_of_not_lt; intro hlt
  have : 3^(a+1) ≤ 3^(c j) := Nat.pow_le_pow_right (by decide) hlt
  rw [Nat.pow_succ] at this; omega

/-- c_j is the least a with 2^j ≤ 3^a. -/
theorem c_least (j : Nat) : 2^j ≤ 3^(c j) ∧ ∀ a, 2^j ≤ 3^a → c j ≤ a :=
  ⟨(c_spec j).1, c_le_of j⟩

theorem c_succ (j : Nat) : c (j+1) = c j ∨ c (j+1) = c j + 1 := by
  simp only [c]; split <;> simp

theorem three_pow_odd (a : Nat) : 3^a % 2 = 1 := by
  induction a with
  | zero => rfl
  | succ a ih => rw [Nat.pow_succ, Nat.mul_mod, ih]

theorem two_pow_even (j : Nat) (h : 1 ≤ j) : 2^j % 2 = 0 := by
  cases j with
  | zero => omega
  | succ j => rw [Nat.pow_succ, Nat.mul_mod]; simp

theorem c_strict (j : Nat) (h : 1 ≤ j) : 2^j < 3^(c j) := by
  have h1 := (c_spec j).1
  have h2 := three_pow_odd (c j)
  have h3 := two_pow_even j h
  apply Nat.lt_of_le_of_ne h1; intro e; rw [e] at h3; omega

section
variable (P Q : Nat) (hQ : 0 < Q) (hlo : 3 * Q < P) (hhi : 2 * P ≤ 9 * Q)
include hQ hlo hhi

/-- Admissible counts at time j are exactly c_j, and c_j + 1 at choice times. -/
theorem ok_iff (j a : Nat) : ok P Q j a ↔ a = c j ∨ (choice P Q j ∧ a = c j + 1) := by
  have hs := c_spec j
  have hY : 0 < 2^j := Nat.pow_pos (by decide)
  have hPY : 0 < P * 2^j := Nat.mul_pos (by omega) hY
  have hB : 2 * (P * 2^j) ≤ 9 * (Q * 2^j) := by
    have := Nat.mul_le_mul_right (2^j) hhi; rwa [Nat.mul_assoc, Nat.mul_assoc] at this
  have hA : 3 * (Q * 2^j) ≤ P * 2^j := by
    have := Nat.mul_le_mul_right (2^j) (Nat.le_of_lt hlo); rwa [Nat.mul_assoc] at this
  constructor
  · rintro ⟨h1, h2⟩
    have hc := c_le_of j a h1
    by_cases e : a = c j
    · exact Or.inl e
    by_cases e' : a = c j + 1
    · subst e'; exact Or.inr ⟨h2, rfl⟩
    exfalso
    have hp : 3^(c j + 2) ≤ 3^a := Nat.pow_le_pow_right (by decide) (by omega)
    have h3 : Q * 3^(c j + 2) ≤ P * 2^j := Nat.le_trans (Nat.mul_le_mul_left Q hp) h2
    rw [Nat.pow_succ, Nat.pow_succ] at h3
    have e3 : Q * (3^(c j) * 3 * 3) = 3 * (3 * (Q * 3^(c j))) := by ac_rfl
    rw [e3] at h3
    have h4 : Q * 2^j ≤ Q * 3^(c j) := Nat.mul_le_mul_left Q hs.1
    omega
  · rintro (e | ⟨hch, e⟩)
    · subst e; refine ⟨hs.1, ?_⟩
      have h1 : Q * 3^(c j) ≤ Q * (3 * 2^j) := Nat.mul_le_mul_left Q (Nat.le_of_lt hs.2)
      have e1 : Q * (3 * 2^j) = 3 * (Q * 2^j) := by ac_rfl
      omega
    · subst e
      exact ⟨Nat.le_trans hs.1 (Nat.pow_le_pow_right (by decide) (Nat.le_succ (c j))), hch⟩

/-- If j+1 (j ≥ 1) is a choice time then c_j = c_{j+1}. -/
theorem iso_prev (j : Nat) (hj : 1 ≤ j) (hch : choice P Q (j+1)) : c (j+1) = c j := by
  rcases c_succ j with e | e
  · exact e
  exfalso
  unfold choice at hch; rw [e] at hch
  have hst := c_strict j hj
  rw [Nat.pow_succ, Nat.pow_succ, Nat.pow_succ] at hch
  have e1 : Q * (3^(c j) * 3 * 3) = 3 * (3 * (Q * 3^(c j))) := by ac_rfl
  have e2 : P * (2^j * 2) = 2 * (P * 2^j) := by ac_rfl
  rw [e1, e2] at hch
  have h1 : Q * 2^j < Q * 3^(c j) := (Nat.mul_lt_mul_left hQ).2 hst
  have hB : 2 * (P * 2^j) ≤ 9 * (Q * 2^j) := by
    have := Nat.mul_le_mul_right (2^j) hhi; rwa [Nat.mul_assoc, Nat.mul_assoc] at this
  omega

/-- If j is a choice time then c_{j+1} = c_j + 1. -/
theorem iso_next_c (j : Nat) (hch : choice P Q j) : c (j+1) = c j + 1 := by
  rcases c_succ j with e | e
  · exfalso
    have h : 2^(j+1) ≤ 3^(c j) := by
      rcases Nat.lt_or_ge (3^(c j)) (2^(j+1)) with h | h
      · have : c (j+1) = c j + 1 := by simp only [c, Nat.not_le.mpr h, ite_false]
        omega
      · exact h
    unfold choice at hch
    rw [Nat.pow_succ] at hch h
    have e1 : Q * (3^(c j) * 3) = 3 * (Q * 3^(c j)) := by ac_rfl
    rw [e1] at hch
    have h1 : Q * (2^j * 2) ≤ Q * 3^(c j) := Nat.mul_le_mul_left Q h
    have e2 : Q * (2^j * 2) = 2 * (Q * 2^j) := by ac_rfl
    rw [e2] at h1
    have hB : 2 * (P * 2^j) ≤ 9 * (Q * 2^j) := by
      have := Nat.mul_le_mul_right (2^j) hhi; rwa [Nat.mul_assoc, Nat.mul_assoc] at this
    have hQY : 0 < Q * 2^j := Nat.mul_pos hQ (Nat.pow_pos (by decide))
    omega
  · exact e

/-- If j ≥ 1 is a choice time then j+1 is not. -/
theorem iso_next (j : Nat) (hj : 1 ≤ j) (hch : choice P Q j) : ¬ choice P Q (j+1) := by
  intro h2
  have e := iso_next_c P Q hQ hlo hhi j hch
  have e' := iso_prev P Q hQ hlo hhi j hj h2
  omega

/-- From an admissible state at time n ≥ 1, c_{n+1} ∈ {a, a+1}. -/
theorem next_c (n a : Nat) (hn : 1 ≤ n) (h : ok P Q n a) : c (n+1) = a ∨ c (n+1) = a + 1 := by
  rcases (ok_iff P Q hQ hlo hhi n a).1 h with e | ⟨hch, e⟩
  · subst e; rcases c_succ n with e | e <;> omega
  · have := iso_next_c P Q hQ hlo hhi n hch; omega

/-! ## Counting -/

/-- E n a k: number of length-k continuations admissible from state (time n, count a). -/
def E (n a k : Nat) : Nat := (allWords k).countP (admB P Q n a)

omit hQ hlo hhi in
theorem countP_and (b : Bool) (q : List Bool → Bool) (l : List (List Bool)) :
    l.countP (fun w => b && q w) = if b = true then l.countP q else 0 := by
  cases b <;> simp

omit hQ hlo hhi in
theorem E_zero (n a : Nat) : E P Q n a 0 = 1 := by
  simp [E, allWords, admB]

omit hQ hlo hhi in
theorem E_succ (n a k : Nat) : E P Q n a (k+1) =
    (if ok P Q (n+1) a then E P Q (n+1) a k else 0) +
    (if ok P Q (n+1) (a+1) then E P Q (n+1) (a+1) k else 0) := by
  unfold E
  simp only [allWords, List.countP_append, List.countP_map]
  have h1 : (admB P Q n a ∘ (false :: ·)) =
      fun w => decide (ok P Q (n+1) a) && admB P Q (n+1) a w := by
    funext w; simp [admB, Bool.toNat]
  have h2 : (admB P Q n a ∘ (true :: ·)) =
      fun w => decide (ok P Q (n+1) (a+1)) && admB P Q (n+1) (a+1) w := by
    funext w; simp [admB, Bool.toNat]
  rw [h1, h2, countP_and, countP_and]
  simp

omit hQ hlo hhi in
theorem B_succ (n : Nat) (hn : 1 ≤ n) :
    B P Q (n+1) = B P Q n + (if choice P Q (n+1) then 1 else 0) := by
  simp only [B]
  by_cases h : choice P Q (n+1)
  · simp [h]; omega
  · simp [h]

theorem forward : ∀ k n a, 1 ≤ n → ok P Q n a →
    E P Q n a k * 2^(B P Q n) = 2^(B P Q (n+k)) := by
  intro k
  induction k with
  | zero => intro n a _ _; simp [E_zero]
  | succ k ih =>
    intro n a hn h
    rw [E_succ]
    have hk : n + (k+1) = (n+1) + k := by omega
    rw [hk]
    by_cases hch : choice P Q (n+1)
    · -- n not a choice time, a = c n = c (n+1); both letters admissible
      have hnc : ¬ choice P Q n := fun h' => iso_next P Q hQ hlo hhi n hn h' hch
      have ha : a = c n := by
        rcases (ok_iff P Q hQ hlo hhi n a).1 h with e | ⟨h', _⟩
        · exact e
        · exact absurd h' hnc
      have hc := iso_prev P Q hQ hlo hhi n hn hch
      have o1 : ok P Q (n+1) a := (ok_iff P Q hQ hlo hhi _ _).2 (Or.inl (by omega))
      have o2 : ok P Q (n+1) (a+1) := (ok_iff P Q hQ hlo hhi _ _).2 (Or.inr ⟨hch, by omega⟩)
      have i1 := ih (n+1) a (by omega) o1
      have i2 := ih (n+1) (a+1) (by omega) o2
      rw [B_succ P Q n hn] at i1 i2
      simp only [hch, ite_true, o1, o2] at i1 i2 ⊢
      rw [Nat.pow_succ] at i1 i2
      rw [← Nat.mul_assoc] at i1 i2
      rw [Nat.add_mul]; omega
    · have hiff : ∀ x, ok P Q (n+1) x ↔ x = c (n+1) := by
        intro x; rw [ok_iff P Q hQ hlo hhi]; simp [hch]
      have hB : B P Q (n+1) = B P Q n := by rw [B_succ P Q n hn]; simp [hch]
      rcases next_c P Q hQ hlo hhi n a hn h with e | e
      · have o1 : ok P Q (n+1) a := (hiff a).2 e.symm
        have o2 : ¬ ok P Q (n+1) (a+1) := fun h' => by have := (hiff _).1 h'; omega
        simp only [o1, o2, ite_true, ite_false, Nat.add_zero]
        have := ih (n+1) a (by omega) o1
        rw [hB] at this; exact this
      · have o1 : ¬ ok P Q (n+1) a := fun h' => by have := (hiff _).1 h'; omega
        have o2 : ok P Q (n+1) (a+1) := (hiff _).2 e.symm
        simp only [o1, o2, ite_true, ite_false, Nat.zero_add]
        have := ih (n+1) (a+1) (by omega) o2
        rw [hB] at this; exact this

/-- **Proposition N1.** For K = P/Q with 3 < K ≤ 9/2, N(L) = 2^B(L) for every L. -/
theorem N1 (L : Nat) : N P Q L = 2^(B P Q L) := by
  have hN : N P Q L = E P Q 0 0 L := by
    unfold N E
    apply congrArg (fun p => List.countP p (allWords L)); funext w
    rw [Bool.eq_iff_iff, decide_eq_true_iff]; exact admissible_iff P Q w
  rw [hN]
  cases L with
  | zero => simp [E_zero, B]
  | succ k =>
    rw [E_succ]
    have o0 : ¬ ok P Q 1 0 := by unfold ok; simp
    have o1 : ok P Q 1 1 := by unfold ok; simp <;> omega
    simp only [o0, o1, ite_true, ite_false, Nat.zero_add]
    have := forward P Q hQ hlo hhi k 1 1 (by omega) o1
    have hB1 : B P Q 1 = 0 := by simp [B]
    rw [hB1, Nat.pow_zero, Nat.mul_one] at this
    rw [this, Nat.add_comm]
end

end N1

#check @N1.N1
#print axioms N1.N1
