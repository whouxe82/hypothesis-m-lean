import HypothesisMFinal
import Rev8Bounds

/-!
# Revision 8 bridge

Connects the core-Lean module `Rev8Bounds` to the frozen statement and the
formal Theorem 1 of the existing development. The definitions in `Rev8Bounds`
repeat those of `MStatement.lean`; the lemmas below prove that they agree, so
the two bounds of Corollary N2 hold for the frozen definitions:

* `n2_lower_frozen` : for every `k ≥ 2`, some seed `2 ≤ n < 2^k` makes no
  coefficient exit within `k` steps (`M(k) ≥ k + 1`), unconditionally;
* `n2_upper_frozen` : every seed `2 ≤ n < 2^k` makes a coefficient exit within
  `2k` steps (`M(k) ≤ 2k`), from `HypothesisMAssembly.hypothesis_M`.
-/

namespace HypMRev8Bridge

theorem shortcut_agree (n : Nat) : HypMRev8.shortcut n = HypothesisMTarget.shortcut n := rfl

theorem orbit_agree (n : Nat) : ∀ j, HypMRev8.orbit n j = HypothesisMTarget.orbit n j := by
  intro j
  induction j with
  | zero => rfl
  | succ j ih =>
    show HypMRev8.shortcut (HypMRev8.orbit n j) = HypothesisMTarget.shortcut (HypothesisMTarget.orbit n j)
    rw [ih]; rfl

theorem oddCount_agree (n : Nat) : ∀ j, HypMRev8.oddCount n j = HypothesisMTarget.oddCount n j := by
  intro j
  induction j with
  | zero => rfl
  | succ j ih =>
    show HypMRev8.oddCount n j + (if HypMRev8.orbit n j % 2 = 1 then 1 else 0) =
      HypothesisMTarget.oddCount n j + (if HypothesisMTarget.orbit n j % 2 = 1 then 1 else 0)
    rw [ih, orbit_agree]

theorem exit_agree (n B : Nat) :
    HypMRev8.CoefficientExitWithin n B ↔ HypothesisMTarget.CoefficientExitWithin n B := by
  unfold HypMRev8.CoefficientExitWithin HypothesisMTarget.CoefficientExitWithin
  simp only [oddCount_agree]

theorem statement_agree : HypMRev8.MStatement ↔ HypothesisMTarget.MStatement := by
  unfold HypMRev8.MStatement HypothesisMTarget.MStatement
  simp only [exit_agree]

/-- Corollary N2, lower bound, for the frozen definitions: `M(k) ≥ k + 1`. -/
theorem n2_lower_frozen (k : Nat) (hk : 2 ≤ k) :
    ∃ n, 2 ≤ n ∧ n < 2 ^ k ∧ ¬ HypothesisMTarget.CoefficientExitWithin n k := by
  obtain ⟨n, h1, h2, h3⟩ := HypMRev8.n2_lower k hk
  exact ⟨n, h1, h2, fun h => h3 ((exit_agree n k).2 h)⟩

/-- Corollary N2, upper bound, for the frozen definitions: `M(k) ≤ 2k`. -/
theorem n2_upper_frozen (k n : Nat) (hn : 2 ≤ n) (hk : n < 2 ^ k) :
    HypothesisMTarget.CoefficientExitWithin n (2 * k) :=
  (exit_agree n (2 * k)).1
    (HypMRev8.n2_upper (statement_agree.2 HypothesisMAssembly.hypothesis_M) k n hn hk)

end HypMRev8Bridge

#print axioms HypMRev8Bridge.n2_lower_frozen
#print axioms HypMRev8Bridge.n2_upper_frozen
