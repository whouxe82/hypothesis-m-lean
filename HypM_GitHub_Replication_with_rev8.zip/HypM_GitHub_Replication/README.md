# Hypothesis M: independent Lean replication on GitHub

This repository rebuilds GPT's Lean proof of Theorem M from scratch on GitHub's
servers. Neither GPT nor Claude controls those machines. The result is public: it
shows a build log, the axiom audit, and a pass or fail mark.

## What it does

The workflow runs five steps in order:

1. **Install Lean.** It installs the exact pinned toolchain, Lean 4.35.0.
2. **Check source hashes.** It verifies that all 33 frozen source files are
   byte-identical to GPT's manifest.
3. **Run the full replay.** It runs GPT's `replay.py`, which:
   - fetches Mathlib at the pinned commit and its official binary cache;
   - builds the Knight2026 library;
   - compiles all 13 proof modules;
   - prints `#print axioms` for each final theorem.
4. **Run Claude's audit.** It compiles `independent_audit/ClaudeIndependentAudit.lean`,
   Claude's own statement audit, which:
   - checks the proof against the frozen target and against a hand-written
     expansion of Theorem M;
   - spot-checks that the definitions compute the real Collatz values;
   - prints every definition used.
5. **Apply the axiom gate.** The build fails unless the final theorems use only
   `propext`, `Classical.choice` and `Quot.sound`.

## Steps for Dr. Houze (web browser only, no software to install)

1. Sign in at github.com (a free account is enough).
2. Click **+**, then **New repository**.
   - Name: `hypothesis-m-lean`
   - Visibility: **Public**. Public repositories get free Actions minutes and a
     shareable link; Private also works.
   - Click **Create repository**.
3. On the new page, click **uploading an existing file**.
   - Unzip this package on your computer.
   - Drag the `replay_project` and `independent_audit` folders, plus this
     `README.md`, into the browser window.
   - Click **Commit changes**.
4. Add the workflow. Folders whose names start with a dot are often skipped by
   drag-and-drop, so create this one by hand:
   - Click **Add file**, then **Create new file**.
   - For the name, type exactly `.github/workflows/hypothesis-m-replay.yml`.
   - Paste in the contents of the file with that name from this package.
   - Click **Commit changes**.
5. Committing starts the build automatically. Click the **Actions** tab to watch it.
   - The first run takes roughly 20 to 40 minutes, mostly downloading Mathlib's
     cache.
   - To rerun it later, open **Actions**, select **Hypothesis M independent Lean
     replay**, and click **Run workflow**.
6. When the run finishes:
   - A green check means the proof was rebuilt independently and passed the
     axiom gate.
   - Open the run and download **hypothesis-m-replay-logs**, which holds all
     compiler logs and the audit output.
   - Send the run's web address to Claude and GPT.

## What a green result does and does not establish

**A green run establishes** that, on a machine neither AI system controls:
- Lean's kernel accepts a proof of exactly the frozen M statement;
- the proof uses only the standard axioms.

**It does not establish:**
- originality;
- significance;
- anything about Collatz convergence.

## Claude's pre-flight review of this package

Claude completed this review on 22 Oct 2026. It covered everything except the
compilation itself.

| Check | Result |
|---|---|
| `MStatement.lean`, read line by line | It states exactly Theorem M: the shortcut map, the actual orbit, odd inputs counted at times 0 to j−1, strict exits on both sides, the bound `Nat.log2 (n*n) + 1`, and n ≥ 2 |
| SHA-256 of `MStatement.lean` and `HypothesisMFinal.lean` | Both match GPT's report |
| `replay.py --check-only` | PASS for all 33 files |
| Search of the project modules for `sorry`, `admit`, `native_decide`, `axiom`, `debug.skipKernelTC`, `implemented_by`, `unsafe`, and custom `elab`, `macro` or `run_cmd` | None found |
| Redefinitions in the target namespace | None. `BaseCases.lean` adds theorems only |
| Knight2026 library | Declares 4 axioms (Ellison, Steiner, and two Halbeisen–Hungerbühler results). The M proof uses only axiom-free Knight lemmas (`bsDenominator_odd`, `bsNumerator` identities). The recorded axiom audit confirms that none of the 4 enters the proof |
| Knight compatibility patch | A one-line tactic fix (`unfold … at hn1 ⊢`). It cannot affect soundness |
| Axiom gate tested on GPT's recorded log | PASS |
